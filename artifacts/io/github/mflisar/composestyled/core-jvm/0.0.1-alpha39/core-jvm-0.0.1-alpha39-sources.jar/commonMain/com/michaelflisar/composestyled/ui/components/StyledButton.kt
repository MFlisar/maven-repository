package com.michaelflisar.composestyled.ui.components

import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.RowScope
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.Stable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.michaelflisar.composestyled.classes.ColorToken
import com.michaelflisar.composestyled.classes.CustomColors
import com.michaelflisar.composestyled.classes.IconComposable
import com.michaelflisar.composestyled.classes.asColorToken
import com.michaelflisar.composestyled.registry.LocalStyledRegistry
import com.michaelflisar.composestyled.registry.StyledComponent
import com.michaelflisar.composestyled.registry.StyledComponentWithDefaults
import com.michaelflisar.composestyled.registry.StyledKey
import com.michaelflisar.composestyled.runtime.InternalComposeStyledApi
import com.michaelflisar.composestyled.runtime.LocalStyledContext
import com.michaelflisar.composestyled.runtime.StyledContext
import com.michaelflisar.composestyled.ui.components.StyledButton.Customization

object StyledButton {

    // -------------
    // 1) key
    // -------------

    val Key = StyledKey<Implementation>("StyledButton")
    val DefaultsKey = StyledKey<Defaults>("StyledButtonDefaults")

    // -------------
    // 2) defaults
    // -------------

    @Stable
    data class Defaults(
        val shape: Shape,
        val iconPosition: IconPosition,
        val iconSpacing: Dp,
    )

    // -------------
    // 3) variants / context
    // -------------

    enum class Variant {
        /** Lets the active theme choose a style that fits the current context. */
        Auto,
        Filled,
        Outlined,
        Plain,
    }

    enum class IconPosition {
        AdjacentToContent,
        AtButtonEdges,
    }

    @InternalComposeStyledApi
    enum class Context : StyledContext {
        Icon,
        Dropdown,
    }

    // -------------
    // 4) customization
    // -------------

    @Immutable
    class Customization internal constructor(
        val colors: CustomColors?,
        val disabledColors: CustomColors?,
        val border: ColorToken?,
        val borderThickness: Dp?,
    )

    // -------------
    // 5) implementation
    // -------------

    interface Implementation : StyledComponent<Implementation>, StyledComponentWithDefaults<Defaults> {
        override val key: StyledKey<Implementation>
            get() = Key

        override val defaultsKey: StyledKey<Defaults>
            get() = DefaultsKey

        @Composable
        fun Render(
            variant: Variant,
            onClick: () -> Unit,
            modifier: Modifier,
            enabled: Boolean,
            shape: Shape,
            iconPosition: IconPosition,
            iconSpacing: Dp,
            interactionSource: MutableInteractionSource?,
            customization: Customization?,
            content: @Composable RowScope.() -> Unit,
        )
    }
}

// -------------------------
// defaults
// -------------------------

object StyledButtonDefaults {

    val shape: Shape
        @Composable get() = LocalStyledRegistry.current[StyledButton.DefaultsKey].shape

    val iconPosition: StyledButton.IconPosition
        @Composable get() = LocalStyledRegistry.current[StyledButton.DefaultsKey].iconPosition

    val iconSpacing: Dp
        @Composable get() = LocalStyledRegistry.current[StyledButton.DefaultsKey].iconSpacing

    fun customize(
        colors: CustomColors? = null,
        disabledColors: CustomColors? = null,
    ) = Customization(colors, disabledColors, null, null)

    fun customize(
        colors: CustomColors? = null,
        border: Color,
        borderThickness: Dp = 1.dp,
        disabledColors: CustomColors? = null,
    ) = customize(colors, border.asColorToken(), borderThickness, disabledColors)

    fun customize(
        colors: CustomColors? = null,
        border: ColorToken,
        borderThickness: Dp = 1.dp,
        disabledColors: CustomColors? = null,
    ) = Customization(colors, disabledColors, border, borderThickness)

}

// -------------------------
// public API
// -------------------------

/** A theme-rendered action button; [variant] defaults to a context-aware style. */
@Composable
fun StyledButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    interactionSource: MutableInteractionSource? = null,
    variant: StyledButton.Variant = StyledButton.Variant.Auto,
    // defaults / customisation
    shape: Shape = StyledButtonDefaults.shape,
    customization: Customization? = null,
    // content
    leadingIcon: IconComposable? = null,
    trailingIcon: IconComposable? = null,
    iconPosition: StyledButton.IconPosition = StyledButtonDefaults.iconPosition,
    iconSpacing: Dp = StyledButtonDefaults.iconSpacing,
    content: @Composable RowScope.() -> Unit,
) {
    StyledButtonImpl(
        variant = variant,
        onClick = onClick,
        modifier = modifier,
        enabled = enabled,
        interactionSource = interactionSource,
        shape = shape,
        iconSpacing = iconSpacing,
        customization = customization,
        leadingIcon = leadingIcon,
        trailingIcon = trailingIcon,
        iconPosition = iconPosition,
        content = content,
    )
}

/** A theme-rendered outlined action button. Its visual variant is fixed. */
@Composable
fun StyledOutlinedButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    interactionSource: MutableInteractionSource? = null,
    shape: Shape = StyledButtonDefaults.shape,
    customization: Customization? = null,
    leadingIcon: IconComposable? = null,
    trailingIcon: IconComposable? = null,
    iconPosition: StyledButton.IconPosition = StyledButtonDefaults.iconPosition,
    iconSpacing: Dp = StyledButtonDefaults.iconSpacing,
    content: @Composable RowScope.() -> Unit,
) {
    StyledButton(
        onClick = onClick,
        modifier = modifier,
        enabled = enabled,
        interactionSource = interactionSource,
        variant = StyledButton.Variant.Outlined,
        shape = shape,
        customization = customization,
        leadingIcon = leadingIcon,
        trailingIcon = trailingIcon,
        iconPosition = iconPosition,
        iconSpacing = iconSpacing,
        content = content,
    )
}

/** A theme-rendered plain/text action button. Its visual variant is fixed. */
@Composable
fun StyledTextButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    interactionSource: MutableInteractionSource? = null,
    shape: Shape = StyledButtonDefaults.shape,
    customization: Customization? = null,
    leadingIcon: IconComposable? = null,
    trailingIcon: IconComposable? = null,
    iconPosition: StyledButton.IconPosition = StyledButtonDefaults.iconPosition,
    iconSpacing: Dp = StyledButtonDefaults.iconSpacing,
    content: @Composable RowScope.() -> Unit,
) {
    StyledButton(
        onClick = onClick,
        modifier = modifier,
        enabled = enabled,
        interactionSource = interactionSource,
        variant = StyledButton.Variant.Plain,
        shape = shape,
        customization = customization,
        leadingIcon = leadingIcon,
        trailingIcon = trailingIcon,
        iconPosition = iconPosition,
        iconSpacing = iconSpacing,
        content = content,
    )
}

// -------------------------
// private API
// -------------------------

@OptIn(InternalComposeStyledApi::class)
@Composable
private fun StyledButtonImpl(
    variant: StyledButton.Variant,
    onClick: () -> Unit,
    modifier: Modifier,
    enabled: Boolean,
    interactionSource: MutableInteractionSource?,
    shape: Shape,
    customization: Customization?,
    leadingIcon: IconComposable?,
    trailingIcon: IconComposable?,
    iconPosition: StyledButton.IconPosition,
    iconSpacing: Dp,
    content: @Composable RowScope.() -> Unit,
) {
    val buttonModifier = modifier.withStyledInputPointerIcon()
    LocalStyledRegistry.current[StyledButton.Key].Render(
        variant = variant,
        onClick = onClick,
        modifier = buttonModifier,
        enabled = enabled,
        shape = shape,
        iconPosition = iconPosition,
        iconSpacing = iconSpacing,
        interactionSource = interactionSource,
        customization = customization,
        content = {
            renderButtonContent(
                leadingIcon = leadingIcon,
                trailingIcon = trailingIcon,
                content = content,
            )
        }
    )
}

// -------------------------
// private functions
// -------------------------

@Composable
private fun RowScope.renderButtonContent(
    leadingIcon: IconComposable?,
    trailingIcon: IconComposable?,
    content: @Composable RowScope.() -> Unit,
) {
    leadingIcon?.let { renderButtonIcon(it) }
    content()
    trailingIcon?.let { renderButtonIcon(it) }
}

@OptIn(InternalComposeStyledApi::class)
@Composable
private fun renderButtonIcon(icon: IconComposable) {
    CompositionLocalProvider(LocalStyledContext provides StyledButton.Context.Icon) {
        StyledIcon(icon = icon)
    }
}
