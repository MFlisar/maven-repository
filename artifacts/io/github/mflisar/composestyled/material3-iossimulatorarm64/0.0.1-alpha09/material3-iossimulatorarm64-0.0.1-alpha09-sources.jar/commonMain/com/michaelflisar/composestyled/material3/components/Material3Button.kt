package com.michaelflisar.composestyled.material3.components

import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ElevatedButton
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp
import com.michaelflisar.composestyled.StyledTheme
import com.michaelflisar.composestyled.material3.CopyMaterialThemeLocals
import com.michaelflisar.composestyled.material3.CopyStyledLocals
import com.michaelflisar.composestyled.material3.components.Material3Button.Companion.DefaultRoleMapping
import com.michaelflisar.composestyled.runtime.InternalComposeStyledApi
import com.michaelflisar.composestyled.runtime.LocalStyledContext
import com.michaelflisar.composestyled.runtime.StyledContext
import com.michaelflisar.composestyled.ui.components.StyledButton
import com.michaelflisar.composestyled.ui.components.StyledMenuBar
import com.michaelflisar.composestyled.ui.components.StyledTopBar
import com.michaelflisar.composestyled.ui.layout.StyledDialog
import com.michaelflisar.composestyled.ui.components.StyledSnackbar
import com.michaelflisar.composestyled.ui.specials.StyledGroupBox
import com.michaelflisar.composestyled.ui.specials.StyledSidePane
import com.michaelflisar.composestyled.ui.specials.StyledSwipeRevealActionBox

class Material3Button internal constructor(
    val roleMapping: RoleMapping,
) : StyledButton.Implementation {

    override val defaults: StyledButton.Defaults
        @Composable get() = StyledButton.Defaults(shape = RoundedCornerShape(percent = 50))

    companion object {

        // -------------
        // 1) create
        // -------------

        /**
         * Creates a Material3Button implementation for StyledButton with the given role mapping.
         * @param roleMapping The mapping of StyledButton roles to MaterialButton variants. Defaults to [DefaultRoleMapping].
         * @return A Material3Button implementation for StyledButton.
         */
        @Composable
        fun create(
            roleMapping: RoleMapping = DefaultRoleMapping,
        ) = remember(roleMapping) {
            Material3Button(roleMapping = roleMapping)
        }

        // -------------
        // 2) mapping
        // -------------

        typealias RoleMapping = (StyledButton.Role, StyledContext) -> Variant

        /**
         * The default mapping of StyledButton roles to MaterialButton variants.
         * - DialogAction and SnackbarAction contexts map to Text variant.
         * - Other contexts map by role:
         *   - Primary role maps to Primary variant.
         *   - Secondary role maps to Outlined variant.
         *   - Tertiary role maps to Text variant.
         */
        val DefaultRoleMapping: RoleMapping = { role, context ->
            when {
                role == StyledButton.Role.Default &&
                    context == StyledGroupBox.Context.Clickable -> Variant.Outlined
                role == StyledButton.Role.Default &&
                    context == StyledSidePane.Context.IconSlot -> Variant.Text
                role == StyledButton.Role.Default &&
                    context == StyledSwipeRevealActionBox.Context.RevealAction -> Variant.Text
                role == StyledButton.Role.Default &&
                    (context is StyledDialog.ActionContext ||
                        context == StyledSnackbar.Context.SnackbarAction ||
                        context == StyledDialog.Context.DialogAction ||
                        context == StyledDialog.Context.FullscreenAction ||
                        context == StyledDialog.Context.BottomSheetAction ||
                        context is StyledTopBar.Context ||
                        context == StyledMenuBar.Context.MenuItem) -> Variant.Text
                else -> when (role) {
                    StyledButton.Role.Default,
                    StyledButton.Role.Primary -> Variant.Primary
                    StyledButton.Role.Secondary -> Variant.Outlined
                    StyledButton.Role.Tertiary -> Variant.Text
                }
            }
        }
    }

    enum class Variant {
        Primary,
        Secondary,
        FilledTonal,
        Elevated,
        Outlined,
        Text
    }


    @OptIn(InternalComposeStyledApi::class)
    @Composable
    override fun Render(
        role: StyledButton.Role,
        onClick: () -> Unit,
        modifier: Modifier,
        enabled: Boolean,
        shape: Shape,
        interactionSource: MutableInteractionSource?,
        customization: StyledButton.Customization?,
        content: @Composable (RowScope.() -> Unit),
    ) {
        val context = LocalStyledContext.current
        val variant = roleMapping(role, context)
        val isGroupBox = context == StyledGroupBox.Context.Clickable
        val buttonModifier = if (context == StyledMenuBar.Context.MenuItem) {
            modifier.width(IntrinsicSize.Min)
        } else {
            modifier
        }
        val isContainerDefaultText = role == StyledButton.Role.Default &&
            (context is StyledTopBar.Context ||
                context == StyledMenuBar.Context.MenuItem)

        when (variant) {
            Variant.FilledTonal -> {
                FilledTonalButton(
                    onClick = onClick,
                    modifier = buttonModifier,
                    enabled = enabled,
                    shape = shape,
                    interactionSource = interactionSource,
                    colors = ButtonDefaults.filledTonalButtonColors(
                        containerColor = customization?.colors?.filledBackground?.resolve()
                            ?: Color.Unspecified,
                        contentColor = customization?.colors?.filledForeground?.resolve()
                            ?: Color.Unspecified,
                    ),
                    contentPadding = if (isGroupBox) {
                        PaddingValues(0.dp)
                    } else {
                        ButtonDefaults.ContentPadding
                    },
                ) {
                    // copy styles from M3 Button to styled locals

                    CopyMaterialThemeLocals(
                        contentColor = LocalContentColor.current
                    ) {
                        content()
                    }
                }
            }

            Variant.Primary -> {
                Button(
                    onClick = onClick,
                    modifier = buttonModifier,
                    enabled = enabled,
                    shape = shape,
                    interactionSource = interactionSource,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = customization?.colors?.filledBackground?.resolve()
                            ?: StyledTheme.colorScheme.primary,
                        contentColor = customization?.colors?.filledForeground?.resolve()
                            ?: MaterialTheme.colorScheme.onPrimary
                    ),
                    contentPadding = if (isGroupBox) {
                        PaddingValues(0.dp)
                    } else {
                        ButtonDefaults.ContentPadding
                    },
                ) {
                    // copy styles from M3 Button to styled locals

                    CopyMaterialThemeLocals(
                        contentColor = LocalContentColor.current
                    ) {
                        content()
                    }
                }
            }

            Variant.Secondary -> {
                Button(
                    onClick = onClick,
                    modifier = buttonModifier,
                    enabled = enabled,
                    shape = shape,
                    interactionSource = interactionSource,
                    // default: primary button

                    colors = ButtonDefaults.buttonColors(
                        containerColor = customization?.colors?.filledBackground?.resolve()
                            ?: StyledTheme.colorScheme.secondary,
                        contentColor = customization?.colors?.filledForeground?.resolve()
                            ?: StyledTheme.colorScheme.onSecondary
                    ),
                    contentPadding = if (isGroupBox) {
                        PaddingValues(0.dp)
                    } else {
                        ButtonDefaults.ContentPadding
                    },
                ) {
                    // copy styles from M3 Button to styled locals

                    CopyMaterialThemeLocals(
                        contentColor = LocalContentColor.current
                    ) {
                        content()
                    }
                }
            }

            Variant.Elevated -> {
                ElevatedButton(
                    onClick = onClick,
                    modifier = buttonModifier,
                    enabled = enabled,
                    shape = shape,
                    interactionSource = interactionSource,
                    colors = ButtonDefaults.elevatedButtonColors(
                        containerColor = customization?.colors?.filledBackground?.resolve()
                            ?: Color.Unspecified,
                        contentColor = customization?.colors?.filledForeground?.resolve()
                            ?: Color.Unspecified
                    ),
                    contentPadding = if (isGroupBox) {
                        PaddingValues(0.dp)
                    } else {
                        ButtonDefaults.ContentPadding
                    },
                ) {
                    // copy styles from M3 Button to styled locals

                    CopyMaterialThemeLocals(
                        contentColor = LocalContentColor.current
                    ) {
                        content()
                    }
                }
            }

            Variant.Outlined -> {
                // button does not allow to change border color via parameter
                // so we change the base local color instead

                CopyStyledLocals(
                    outlineVariant = customization?.border?.resolve()
                ) {
                    OutlinedButton(
                        onClick = onClick,
                        modifier = buttonModifier,
                        enabled = enabled,
                        shape = shape,
                        interactionSource = interactionSource,
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = Color.Unspecified,
                            contentColor = customization?.colors?.textForeground?.resolve()
                                ?: MaterialTheme.colorScheme.onSurfaceVariant
                        ),
                        border = if (isGroupBox) {
                            null
                        } else {
                            ButtonDefaults.outlinedButtonBorder(enabled)
                        },
                        contentPadding = if (isGroupBox) {
                            PaddingValues(0.dp)
                        } else {
                            ButtonDefaults.ContentPadding
                        },
                    ) {
                        // copy styles from M3 Button to styled locals

                        CopyMaterialThemeLocals(
                            contentColor = LocalContentColor.current
                        ) {
                            content()
                        }
                    }
                }
            }

            Variant.Text -> {
                TextButton(
                    onClick = onClick,
                    modifier = buttonModifier,
                    enabled = enabled,
                    shape = shape,
                    interactionSource = interactionSource,
                    colors = ButtonDefaults.textButtonColors(
                        containerColor = Color.Unspecified,
                        contentColor = customization?.colors?.textForeground?.resolve()
                            ?: if (isContainerDefaultText) StyledTheme.currentContentColor
                            else MaterialTheme.colorScheme.primary
                    ),
                    contentPadding = if (isGroupBox) {
                        PaddingValues(0.dp)
                    } else {
                        ButtonDefaults.TextButtonContentPadding
                    },
                ) {
                    // copy styles from M3 Button to styled locals

                    CopyMaterialThemeLocals(
                        contentColor = LocalContentColor.current
                    ) {
                        content()
                    }
                }

            }
        }
    }
}
