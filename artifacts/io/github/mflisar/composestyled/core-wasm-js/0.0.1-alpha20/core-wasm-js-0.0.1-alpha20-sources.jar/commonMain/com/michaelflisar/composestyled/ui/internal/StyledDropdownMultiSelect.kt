package com.michaelflisar.composestyled.ui.internal

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.MutableState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import com.michaelflisar.composestyled.StyledTheme
import com.michaelflisar.composestyled.runtime.InternalComposeStyledApi
import com.michaelflisar.composestyled.runtime.LocalStyledContext
import com.michaelflisar.composestyled.tokens.LocalStyledContentColor
import com.michaelflisar.composestyled.tokens.LocalStyledTextStyle
import com.michaelflisar.composestyled.ui.components.StyledButton
import com.michaelflisar.composestyled.ui.components.StyledCheckbox
import com.michaelflisar.composestyled.ui.components.StyledPopupMenu
import com.michaelflisar.composestyled.ui.components.StyledPopupMenuDefaults
import com.michaelflisar.composestyled.ui.layout.StyledRow
import com.michaelflisar.composestyled.ui.primitives.StyledText

// -------------------------
// context
// -------------------------

internal object StyledDropdownMultiSelect {
    class Actions internal constructor(
        val canSelectAll: Boolean,
        val canClear: Boolean,
        val selectAll: () -> Unit,
        val clearSelection: () -> Unit,
    )
}

// -------------------------
// defaults
// -------------------------

internal object StyledDropdownMultiSelectDefaults {

    @OptIn(InternalComposeStyledApi::class)
    @Composable
    fun defaultActions(
        selectAllLabel: String = "Select all",
        clearSelectionLabel: String = "Clear selection",
    ): @Composable (StyledDropdownMultiSelect.Actions) -> Unit = { actions ->
        StyledRow(
            modifier = Modifier.fillMaxWidth().padding(StyledTheme.padding.medium),
            horizontalArrangement = Arrangement.spacedBy(
                StyledTheme.spacing.medium,
                Alignment.End,
            ),
        ) {
            CompositionLocalProvider(
                LocalStyledContext provides StyledButton.Context.Dropdown,
            ) {
                StyledButton(onClick = actions.selectAll, enabled = actions.canSelectAll) {
                    StyledText(selectAllLabel)
                }
                StyledButton(onClick = actions.clearSelection, enabled = actions.canClear) {
                    StyledText(clearSelectionLabel)
                }
            }
        }
    }

    @Composable
    fun <T : Any> defaultRenderer(
        mapper: @Composable (item: T) -> String = { it.toString() },
        formatter: @Composable (selected: List<String>) -> String = StyledDropdownMultiSelectDefaults.formatter,
        color: Color = Color.Unspecified,
        fontWeight: FontWeight? = null,
        maxLines: Int = 1,
        leadingContent: @Composable () -> Unit = {},
        dropdownMapper: @Composable (item: T) -> String = mapper,
        colorDropdown: Color = Color.Unspecified,
        colorDropdownSelected: Color = StyledTheme.colorScheme.primary,
        fontWeightDropdown: FontWeight? = null,
        fontWeightDropdownSelected: FontWeight? = FontWeight.Bold,
        maxLinesDropdown: Int = 1,
        textStyle: TextStyle? = null,
        dropdownTextStyle: TextStyle? = textStyle,
    ) = StyledDropdown.renderContent(
        content = defaultContent(
            mapper = mapper,
            formatter = formatter,
            color = color,
            fontWeight = fontWeight,
            maxLines = maxLines,
            leadingContent = leadingContent,
            textStyle = textStyle,
        ),
        dropdownContent = defaultDropdownContent(
            mapper = dropdownMapper,
            color = colorDropdown,
            colorSelected = colorDropdownSelected,
            fontWeight = fontWeightDropdown,
            fontWeightSelected = fontWeightDropdownSelected,
            maxLines = maxLinesDropdown,
            leadingContent = leadingContent,
            textStyle = dropdownTextStyle,
        )
    )

    @Composable
    fun <T : Any> defaultRenderer(
        content: @Composable (context: StyledDropdown.RenderContext.Selection<List<T>>) -> Unit = defaultContent(),
        dropdownContent: @Composable (context: StyledDropdown.RenderContext.DropdownItem<T>) -> Unit = defaultDropdownContent(),
    ) = StyledDropdown.renderContent(
        content = content,
        dropdownContent = dropdownContent
    )

    @Composable
    fun <T> defaultContent(
        mapper: @Composable (item: T) -> String = { it.toString() },
        formatter: @Composable (selected: List<String>) -> String = StyledDropdownMultiSelectDefaults.formatter,
        color: Color = Color.Unspecified,
        fontWeight: FontWeight? = null,
        maxLines: Int = 1,
        leadingContent: @Composable () -> Unit = {},
        textStyle: TextStyle? = null,
    ): @Composable (StyledDropdown.RenderContext.Selection<List<T>>) -> Unit = { context ->
        val resolvedTextStyle = textStyle?.let(LocalStyledTextStyle.current::merge)
            ?: LocalStyledTextStyle.current
        StyledRow(itemSpacing = StyledTheme.spacing.medium) {
            leadingContent()
            StyledText(
                text = formatter(context.selection.map { mapper(it) }),
                modifier = Modifier.weight(1f),
                color = color,
                fontWeight = if (textStyle?.fontWeight != null) null else fontWeight,
                style = resolvedTextStyle,
                maxLines = maxLines
            )
        }
    }

    @Composable
    fun <T : Any> defaultDropdownContent(
        mapper: @Composable (item: T) -> String = { it.toString() },
        color: Color = Color.Unspecified,
        colorSelected: Color = StyledTheme.colorScheme.primary,
        fontWeight: FontWeight? = null,
        fontWeightSelected: FontWeight? = FontWeight.Bold,
        maxLines: Int = 1,
        leadingContent: @Composable () -> Unit = {},
        textStyle: TextStyle? = null,
    ): @Composable (StyledDropdown.RenderContext.DropdownItem<T>) -> Unit = { context ->
        val resolvedTextStyle = textStyle?.let(LocalStyledTextStyle.current::merge)
            ?: LocalStyledTextStyle.current
        StyledRow(
            modifier = Modifier.fillMaxWidth(),
            itemSpacing = StyledTheme.spacing.medium
        ) {
            StyledCheckbox(
                checked = context.selected,
                onCheckedChange = null,
                tint = (if (context.selected) colorSelected else color)
                    .takeIf { it != Color.Unspecified } ?: LocalStyledContentColor.current,
            )
            leadingContent()
            StyledText(
                text = mapper(context.item),
                color = if (context.selected) colorSelected else color,
                modifier = Modifier.weight(1f),
                fontWeight = if (textStyle?.fontWeight != null) {
                    null
                } else if (context.selected) {
                    fontWeightSelected
                } else {
                    fontWeight
                },
                style = resolvedTextStyle,
                maxLines = maxLines
            )
        }
    }

    @Composable
    fun shape() = StyledTheme.shapes.small

    val formatter: @Composable (selected: List<String>) -> String = { selected ->
        if (selected.isEmpty()) {
            ""
        } else {
            selected.joinToString(";")
        }
    }

    const val sortSelectionByItems = true
}

// -------------------------
// public API
// -------------------------

/**
 * Updates [selected] before notifying [onSelectionChange] with original list indices and items.
 */
@Composable
internal fun <T : Any> StyledDropdownMultiSelect(
    items: List<T>,
    selected: MutableState<List<T>>,
    modifier: Modifier = Modifier,
    title: String = "",
    enabled: Boolean = true,
    variant: StyledButton.Variant = StyledButton.Variant.Auto,
    // defaults / customisation
    customization: StyledButton.Customization? = null,
    filter: StyledDropdown.Filter<T>? = null,
    shape: Shape = StyledDropdownMultiSelectDefaults.shape(),
    popupWidthConfig: StyledPopupMenu.WidthConfig = StyledPopupMenu.WidthConfig.MatchAnchor,
    popupHorizontalAlignment: StyledPopupMenu.HorizontalAlignment =
        StyledPopupMenu.HorizontalAlignment.Start,
    sortSelectionByItems: Boolean = StyledDropdownMultiSelectDefaults.sortSelectionByItems,
    expanded: MutableState<Boolean>? = null,
    // content
    content: @Composable (context: StyledDropdown.RenderContext<T, List<T>>) -> Unit = StyledDropdownMultiSelectDefaults.defaultRenderer(),
    popupMaxHeight: Dp = StyledPopupMenuDefaults.maxHeight,
    actions: @Composable (StyledDropdownMultiSelect.Actions) -> Unit = StyledDropdownMultiSelectDefaults.defaultActions(),
    onSelectionChange: ((indices: List<Int>, items: List<T>) -> Unit)? = null,
) {
    StyledDropdownMultiSelect(
        modifier = modifier,
        items = items,
        selected = selected.value,
        title = title,
        enabled = enabled,
        variant = variant,
        filter = filter,
        customization = customization,
        shape = shape,
        popupWidthConfig = popupWidthConfig,
        popupHorizontalAlignment = popupHorizontalAlignment,
        sortSelectionByItems = sortSelectionByItems,
        expanded = expanded,
        content = content,
        popupMaxHeight = popupMaxHeight,
        actions = actions,
    ) { selectedIndices, selectedItems ->
        selected.value = selectedItems
        onSelectionChange?.invoke(selectedIndices, selectedItems)
    }
}

/**
 * Renders selected items through [StyledDropdown.RenderContext.Selection] and menu entries through
 * [StyledDropdown.RenderContext.DropdownItem]. Item clicks toggle selection without closing the menu.
 */
@Composable
internal fun <T : Any> StyledDropdownMultiSelect(
    items: List<T>,
    selected: List<T>,
    modifier: Modifier = Modifier,
    title: String = "",
    enabled: Boolean = true,
    variant: StyledButton.Variant = StyledButton.Variant.Auto,
    // defaults / customisation
    customization: StyledButton.Customization? = null,
    filter: StyledDropdown.Filter<T>? = null,
    shape: Shape = StyledDropdownMultiSelectDefaults.shape(),
    popupWidthConfig: StyledPopupMenu.WidthConfig = StyledPopupMenu.WidthConfig.MatchAnchor,
    popupHorizontalAlignment: StyledPopupMenu.HorizontalAlignment =
        StyledPopupMenu.HorizontalAlignment.Start,
    sortSelectionByItems: Boolean = StyledDropdownMultiSelectDefaults.sortSelectionByItems,
    expanded: MutableState<Boolean>? = null,
    // content
    content: @Composable (context: StyledDropdown.RenderContext<T, List<T>>) -> Unit = StyledDropdownMultiSelectDefaults.defaultRenderer(),
    popupMaxHeight: Dp = StyledPopupMenuDefaults.maxHeight,
    actions: @Composable (StyledDropdownMultiSelect.Actions) -> Unit = StyledDropdownMultiSelectDefaults.defaultActions(),
    onSelectionChange: (indices: List<Int>, items: List<T>) -> Unit,
) {
    val selectedIndices = selected.map { items.indexOf(it) }
    StyledDropdownMultiSelectImpl(
        modifier = modifier,
        title = title,
        items = items,
        selected = selectedIndices,
        enabled = enabled,
        customization = customization,
        filter = filter,
        shape = shape,
        popupWidthConfig = popupWidthConfig,
        popupHorizontalAlignment = popupHorizontalAlignment,
        popupMaxHeight = popupMaxHeight,
        expanded = expanded,
        content = content,
        sortSelectionByItems = sortSelectionByItems,
        actions = actions,
        variant = variant,
        onSelectionChange = onSelectionChange
    )
}

/**
 * Updates [selectedIndices] before notifying [onSelectionChange] with original list indices and items.
 */
@Composable
internal fun <T : Any> StyledDropdownMultiSelectIndex(
    items: List<T>,
    selectedIndices: MutableState<List<Int>>,
    modifier: Modifier = Modifier,
    title: String = "",
    enabled: Boolean = true,
    variant: StyledButton.Variant = StyledButton.Variant.Auto,
    // defaults / customisation
    customization: StyledButton.Customization? = null,
    filter: StyledDropdown.Filter<T>? = null,
    shape: Shape = StyledDropdownMultiSelectDefaults.shape(),
    popupWidthConfig: StyledPopupMenu.WidthConfig = StyledPopupMenu.WidthConfig.MatchAnchor,
    popupHorizontalAlignment: StyledPopupMenu.HorizontalAlignment =
        StyledPopupMenu.HorizontalAlignment.Start,
    sortSelectionByItems: Boolean = StyledDropdownMultiSelectDefaults.sortSelectionByItems,
    // content
    content: @Composable (context: StyledDropdown.RenderContext<T, List<T>>) -> Unit = StyledDropdownMultiSelectDefaults.defaultRenderer(),
    popupMaxHeight: Dp = StyledPopupMenuDefaults.maxHeight,
    actions: @Composable (StyledDropdownMultiSelect.Actions) -> Unit = StyledDropdownMultiSelectDefaults.defaultActions(),
    onSelectionChange: ((indices: List<Int>, items: List<T>) -> Unit)? = null,
) {
    StyledDropdownMultiSelectIndex(
        modifier = modifier,
        items = items,
        selectedIndices = selectedIndices.value,
        title = title,
        enabled = enabled,
        variant = variant,
        filter = filter,
        customization = customization,
        shape = shape,
        popupWidthConfig = popupWidthConfig,
        popupHorizontalAlignment = popupHorizontalAlignment,
        sortSelectionByItems = sortSelectionByItems,
        content = content,
        popupMaxHeight = popupMaxHeight,
        actions = actions,
        onSelectionChange = { indices, selectedItems ->
            selectedIndices.value = indices
            onSelectionChange?.invoke(indices, selectedItems)
        },
    )
}

/**
 * [selectedIndices] must reference entries in [items].
 * [sortSelectionByItems] orders the rendered selection and callback results by original list index.
 * [filter] affects menu entries only; select-all and clear operate on the entire selection.
 */
@Composable
internal fun <T : Any> StyledDropdownMultiSelectIndex(
    items: List<T>,
    selectedIndices: List<Int>,
    modifier: Modifier = Modifier,
    title: String = "",
    enabled: Boolean = true,
    variant: StyledButton.Variant = StyledButton.Variant.Auto,
    // defaults / customisation
    customization: StyledButton.Customization? = null,
    filter: StyledDropdown.Filter<T>? = null,
    shape: Shape = StyledDropdownMultiSelectDefaults.shape(),
    popupWidthConfig: StyledPopupMenu.WidthConfig = StyledPopupMenu.WidthConfig.MatchAnchor,
    popupHorizontalAlignment: StyledPopupMenu.HorizontalAlignment =
        StyledPopupMenu.HorizontalAlignment.Start,
    sortSelectionByItems: Boolean = StyledDropdownMultiSelectDefaults.sortSelectionByItems,
    // content
    content: @Composable (context: StyledDropdown.RenderContext<T, List<T>>) -> Unit = StyledDropdownMultiSelectDefaults.defaultRenderer(),
    popupMaxHeight: Dp = StyledPopupMenuDefaults.maxHeight,
    actions: @Composable (StyledDropdownMultiSelect.Actions) -> Unit = StyledDropdownMultiSelectDefaults.defaultActions(),
    onSelectionChange: (indices: List<Int>, items: List<T>) -> Unit,
) {
    StyledDropdownMultiSelectImpl(
        modifier = modifier,
        title = title,
        items = items,
        selected = selectedIndices,
        enabled = enabled,
        customization = customization,
        filter = filter,
        shape = shape,
        popupWidthConfig = popupWidthConfig,
        popupHorizontalAlignment = popupHorizontalAlignment,
        popupMaxHeight = popupMaxHeight,
        expanded = null,
        content = content,
        sortSelectionByItems = sortSelectionByItems,
        actions = actions,
        variant = variant,
        onSelectionChange = onSelectionChange
    )
}

/**
 * Outlined-variant overload for [StyledDropdownMultiSelect] with state-backed selection.
 */
@Composable
internal fun <T : Any> StyledOutlinedDropdownMultiSelect(
    items: List<T>,
    selected: MutableState<List<T>>,
    modifier: Modifier = Modifier,
    title: String = "",
    enabled: Boolean = true,
    // defaults / customisation
    customization: StyledButton.Customization? = null,
    filter: StyledDropdown.Filter<T>? = null,
    shape: Shape = StyledDropdownMultiSelectDefaults.shape(),
    popupWidthConfig: StyledPopupMenu.WidthConfig = StyledPopupMenu.WidthConfig.MatchAnchor,
    sortSelectionByItems: Boolean = StyledDropdownMultiSelectDefaults.sortSelectionByItems,
    // content
    content: @Composable (context: StyledDropdown.RenderContext<T, List<T>>) -> Unit = StyledDropdownMultiSelectDefaults.defaultRenderer(),
    popupMaxHeight: Dp = StyledPopupMenuDefaults.maxHeight,
    actions: @Composable (StyledDropdownMultiSelect.Actions) -> Unit = StyledDropdownMultiSelectDefaults.defaultActions(),
    onSelectionChange: ((indices: List<Int>, items: List<T>) -> Unit)? = null,
) {
    StyledDropdownMultiSelect(
        items = items,
        selected = selected,
        modifier = modifier,
        title = title,
        enabled = enabled,
        variant = StyledButton.Variant.Outlined,
        customization = customization,
        filter = filter,
        shape = shape,
        popupWidthConfig = popupWidthConfig,
        sortSelectionByItems = sortSelectionByItems,
        content = content,
        popupMaxHeight = popupMaxHeight,
        actions = actions,
        onSelectionChange = onSelectionChange,
    )
}

/**
 * Outlined-variant overload for [StyledDropdownMultiSelect] with controlled selection.
 */
@Composable
internal fun <T : Any> StyledOutlinedDropdownMultiSelect(
    items: List<T>,
    selected: List<T>,
    modifier: Modifier = Modifier,
    title: String = "",
    enabled: Boolean = true,
    // defaults / customisation
    customization: StyledButton.Customization? = null,
    filter: StyledDropdown.Filter<T>? = null,
    shape: Shape = StyledDropdownMultiSelectDefaults.shape(),
    popupWidthConfig: StyledPopupMenu.WidthConfig = StyledPopupMenu.WidthConfig.MatchAnchor,
    sortSelectionByItems: Boolean = StyledDropdownMultiSelectDefaults.sortSelectionByItems,
    // content
    content: @Composable (context: StyledDropdown.RenderContext<T, List<T>>) -> Unit = StyledDropdownMultiSelectDefaults.defaultRenderer(),
    popupMaxHeight: Dp = StyledPopupMenuDefaults.maxHeight,
    actions: @Composable (StyledDropdownMultiSelect.Actions) -> Unit = StyledDropdownMultiSelectDefaults.defaultActions(),
    onSelectionChange: (indices: List<Int>, items: List<T>) -> Unit,
) {
    StyledDropdownMultiSelect(
        items = items,
        selected = selected,
        modifier = modifier,
        title = title,
        enabled = enabled,
        variant = StyledButton.Variant.Outlined,
        customization = customization,
        filter = filter,
        shape = shape,
        popupWidthConfig = popupWidthConfig,
        sortSelectionByItems = sortSelectionByItems,
        content = content,
        popupMaxHeight = popupMaxHeight,
        actions = actions,
        onSelectionChange = onSelectionChange,
    )
}

/**
 * Outlined-variant overload for [StyledDropdownMultiSelectIndex] with state-backed selection.
 */
@Composable
internal fun <T : Any> StyledOutlinedDropdownMultiSelectIndex(
    items: List<T>,
    selectedIndices: MutableState<List<Int>>,
    modifier: Modifier = Modifier,
    title: String = "",
    enabled: Boolean = true,
    // defaults / customisation
    customization: StyledButton.Customization? = null,
    filter: StyledDropdown.Filter<T>? = null,
    shape: Shape = StyledDropdownMultiSelectDefaults.shape(),
    popupWidthConfig: StyledPopupMenu.WidthConfig = StyledPopupMenu.WidthConfig.MatchAnchor,
    sortSelectionByItems: Boolean = StyledDropdownMultiSelectDefaults.sortSelectionByItems,
    // content
    content: @Composable (context: StyledDropdown.RenderContext<T, List<T>>) -> Unit = StyledDropdownMultiSelectDefaults.defaultRenderer(),
    popupMaxHeight: Dp = StyledPopupMenuDefaults.maxHeight,
    actions: @Composable (StyledDropdownMultiSelect.Actions) -> Unit = StyledDropdownMultiSelectDefaults.defaultActions(),
    onSelectionChange: ((indices: List<Int>, items: List<T>) -> Unit)? = null,
) {
    StyledDropdownMultiSelectIndex(
        items = items,
        selectedIndices = selectedIndices,
        modifier = modifier,
        title = title,
        enabled = enabled,
        variant = StyledButton.Variant.Outlined,
        customization = customization,
        filter = filter,
        shape = shape,
        popupWidthConfig = popupWidthConfig,
        sortSelectionByItems = sortSelectionByItems,
        content = content,
        popupMaxHeight = popupMaxHeight,
        actions = actions,
        onSelectionChange = onSelectionChange,
    )
}

/**
 * Outlined-variant overload for [StyledDropdownMultiSelectIndex] with controlled selection.
 */
@Composable
internal fun <T : Any> StyledOutlinedDropdownMultiSelectIndex(
    items: List<T>,
    selectedIndices: List<Int>,
    modifier: Modifier = Modifier,
    title: String = "",
    enabled: Boolean = true,
    // defaults / customisation
    customization: StyledButton.Customization? = null,
    filter: StyledDropdown.Filter<T>? = null,
    shape: Shape = StyledDropdownMultiSelectDefaults.shape(),
    popupWidthConfig: StyledPopupMenu.WidthConfig = StyledPopupMenu.WidthConfig.MatchAnchor,
    sortSelectionByItems: Boolean = StyledDropdownMultiSelectDefaults.sortSelectionByItems,
    // content
    content: @Composable (context: StyledDropdown.RenderContext<T, List<T>>) -> Unit = StyledDropdownMultiSelectDefaults.defaultRenderer(),
    popupMaxHeight: Dp = StyledPopupMenuDefaults.maxHeight,
    actions: @Composable (StyledDropdownMultiSelect.Actions) -> Unit = StyledDropdownMultiSelectDefaults.defaultActions(),
    onSelectionChange: (indices: List<Int>, items: List<T>) -> Unit,
) {
    StyledDropdownMultiSelectIndex(
        items = items,
        selectedIndices = selectedIndices,
        modifier = modifier,
        title = title,
        enabled = enabled,
        variant = StyledButton.Variant.Outlined,
        customization = customization,
        filter = filter,
        shape = shape,
        popupWidthConfig = popupWidthConfig,
        sortSelectionByItems = sortSelectionByItems,
        content = content,
        popupMaxHeight = popupMaxHeight,
        actions = actions,
        onSelectionChange = onSelectionChange,
    )
}



// -------------------------
// private API
// -------------------------

@Composable
private fun <T : Any> StyledDropdownMultiSelectImpl(
    modifier: Modifier,
    title: String,
    items: List<T>,
    selected: List<Int>,
    enabled: Boolean,
    customization: StyledButton.Customization?,
    filter: StyledDropdown.Filter<T>?,
    shape: Shape,
    popupWidthConfig: StyledPopupMenu.WidthConfig,
    popupHorizontalAlignment: StyledPopupMenu.HorizontalAlignment,
    expanded: MutableState<Boolean>?,
    content: @Composable (context: StyledDropdown.RenderContext<T, List<T>>) -> Unit,
    sortSelectionByItems: Boolean,
    variant: StyledButton.Variant,
    popupMaxHeight: Dp,
    actions: @Composable (StyledDropdownMultiSelect.Actions) -> Unit,
    onSelectionChange: (indices: List<Int>, items: List<T>) -> Unit,
) {
    val selectedIndices = dropdownSelectionIndices(selected, items.size, sortSelectionByItems)
    val selectedItems = selectedIndices.map { items[it] }
    val notifySelectionChange: (List<Int>) -> Unit = { indices ->
        val effectiveIndices = dropdownSelectionIndices(indices, items.size, sortSelectionByItems)
        onSelectionChange(effectiveIndices, effectiveIndices.map { items[it] })
    }
    StyledDropdownBase(
        modifier = modifier,
        title = title,
        items = items,
        selection = selectedItems,
        isSelected = { it in selectedIndices },
        closeOnItemClick = false,
        enabled = enabled,
        customization = customization,
        filter = filter,
        shape = shape,
        variant = variant,
        popupWidthConfig = popupWidthConfig,
        popupHorizontalAlignment = popupHorizontalAlignment,
        popupMaxHeight = popupMaxHeight,
        expanded = expanded,
        content = content,
        popupHeader = {
            actions(
                StyledDropdownMultiSelect.Actions(
                    canSelectAll = selectedIndices.size != items.size,
                    canClear = selectedIndices.isNotEmpty(),
                    selectAll = { notifySelectionChange(items.indices.toList()) },
                    clearSelection = { notifySelectionChange(emptyList()) },
                )
            )
        },
        onItemClick = { index, _ ->
            notifySelectionChange(toggleDropdownSelection(selectedIndices, index))
        }
    )
}

internal fun dropdownSelectionIndices(
    selected: List<Int>,
    itemCount: Int,
    sortSelectionByItems: Boolean,
): List<Int> {
    require(selected.all { it in 0 until itemCount }) {
        "Selected indices must refer to entries in items"
    }
    val unique = selected.distinct()
    return if (sortSelectionByItems) unique.sorted() else unique
}

internal fun toggleDropdownSelection(selected: List<Int>, index: Int): List<Int> =
    if (index in selected) selected.filterNot { it == index } else selected + index