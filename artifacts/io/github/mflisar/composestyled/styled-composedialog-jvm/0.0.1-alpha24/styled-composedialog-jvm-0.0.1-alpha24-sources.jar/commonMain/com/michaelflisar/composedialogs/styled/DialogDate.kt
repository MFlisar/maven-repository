package com.michaelflisar.composedialogs.styled

import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import com.michaelflisar.composedialogs.dialogs.date.DatePicker
import com.michaelflisar.composedialogs.dialogs.date.ui.DatePickerRange
import com.michaelflisar.composedialogs.dialogs.date.ui.DatePickerSetup
import com.michaelflisar.composedialogs.styled.provider.DateUIProviderImpl
import com.michaelflisar.composestyled.isLandscape
import com.michaelflisar.composestyled.ui.layout.StyledDialog
import com.michaelflisar.composestyled.ui.layout.StyledDialogDefaults
import com.michaelflisar.composestyled.ui.state.DialogState
import kotlinx.datetime.LocalDate

/** Shows the ComposeDialogs date picker in a Styled dialog. */
@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun DialogDate(
    state: DialogState,
    date: MutableState<LocalDate>,
    dateRange: DatePickerRange,
    setup: DatePickerSetup,
    modifier: Modifier = Modifier,
    style: StyledDialog.Style = StyledDialogDefaults.style,
    properties: StyledDialog.Properties = StyledDialog.Properties(),
    title: (@Composable () -> Unit)? = null,
    icon: (@Composable () -> Unit)? = null,
    buttons: StyledDialog.Buttons = StyledDialog.Buttons(),
    onDismissRequest: () -> Unit = state::dismiss,
) {
    val landscape = isLandscape
    StyledDialog(
        state = state,
        modifier = modifier,
        style = style,
        properties = properties,
        title = StyledDialogDefaults.title(
            icon.takeUnless { landscape },
            title.takeUnless { landscape },
        ),
        buttons = buttons,
        onDismissRequest = onDismissRequest,
        content = StyledDialogDefaults.content {
            if (state.visible) {
                DatePicker(
                    uiProvider = DateUIProviderImpl,
                    date = date,
                    dateRange = dateRange,
                    setup = setup,
                    landscape = landscape,
                    title = title,
                    icon = icon,
                )
            }
        },
    )
}
