package com.michaelflisar.composepreferences.styled

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.michaelflisar.composepreferences.styled.internal.BaseDialogPreference
import com.michaelflisar.composepreferences.styled.internal.LocalPreferenceStyle
import com.michaelflisar.composepreferences.styled.internal.PreferenceEntry
import com.michaelflisar.composepreferences.styled.layout.PreferenceStyledRow
import com.michaelflisar.composestyled.StyledTheme
import com.michaelflisar.composestyled.classes.CustomColors
import com.michaelflisar.composestyled.classes.IconComposable
import com.michaelflisar.composestyled.tokens.LocalStyledTextStyle
import com.michaelflisar.composestyled.ui.components.StyledButton
import com.michaelflisar.composestyled.ui.components.StyledButtonDefaults
import com.michaelflisar.composestyled.ui.components.StyledCheckbox
import com.michaelflisar.composestyled.ui.components.StyledIcon
import com.michaelflisar.composestyled.ui.components.StyledInput
import com.michaelflisar.composestyled.ui.components.StyledListItem
import com.michaelflisar.composestyled.ui.components.StyledPopupDropdown
import com.michaelflisar.composestyled.ui.components.StyledPopupDropdownMultiSelect
import com.michaelflisar.composestyled.ui.components.StyledPopupDropdownMultiSelectDefaults
import com.michaelflisar.composestyled.ui.components.StyledPopupMenu
import com.michaelflisar.composestyled.ui.components.StyledRadioButton
import com.michaelflisar.composestyled.ui.layout.StyledDialog
import com.michaelflisar.composestyled.ui.primitives.StyledText
import com.michaelflisar.composestyled.ui.state.rememberDialogState
import com.michaelflisar.composestyled.utils.PointerInputBlocker

object PreferenceList {
    sealed class Presentation {
        data object Dialog : Presentation()

        data class Dropdown(
            val clickBehavior: ClickBehavior = ClickBehavior.FullItem,
        ) : Presentation() {
            enum class ClickBehavior {
                /** The whole preference row opens the dropdown. */
                FullItem,

                /** Only the trailing dropdown control opens the dropdown. */
                DropdownOnly,
            }
        }
    }

    class Filter<T : Any>(
        val label: String? = null,
        val matches: ((query: String, item: T) -> Boolean)? = null,
    )
}

/** Single-selection preference presented in a dialog or dropdown. */
@Composable
fun <T : Any> PreferenceList(
    items: List<T>,
    selected: MutableState<T>,
    title: String,
    modifier: Modifier = Modifier,
    key: String? = null,
    subtitle: String? = null,
    icon: IconComposable? = null,
    presentation: PreferenceList.Presentation = PreferenceList.Presentation.Dialog,
    filter: PreferenceList.Filter<T>? = null,
    itemText: (T) -> String = { it.toString() },
    enabled: Boolean = true,
    filterTags: List<String> = emptyList(),
    isEnabled: @Composable () -> Boolean = { enabled },
    isVisible: @Composable () -> Boolean = { true },
    dropdownCustomization: StyledButton.Customization? = null,
    shape: Shape? = null,
    itemLeadingContent: (@Composable (T) -> Unit)? = null,
) {
    PreferenceList(
        items = items,
        selected = selected.value,
        onValueChange = { selected.value = it },
        title = title,
        modifier = modifier,
        key = key,
        subtitle = subtitle,
        icon = icon,
        presentation = presentation,
        filter = filter,
        itemText = itemText,
        enabled = enabled,
        filterTags = filterTags,
        isEnabled = isEnabled,
        isVisible = isVisible,
        dropdownCustomization = dropdownCustomization,
        shape = shape,
        itemLeadingContent = itemLeadingContent,
    )
}

/** Controlled single-selection preference. */
@Composable
fun <T : Any> PreferenceList(
    items: List<T>,
    selected: T,
    onValueChange: (T) -> Unit,
    title: String,
    modifier: Modifier = Modifier,
    key: String? = null,
    subtitle: String? = null,
    icon: IconComposable? = null,
    presentation: PreferenceList.Presentation = PreferenceList.Presentation.Dialog,
    filter: PreferenceList.Filter<T>? = null,
    itemText: (T) -> String = { it.toString() },
    enabled: Boolean = true,
    filterTags: List<String> = emptyList(),
    isEnabled: @Composable () -> Boolean = { enabled },
    isVisible: @Composable () -> Boolean = { true },
    dropdownCustomization: StyledButton.Customization? = null,
    shape: Shape? = null,
    itemLeadingContent: (@Composable (T) -> Unit)? = null,
) {
    val dialog = rememberDialogState()
    val strings = LocalPreferenceStrings.current
    var query by rememberSaveable { mutableStateOf("") }
    val dropdownExpanded = remember { mutableStateOf(false) }
    val effectiveShape = checkNotNull(LocalPreferenceStyle.current).item.shape

    when (presentation) {
        is PreferenceList.Presentation.Dropdown -> PreferenceEntry(
            title = title,
            subtitle = subtitle ?: itemText(selected),
            filterTags = filterTags,
            key = key,
            isEnabled = isEnabled,
            isVisible = isVisible,
            breaksSectionShape = shape != null,
        ) { visuals ->
            PreferenceStyledRow(
                title = title,
                subtitle = subtitle,
                icon = icon,
                modifier = modifier,
                onClick =
                    if (presentation.clickBehavior ==
                        PreferenceList.Presentation.Dropdown.ClickBehavior.FullItem
                    ) {
                        { dropdownExpanded.value = true }
                    } else {
                        null
                    },
                enabled = visuals.enabled,
                style = visuals.style,
                insideSection = visuals.insideSection,
                breadcrumb = visuals.breadcrumb,
                shape = shape,
                trailing = {
                    val textStyle = LocalStyledTextStyle.current
                    val dropdownTextStyle = textStyle.copy(textAlign = TextAlign.Start)
                    val blockDropdownInteraction = presentation.clickBehavior == PreferenceList.Presentation.Dropdown.ClickBehavior.FullItem
                    PointerInputBlocker(blocked = blockDropdownInteraction) {
                        StyledPopupDropdown(
                            items = items,
                            selected = selected,
                            title = "",
                            enabled = visuals.enabled,
                            expanded = dropdownExpanded,
                            filter = filter?.toStyledFilter(itemText, strings.filterOptions),
                            variant = StyledButton.Variant.Plain,
                            customization = dropdownCustomization
                                ?: visuals.style.toDropdownCustomization(),
                            content = {
                                selection { item ->
                                    if (item != null) {
                                        PreferenceListDropdownItem(
                                            item = item,
                                            itemText = itemText,
                                            itemLeadingContent = itemLeadingContent,
                                            textStyle = textStyle,
                                        )
                                    }
                                }
                                item { item, selected ->
                                    PreferenceListDropdownItem(
                                        item = item,
                                        itemText = itemText,
                                        itemLeadingContent = itemLeadingContent,
                                        textStyle = dropdownTextStyle,
                                        selected = selected,
                                        modifier = Modifier.fillMaxWidth(),
                                    )
                                }
                            },
                            onSelectionChange = { _, item -> onValueChange(item) },
                            popupWidthConfig = StyledPopupMenu.WidthConfig.WrapContent,
                            popupHorizontalAlignment = StyledPopupMenu.HorizontalAlignment.End,
                        )
                    }
                },
            )
        }

        PreferenceList.Presentation.Dialog -> BaseDialogPreference(
            data = items,
            title = title,
            subtitle = subtitle ?: itemText(selected),
            displaySubtitle = subtitle,
            dialog = dialog,
            modifier = modifier,
            key = key,
            icon = icon,
            filterTags = filterTags,
            enabled = enabled,
            isEnabled = isEnabled,
            isVisible = isVisible,
            shape = shape,
            trailing = {
                Row(horizontalArrangement = Arrangement.spacedBy(StyledTheme.spacing.medium)) {
                    itemLeadingContent?.invoke(selected)
                    StyledText(itemText(selected))
                }
            },
            onOpen = { query = "" },
        ) { dialogItems, dialogState, padding, visuals ->
            Column(
                verticalArrangement = Arrangement.spacedBy(StyledTheme.spacing.medium),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(padding),
            ) {
                if (filter != null) {
                    StyledInput(
                        value = query,
                        onValueChange = { query = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { StyledText(filter.label ?: strings.filterOptions) },
                    )
                }
                Column(
                    verticalArrangement = Arrangement.spacedBy(StyledTheme.spacing.medium),
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                ) {
                    dialogItems.filter { filter?.test(query, it, itemText) != false }
                        .forEach { item ->
                            StyledListItem(
                                headline = { StyledText(itemText(item)) },
                                onClick = {
                                    onValueChange(item)
                                    dialogState.dismiss()
                                },
                                leading = itemLeadingContent?.let { leadingContent ->
                                    { leadingContent(item) }
                                },
                                actions = {
                                    StyledRadioButton(
                                        selected = selected == item,
                                        onClick = null,
                                        enabled = visuals.enabled,
                                    )
                                },
                                shape = effectiveShape,
                                enabled = visuals.enabled,
                                minHeight = visuals.style.item.minimumItemHeight,
                                contentPadding = visuals.style.item.contentPadding,
                                containerColor = visuals.style.item.colors.containerColor,
                                contentColor = visuals.style.item.colors.contentColor,
                                supportingColor = visuals.style.item.colors.supportingColor,
                            )
                        }
                }
            }
        }
    }
}

/** Multi-selection preference presented in a dialog or dropdown. */
@Composable
fun <T : Any> PreferenceListMultiSelect(
    items: List<T>,
    selected: MutableState<List<T>>,
    title: String,
    modifier: Modifier = Modifier,
    key: String? = null,
    subtitle: String? = null,
    icon: IconComposable? = null,
    presentation: PreferenceList.Presentation = PreferenceList.Presentation.Dialog,
    filter: PreferenceList.Filter<T>? = null,
    itemText: (T) -> String = { it.toString() },
    enabled: Boolean = true,
    filterTags: List<String> = emptyList(),
    isEnabled: @Composable () -> Boolean = { enabled },
    isVisible: @Composable () -> Boolean = { true },
    dropdownCustomization: StyledButton.Customization? = null,
    shape: Shape? = null,
    itemLeadingContent: (@Composable (T) -> Unit)? = null,
) {
    PreferenceListMultiSelect(
        items = items,
        selected = selected.value,
        onValueChange = { selected.value = it },
        title = title,
        modifier = modifier,
        key = key,
        subtitle = subtitle,
        icon = icon,
        presentation = presentation,
        filter = filter,
        itemText = itemText,
        enabled = enabled,
        filterTags = filterTags,
        isEnabled = isEnabled,
        isVisible = isVisible,
        dropdownCustomization = dropdownCustomization,
        shape = shape,
        itemLeadingContent = itemLeadingContent,
    )
}

/** Controlled multi-selection preference. */
@Composable
fun <T : Any> PreferenceListMultiSelect(
    items: List<T>,
    selected: List<T>,
    onValueChange: (List<T>) -> Unit,
    title: String,
    modifier: Modifier = Modifier,
    key: String? = null,
    subtitle: String? = null,
    icon: IconComposable? = null,
    presentation: PreferenceList.Presentation = PreferenceList.Presentation.Dialog,
    filter: PreferenceList.Filter<T>? = null,
    itemText: (T) -> String = { it.toString() },
    enabled: Boolean = true,
    filterTags: List<String> = emptyList(),
    isEnabled: @Composable () -> Boolean = { enabled },
    isVisible: @Composable () -> Boolean = { true },
    dropdownCustomization: StyledButton.Customization? = null,
    shape: Shape? = null,
    itemLeadingContent: (@Composable (T) -> Unit)? = null,
) {
    val dialog = rememberDialogState()
    val strings = LocalPreferenceStrings.current
    var draft by remember(selected) { mutableStateOf(selected) }
    var query by rememberSaveable { mutableStateOf("") }
    val dropdownExpanded = remember { mutableStateOf(false) }
    LaunchedEffect(dialog.visible, selected) {
        if (dialog.visible) draft = selected
    }
    val effectiveShape = checkNotNull(LocalPreferenceStyle.current).item.shape
    val selectedText = selected.joinToString(", ", transform = itemText)

    when (presentation) {
        is PreferenceList.Presentation.Dropdown -> PreferenceEntry(
            title = title,
            subtitle = subtitle ?: selectedText,
            filterTags = filterTags,
            key = key,
            isEnabled = isEnabled,
            isVisible = isVisible,
            breaksSectionShape = shape != null,
        ) { visuals ->
            PreferenceStyledRow(
                title = title,
                subtitle = subtitle,
                icon = icon,
                enabled = visuals.enabled,
                modifier = modifier,
                onClick =
                    if (presentation.clickBehavior ==
                        PreferenceList.Presentation.Dropdown.ClickBehavior.FullItem
                    ) {
                        { dropdownExpanded.value = true }
                    } else {
                        null
                    },
                style = visuals.style,
                insideSection = visuals.insideSection,
                breadcrumb = visuals.breadcrumb,
                shape = shape,
                trailing = {
                    val textStyle = LocalStyledTextStyle.current
                    val dropdownTextStyle = textStyle.copy(textAlign = TextAlign.Start)
                    val blockDropdownInteraction = presentation.clickBehavior ==
                        PreferenceList.Presentation.Dropdown.ClickBehavior.FullItem
                    PointerInputBlocker(blocked = blockDropdownInteraction) {
                        StyledPopupDropdownMultiSelect(
                            items = items,
                            selected = selected,
                            title = "",
                            modifier = Modifier,
                            enabled = visuals.enabled,
                            expanded = dropdownExpanded,
                            filter = filter?.toStyledFilter(itemText, strings.filterOptions),
                            variant = StyledButton.Variant.Plain,
                            customization = dropdownCustomization
                                ?: visuals.style.toDropdownCustomization(),
                            content = {
                                selection { selectedItems ->
                                    Row(horizontalArrangement = Arrangement.spacedBy(0.dp)) {
                                        selectedItems.forEachIndexed { index, item ->
                                            if (index > 0) {
                                                StyledText(", ", style = textStyle)
                                            }
                                            Row(
                                                horizontalArrangement = Arrangement.spacedBy(StyledTheme.spacing.medium),
                                            ) {
                                                itemLeadingContent?.invoke(item)
                                                StyledText(
                                                    itemText(item),
                                                    color = Color.Unspecified,
                                                    style = textStyle,
                                                    maxLines = 1,
                                                )
                                            }
                                        }
                                    }
                                }
                                item { item, isSelected ->
                                    PreferenceListDropdownItem(
                                        item = item,
                                        itemText = itemText,
                                        itemLeadingContent = itemLeadingContent,
                                        textStyle = dropdownTextStyle,
                                        selected = isSelected,
                                        modifier = Modifier.fillMaxWidth(),
                                    )
                                }
                            },
                            actions = StyledPopupDropdownMultiSelectDefaults.defaultActions(),
                            onSelectionChange = { _, next -> onValueChange(next) },
                            popupWidthConfig = StyledPopupMenu.WidthConfig.WrapContent,
                            popupHorizontalAlignment = StyledPopupMenu.HorizontalAlignment.End,
                        )
                    }
                },
            )
        }

        PreferenceList.Presentation.Dialog -> BaseDialogPreference(
            data = items,
            title = title,
            subtitle = subtitle ?: selectedText,
            displaySubtitle = subtitle,
            dialog = dialog,
            modifier = modifier,
            key = key,
            icon = icon,
            filterTags = filterTags,
            enabled = enabled,
            isEnabled = isEnabled,
            isVisible = isVisible,
            shape = shape,
            buttons = { visuals ->
                StyledDialog.Buttons(
                    positive = StyledDialog.Button(
                        onClick = { onValueChange(draft) },
                        label = strings.apply,
                        enabled = visuals.enabled,
                    ),
                    negative = StyledDialog.Button(
                        onClick = {},
                        label = strings.cancel,
                        enabled = visuals.enabled,
                    ),
                )
            },
            trailing = {
                Row(horizontalArrangement = Arrangement.spacedBy(0.dp)) {
                    selected.forEachIndexed { index, item ->
                        if (index > 0) {
                            StyledText(", ")
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(StyledTheme.spacing.medium)) {
                            itemLeadingContent?.invoke(item)
                            StyledText(itemText(item))
                        }
                    }
                }
            },
            onOpen = {
                draft = selected
                query = ""
            },
        ) { dialogItems, _, padding, visuals ->
            Column(
                verticalArrangement = Arrangement.spacedBy(StyledTheme.spacing.medium),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(padding),
            ) {
                if (filter != null) {
                    StyledInput(
                        value = query,
                        onValueChange = { query = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { StyledText(filter.label ?: strings.filterOptions) },
                    )
                }
                Column(
                    verticalArrangement = Arrangement.spacedBy(StyledTheme.spacing.medium),
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                ) {
                    dialogItems.filter { filter?.test(query, it, itemText) != false }
                        .forEach { item ->
                            val checked = item in draft
                            StyledListItem(
                                headline = { StyledText(itemText(item)) },
                                onClick = {
                                    draft = if (checked) {
                                        draft.filterNot { it == item }
                                    } else {
                                        draft + item
                                    }
                                },
                                enabled = visuals.enabled,
                                leading = itemLeadingContent?.let { leadingContent ->
                                    { leadingContent(item) }
                                },
                                actions = {
                                    StyledCheckbox(
                                        checked = checked,
                                        onCheckedChange = null,
                                        enabled = visuals.enabled,
                                    )
                                },
                                shape = effectiveShape,
                                minHeight = visuals.style.item.minimumItemHeight,
                                contentPadding = visuals.style.item.contentPadding,
                                containerColor = visuals.style.item.colors.containerColor,
                                contentColor = visuals.style.item.colors.contentColor,
                                supportingColor = visuals.style.item.colors.supportingColor,
                            )
                        }
                }
            }
        }
    }
}

private fun <T : Any> PreferenceList.Filter<T>.toStyledFilter(
    itemText: (T) -> String,
    label: String,
): StyledPopupDropdown.Filter<T> = StyledPopupDropdown.Filter(this.label ?: label) { query, item ->
    test(query, item, itemText)
}

private fun <T : Any> PreferenceList.Filter<T>.test(
    query: String,
    item: T,
    itemText: (T) -> String,
): Boolean = matches?.invoke(query, item) ?: itemText(item).contains(query, ignoreCase = true)

@Composable
private fun <T : Any> PreferenceListDropdownItem(
    item: T,
    itemText: (T) -> String,
    itemLeadingContent: (@Composable (T) -> Unit)?,
    textStyle: TextStyle,
    selected: Boolean = false,
    modifier: Modifier = Modifier,
) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(StyledTheme.spacing.medium),
        modifier = modifier,
    ) {
        itemLeadingContent?.invoke(item)
        StyledText(
            text = itemText(item),
            modifier = Modifier.weight(1f),
            color = if (selected) StyledTheme.colorScheme.primary else Color.Unspecified,
            fontWeight = if (selected && textStyle.fontWeight == null) {
                FontWeight.Bold
            } else {
                null
            },
            style = textStyle,
            maxLines = 1,
        )
    }
}

private fun PreferenceStyle.toDropdownCustomization(): StyledButton.Customization {
    val contentColor = trailingStyle.contentColor ?: item.colors.contentColor
    return StyledButtonDefaults.customize(
        CustomColors(
            filledBackground = item.colors.containerColor,
            filledForeground = contentColor,
            textForeground = contentColor,
        ),
    )
}
