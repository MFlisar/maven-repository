package com.michaelflisar.composedialogs.styled

import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.MutableState
import androidx.compose.ui.Modifier
import com.michaelflisar.composedialogs.dialogs.time.TimePicker
import com.michaelflisar.composedialogs.dialogs.time.TimePickerConfig
import com.michaelflisar.composedialogs.dialogs.time.TimePickerDefaults
import com.michaelflisar.composedialogs.dialogs.time.TimePickerTexts
import com.michaelflisar.composedialogs.styled.provider.TimeUIProviderImpl
import com.michaelflisar.composedialogs.styled.shared.withPositiveButtonEnabled
import com.michaelflisar.composestyled.ui.layout.StyledDialog
import com.michaelflisar.composestyled.ui.layout.StyledDialogDefaults
import com.michaelflisar.composestyled.ui.state.DialogState
import kotlinx.datetime.LocalTime

/** Shows the ComposeDialogs time picker in a Styled dialog. */
@Composable
fun DialogTime(
    state: DialogState,
    time: MutableState<LocalTime>,
    modifier: Modifier = Modifier,
    config: TimePickerConfig = TimePickerDefaults.config(),
    texts: TimePickerTexts = TimePickerDefaults.texts(),
    style: StyledDialog.Style = StyledDialogDefaults.style,
    properties: StyledDialog.Properties = StyledDialog.Properties(),
    title: (@Composable () -> Unit)? = null,
    icon: (@Composable () -> Unit)? = null,
    buttons: StyledDialog.Buttons = StyledDialog.Buttons(),
    onDismissRequest: () -> Unit = state::dismiss,
) {
    var isValid by remember { mutableStateOf(true) }
    StyledDialog(
        state = state,
        modifier = modifier,
        style = style,
        properties = properties,
        title = StyledDialogDefaults.title(icon, title),
        buttons = buttons.withPositiveButtonEnabled(isValid),
        onDismissRequest = onDismissRequest,
        content = StyledDialogDefaults.content {
            if (state.visible) {
                TimePicker(
                    time = time,
                    config = config,
                    texts = texts,
                    uiProvider = TimeUIProviderImpl,
                    onValidationChanged = { isValid = it },
                )
            }
        },
    )
}
