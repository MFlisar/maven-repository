package com.michaelflisar.composestyled.material3.components

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.PlainTooltip
import androidx.compose.material3.TooltipAnchorPosition
import androidx.compose.material3.TooltipBox
import androidx.compose.material3.TooltipDefaults
import androidx.compose.material3.rememberTooltipState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.michaelflisar.composestyled.material3.ProvideStyledLocals
import com.michaelflisar.composestyled.StyledTheme
import com.michaelflisar.composestyled.runtime.InternalComposeStyledApi
import com.michaelflisar.composestyled.ui.components.StyledTooltip
import com.michaelflisar.composestyled.ui.components.StyledTooltipState
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.collectLatest

@OptIn(ExperimentalMaterial3Api::class)
class Material3Tooltip internal constructor() : StyledTooltip.Implementation {

    override val defaults: StyledTooltip.Defaults
        @Composable get() {
            val shape = TooltipDefaults.plainTooltipContainerShape
            val containerColor = TooltipDefaults.plainTooltipContainerColor
            val contentColor = TooltipDefaults.plainTooltipContentColor
            val contentPadding = remember { PaddingValues(0.dp) }
            return remember(shape, containerColor, contentColor, contentPadding) {
                StyledTooltip.Defaults(
                    shape = shape,
                    containerColor = containerColor,
                    contentColor = contentColor,
                    maxWidth = TooltipDefaults.plainTooltipMaxWidth,
                    shadowElevation = 0.dp,
                    contentPadding = contentPadding,
                )
            }
        }

    companion object {

        // -------------
        // 1) create
        // -------------

        @Composable
        fun create(): Material3Tooltip = remember { Material3Tooltip() }
    }

    @OptIn(ExperimentalMaterial3Api::class, InternalComposeStyledApi::class)
    @Composable
    override fun Render(
        state: StyledTooltipState,
        enableUserInput: Boolean,
        focusable: Boolean,
        onDismissRequest: (() -> Unit)?,
        modifier: Modifier,
        shape: Shape,
        containerColor: Color,
        contentColor: Color,
        maxWidth: Dp,
        shadowElevation: Dp,
        contentPadding: PaddingValues,
        tooltip: @Composable () -> Unit,
        content: @Composable () -> Unit,
    ) {
        val tooltipState = rememberTooltipState(
            initialIsVisible = false,
            isPersistent = state.isPersistent,
        )
        LaunchedEffect(state, tooltipState) {
            snapshotFlow { state.isVisible }.collectLatest { isVisible ->
                if (isVisible) {
                    if (!tooltipState.isVisible) {
                        tooltipState.show()
                    }
                } else {
                    tooltipState.dismiss()
                }
            }
        }
        LaunchedEffect(state, tooltipState) {
            snapshotFlow { tooltipState.isVisible }.collect { isVisible ->
                state.updateVisibilityFromRenderer(isVisible)
            }
        }

        val positionProvider = TooltipDefaults.rememberTooltipPositionProvider(
            positioning = TooltipAnchorPosition.Above,
        )
        TooltipBox(
            positionProvider = positionProvider,
            tooltip = {
                PlainTooltip(
                    caretShape = null,
                    maxWidth = maxWidth,
                    shape = shape,
                    contentColor = contentColor,
                    containerColor = containerColor,
                    shadowElevation = shadowElevation,
                ) {
                    ProvideStyledLocals(
                        contentColor = contentColor,
                        textStyle = StyledTheme.typography.bodySmall,
                    ) {
                        Box(Modifier.padding(contentPadding)) {
                            tooltip()
                        }
                    }
                }
            },
            state = tooltipState,
            modifier = modifier,
            onDismissRequest = {
                state.dismiss()
                onDismissRequest?.invoke()
            },
            focusable = focusable,
            enableUserInput = enableUserInput,
            hasAction = false,
            content = content,
        )
    }
}
