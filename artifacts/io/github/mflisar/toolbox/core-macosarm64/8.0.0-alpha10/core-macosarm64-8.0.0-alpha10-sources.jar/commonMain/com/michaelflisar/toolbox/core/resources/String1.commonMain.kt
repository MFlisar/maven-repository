@file:OptIn(InternalResourceApi::class)

package com.michaelflisar.toolbox.core.resources

import kotlin.OptIn
import kotlin.String
import kotlin.collections.MutableMap
import org.jetbrains.compose.resources.InternalResourceApi
import org.jetbrains.compose.resources.LanguageQualifier
import org.jetbrains.compose.resources.ResourceContentHash
import org.jetbrains.compose.resources.ResourceItem
import org.jetbrains.compose.resources.StringResource

private const val MD: String = "composeResources/com.michaelflisar.toolbox.core.resources/"

@delegate:ResourceContentHash(884_451_613)
public val Res.string.settings_group_privacy: StringResource by lazy {
      StringResource("string:settings_group_privacy", "settings_group_privacy", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 7452, 46),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 6624, 42),
      ))
    }

@delegate:ResourceContentHash(-117_433_951)
public val Res.string.settings_group_style: StringResource by lazy {
      StringResource("string:settings_group_style", "settings_group_style", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 7499, 44),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 6667, 44),
      ))
    }

@delegate:ResourceContentHash(-533_708_928)
public val Res.string.settings_open_play_store: StringResource by lazy {
      StringResource("string:settings_open_play_store", "settings_open_play_store", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 7637, 48),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 6793, 48),
      ))
    }

@delegate:ResourceContentHash(-1_029_980_479)
public val Res.string.settings_open_play_store_details: StringResource by lazy {
      StringResource("string:settings_open_play_store_details", "settings_open_play_store_details", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 7544, 92),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 6712, 80),
      ))
    }

@delegate:ResourceContentHash(763_462_681)
public val Res.string.settings_privacy_policy: StringResource by lazy {
      StringResource("string:settings_privacy_policy", "settings_privacy_policy", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 7790, 59),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 6926, 51),
      ))
    }

@delegate:ResourceContentHash(1_534_040_488)
public val Res.string.settings_privacy_policy_details: StringResource by lazy {
      StringResource("string:settings_privacy_policy_details", "settings_privacy_policy_details", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 7686, 103),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 6842, 83),
      ))
    }

@delegate:ResourceContentHash(46_908_160)
public val Res.string.settings_pro_version: StringResource by lazy {
      StringResource("string:settings_pro_version", "settings_pro_version", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 8401, 40),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 7485, 40),
      ))
    }

@delegate:ResourceContentHash(852_342_286)
public val Res.string.settings_pro_version_already_pro: StringResource by lazy {
      StringResource("string:settings_pro_version_already_pro", "settings_pro_version_already_pro", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 7850, 144),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 6978, 132),
      ))
    }

@delegate:ResourceContentHash(352_511_360)
public val Res.string.settings_pro_version_clickable_free_title: StringResource by lazy {
      StringResource("string:settings_pro_version_clickable_free_title", "settings_pro_version_clickable_free_title", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 7995, 65),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 7111, 65),
      ))
    }

@delegate:ResourceContentHash(133_691_956)
public val Res.string.settings_pro_version_free_upgrade_hint: StringResource by lazy {
      StringResource("string:settings_pro_version_free_upgrade_hint", "settings_pro_version_free_upgrade_hint", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 8061, 98),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 7177, 86),
      ))
    }

@delegate:ResourceContentHash(352_511_360)
public val Res.string.settings_pro_version_is_free: StringResource by lazy {
      StringResource("string:settings_pro_version_is_free", "settings_pro_version_is_free", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 8160, 52),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 7264, 52),
      ))
    }

@delegate:ResourceContentHash(-1_400_315_107)
public val Res.string.settings_pro_version_is_pro_info: StringResource by lazy {
      StringResource("string:settings_pro_version_is_pro_info", "settings_pro_version_is_pro_info", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 8213, 136),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 7317, 116),
      ))
    }

@delegate:ResourceContentHash(-547_630_464)
public val Res.string.settings_pro_version_title: StringResource by lazy {
      StringResource("string:settings_pro_version_title", "settings_pro_version_title", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 8350, 50),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 7434, 50),
      ))
    }

@delegate:ResourceContentHash(-474_292_960)
public val Res.string.settings_restore_backup: StringResource by lazy {
      StringResource("string:settings_restore_backup", "settings_restore_backup", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 8442, 67),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 7526, 51),
      ))
    }

@delegate:ResourceContentHash(-198_748_159)
public val Res.string.settings_section_auto_backup: StringResource by lazy {
      StringResource("string:settings_section_auto_backup", "settings_section_auto_backup", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 8510, 52),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 7578, 48),
      ))
    }

@delegate:ResourceContentHash(-1_845_178_575)
public val Res.string.settings_section_manual_backup: StringResource by lazy {
      StringResource("string:settings_section_manual_backup", "settings_section_manual_backup", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 8563, 50),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 7627, 46),
      ))
    }

@delegate:ResourceContentHash(681_017_923)
public val Res.string.settings_section_more_settings: StringResource by lazy {
      StringResource("string:settings_section_more_settings", "settings_section_more_settings", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 8614, 66),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 7674, 58),
      ))
    }

@delegate:ResourceContentHash(-1_045_808_850)
public val Res.string.settings_section_theme_options: StringResource by lazy {
      StringResource("string:settings_section_theme_options", "settings_section_theme_options", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 8681, 50),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 7733, 50),
      ))
    }

@delegate:ResourceContentHash(830_302_194)
public val Res.string.settings_theme: StringResource by lazy {
      StringResource("string:settings_theme", "settings_theme", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 9024, 30),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 8072, 30),
      ))
    }

@delegate:ResourceContentHash(620_652_159)
public val Res.string.settings_theme_appearance: StringResource by lazy {
      StringResource("string:settings_theme_appearance", "settings_theme_appearance", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 8732, 49),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 7784, 57),
      ))
    }

@delegate:ResourceContentHash(1_532_394_696)
public val Res.string.settings_theme_collection: StringResource by lazy {
      StringResource("string:settings_theme_collection", "settings_theme_collection", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 8782, 45),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 7842, 49),
      ))
    }

@delegate:ResourceContentHash(-1_638_912_421)
public val Res.string.settings_theme_colors: StringResource by lazy {
      StringResource("string:settings_theme_colors", "settings_theme_colors", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 8828, 37),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 7892, 37),
      ))
    }

@delegate:ResourceContentHash(623_076_753)
public val Res.string.settings_theme_details: StringResource by lazy {
      StringResource("string:settings_theme_details", "settings_theme_details", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 8866, 114),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 7930, 98),
      ))
    }

@delegate:ResourceContentHash(62_311_890)
public val Res.string.settings_theme_variant: StringResource by lazy {
      StringResource("string:settings_theme_variant", "settings_theme_variant", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 8981, 42),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 8029, 42),
      ))
    }

@delegate:ResourceContentHash(-873_154_248)
public val Res.string.settings_toolbar_style: StringResource by lazy {
      StringResource("string:settings_toolbar_style", "settings_toolbar_style", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 9055, 46),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 8103, 50),
      ))
    }

@delegate:ResourceContentHash(-1_949_493_021)
public val Res.string.settings_version: StringResource by lazy {
      StringResource("string:settings_version", "settings_version", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 9102, 44),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 8154, 40),
      ))
    }

@delegate:ResourceContentHash(-1_208_808_197)
public val Res.string.theme_dark: StringResource by lazy {
      StringResource("string:theme_dark", "theme_dark", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 9147, 26),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 8195, 26),
      ))
    }

@delegate:ResourceContentHash(-251_661_480)
public val Res.string.theme_light: StringResource by lazy {
      StringResource("string:theme_light", "theme_light", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 9174, 27),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 8222, 27),
      ))
    }

@delegate:ResourceContentHash(-631_594_592)
public val Res.string.theme_system: StringResource by lazy {
      StringResource("string:theme_system", "theme_system", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 9202, 28),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 8250, 28),
      ))
    }

@delegate:ResourceContentHash(1_490_176_740)
public val Res.string.theme_variant_colorful: StringResource by lazy {
      StringResource("string:theme_variant_colorful", "theme_variant_colorful", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 9231, 38),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 8279, 42),
      ))
    }

@delegate:ResourceContentHash(1_284_753_719)
public val Res.string.theme_variant_monochrome: StringResource by lazy {
      StringResource("string:theme_variant_monochrome", "theme_variant_monochrome", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 9270, 44),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 8322, 48),
      ))
    }

@delegate:ResourceContentHash(1_979_852_325)
public val Res.string.toolbar_mode_background: StringResource by lazy {
      StringResource("string:toolbar_mode_background", "toolbar_mode_background", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 9315, 55),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 8371, 55),
      ))
    }

@delegate:ResourceContentHash(-1_299_417_330)
public val Res.string.toolbar_mode_black: StringResource by lazy {
      StringResource("string:toolbar_mode_black", "toolbar_mode_black", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 9371, 38),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 8427, 34),
      ))
    }

@delegate:ResourceContentHash(-1_439_526_515)
public val Res.string.toolbar_mode_primary: StringResource by lazy {
      StringResource("string:toolbar_mode_primary", "toolbar_mode_primary", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 9410, 48),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 8462, 48),
      ))
    }

@InternalResourceApi
internal fun _collectCommonMainString1Resources(map: MutableMap<String, StringResource>) {
  map.put("settings_group_privacy", Res.string.settings_group_privacy)
  map.put("settings_group_style", Res.string.settings_group_style)
  map.put("settings_open_play_store", Res.string.settings_open_play_store)
  map.put("settings_open_play_store_details", Res.string.settings_open_play_store_details)
  map.put("settings_privacy_policy", Res.string.settings_privacy_policy)
  map.put("settings_privacy_policy_details", Res.string.settings_privacy_policy_details)
  map.put("settings_pro_version", Res.string.settings_pro_version)
  map.put("settings_pro_version_already_pro", Res.string.settings_pro_version_already_pro)
  map.put("settings_pro_version_clickable_free_title", Res.string.settings_pro_version_clickable_free_title)
  map.put("settings_pro_version_free_upgrade_hint", Res.string.settings_pro_version_free_upgrade_hint)
  map.put("settings_pro_version_is_free", Res.string.settings_pro_version_is_free)
  map.put("settings_pro_version_is_pro_info", Res.string.settings_pro_version_is_pro_info)
  map.put("settings_pro_version_title", Res.string.settings_pro_version_title)
  map.put("settings_restore_backup", Res.string.settings_restore_backup)
  map.put("settings_section_auto_backup", Res.string.settings_section_auto_backup)
  map.put("settings_section_manual_backup", Res.string.settings_section_manual_backup)
  map.put("settings_section_more_settings", Res.string.settings_section_more_settings)
  map.put("settings_section_theme_options", Res.string.settings_section_theme_options)
  map.put("settings_theme", Res.string.settings_theme)
  map.put("settings_theme_appearance", Res.string.settings_theme_appearance)
  map.put("settings_theme_collection", Res.string.settings_theme_collection)
  map.put("settings_theme_colors", Res.string.settings_theme_colors)
  map.put("settings_theme_details", Res.string.settings_theme_details)
  map.put("settings_theme_variant", Res.string.settings_theme_variant)
  map.put("settings_toolbar_style", Res.string.settings_toolbar_style)
  map.put("settings_version", Res.string.settings_version)
  map.put("theme_dark", Res.string.theme_dark)
  map.put("theme_light", Res.string.theme_light)
  map.put("theme_system", Res.string.theme_system)
  map.put("theme_variant_colorful", Res.string.theme_variant_colorful)
  map.put("theme_variant_monochrome", Res.string.theme_variant_monochrome)
  map.put("toolbar_mode_background", Res.string.toolbar_mode_background)
  map.put("toolbar_mode_black", Res.string.toolbar_mode_black)
  map.put("toolbar_mode_primary", Res.string.toolbar_mode_primary)
}
