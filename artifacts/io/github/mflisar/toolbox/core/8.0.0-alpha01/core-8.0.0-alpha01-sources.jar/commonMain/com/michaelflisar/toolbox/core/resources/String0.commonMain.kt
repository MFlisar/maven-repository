@file:OptIn(InternalResourceApi::class)

package com.michaelflisar.toolbox.core.resources

import kotlin.OptIn
import kotlin.String
import kotlin.collections.MutableMap
import org.jetbrains.compose.resources.InternalResourceApi
import org.jetbrains.compose.resources.LanguageQualifier
import org.jetbrains.compose.resources.ResourceContentHash
import org.jetbrains.compose.resources.ResourceItem
import org.jetbrains.compose.resources.StringResource

private const val MD: String = "composeResources/com.michaelflisar.toolbox.core.resources/"

@delegate:ResourceContentHash(1_850_003_945)
public val Res.string.backup_dialog_create_document_activity_not_found_info: StringResource by
    lazy {
      StringResource("string:backup_dialog_create_document_activity_not_found_info", "backup_dialog_create_document_activity_not_found_info", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 10, 437),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 10, 345),
      ))
    }

@delegate:ResourceContentHash(415_926_306)
public val Res.string.backup_dialog_create_document_activity_not_found_title: StringResource by
    lazy {
      StringResource("string:backup_dialog_create_document_activity_not_found_title", "backup_dialog_create_document_activity_not_found_title", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 448, 102),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 356, 86),
      ))
    }

@delegate:ResourceContentHash(1_801_960_204)
public val Res.string.backup_dialog_open_document_activity_not_found_info: StringResource by lazy {
      StringResource("string:backup_dialog_open_document_activity_not_found_info", "backup_dialog_open_document_activity_not_found_info", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 551, 431),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 443, 343),
      ))
    }

@delegate:ResourceContentHash(-797_763_864)
public val Res.string.backup_dialog_open_document_activity_not_found_title: StringResource by lazy {
      StringResource("string:backup_dialog_open_document_activity_not_found_title", "backup_dialog_open_document_activity_not_found_title", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 983, 100),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 787, 84),
      ))
    }

@delegate:ResourceContentHash(1_333_531_016)
public val Res.string.backup_done: StringResource by lazy {
      StringResource("string:backup_done", "backup_done", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1084, 31),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 872, 27),
      ))
    }

@delegate:ResourceContentHash(945_634_191)
public val Res.string.backup_error: StringResource by lazy {
      StringResource("string:backup_error", "backup_error", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1116, 36),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 900, 36),
      ))
    }

@delegate:ResourceContentHash(-1_361_049_216)
public val Res.string.backup_export: StringResource by lazy {
      StringResource("string:backup_export", "backup_export", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1198, 29),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 978, 29),
      ))
    }

@delegate:ResourceContentHash(220_563_103)
public val Res.string.backup_exporting: StringResource by lazy {
      StringResource("string:backup_exporting", "backup_exporting", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1153, 44),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 937, 40),
      ))
    }

@delegate:ResourceContentHash(1_391_261_728)
public val Res.string.backup_import: StringResource by lazy {
      StringResource("string:backup_import", "backup_import", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1273, 29),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1049, 29),
      ))
    }

@delegate:ResourceContentHash(59_885_503)
public val Res.string.backup_importing: StringResource by lazy {
      StringResource("string:backup_importing", "backup_importing", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1228, 44),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1008, 40),
      ))
    }

@delegate:ResourceContentHash(747_720_467)
public val Res.string.backup_select_file: StringResource by lazy {
      StringResource("string:backup_select_file", "backup_select_file", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1303, 46),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1079, 42),
      ))
    }

@delegate:ResourceContentHash(-850_159_080)
public val Res.string.backup_waiting_for_file: StringResource by lazy {
      StringResource("string:backup_waiting_for_file", "backup_waiting_for_file", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1350, 95),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1122, 79),
      ))
    }

@delegate:ResourceContentHash(324_824_862)
public val Res.string.button_cancel: StringResource by lazy {
      StringResource("string:button_cancel", "button_cancel", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1446, 33),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1202, 29),
      ))
    }

@delegate:ResourceContentHash(1_879_537_469)
public val Res.string.button_close: StringResource by lazy {
      StringResource("string:button_close", "button_close", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1480, 36),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1232, 28),
      ))
    }

@delegate:ResourceContentHash(1_804_059_142)
public val Res.string.button_no: StringResource by lazy {
      StringResource("string:button_no", "button_no", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1517, 25),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1261, 21),
      ))
    }

@delegate:ResourceContentHash(81_670_336)
public val Res.string.button_ok: StringResource by lazy {
      StringResource("string:button_ok", "button_ok", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1543, 21),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1283, 21),
      ))
    }

@delegate:ResourceContentHash(82_645_874)
public val Res.string.button_yes: StringResource by lazy {
      StringResource("string:button_yes", "button_yes", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1565, 22),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1305, 22),
      ))
    }

@delegate:ResourceContentHash(2_074_099_281)
public val Res.string.contrast_high: StringResource by lazy {
      StringResource("string:contrast_high", "contrast_high", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1588, 29),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1328, 29),
      ))
    }

@delegate:ResourceContentHash(1_167_716_518)
public val Res.string.contrast_medium: StringResource by lazy {
      StringResource("string:contrast_medium", "contrast_medium", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1618, 31),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1358, 31),
      ))
    }

@delegate:ResourceContentHash(-2_136_677_536)
public val Res.string.contrast_normal: StringResource by lazy {
      StringResource("string:contrast_normal", "contrast_normal", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1650, 31),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1390, 31),
      ))
    }

@delegate:ResourceContentHash(1_190_233_503)
public val Res.string.dlg_getting_pro_error_info: StringResource by lazy {
      StringResource("string:dlg_getting_pro_error_info", "dlg_getting_pro_error_info", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1682, 182),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1422, 134),
      ))
    }

@delegate:ResourceContentHash(970_559_495)
public val Res.string.dlg_pro_version_info: StringResource by lazy {
      StringResource("string:dlg_pro_version_info", "dlg_pro_version_info", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 2145, 152),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1833, 140),
      ))
    }

@delegate:ResourceContentHash(1_608_915_567)
public val Res.string.dlg_pro_version_info_already_bought: StringResource by lazy {
      StringResource("string:dlg_pro_version_info_already_bought", "dlg_pro_version_info_already_bought", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1865, 143),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1557, 135),
      ))
    }

@delegate:ResourceContentHash(1_014_854_258)
public val Res.string.dlg_pro_version_info_bought: StringResource by lazy {
      StringResource("string:dlg_pro_version_info_bought", "dlg_pro_version_info_bought", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 2009, 135),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1693, 139),
      ))
    }

@delegate:ResourceContentHash(46_334_286)
public val Res.string.dlg_pro_version_item_owned: StringResource by lazy {
      StringResource("string:dlg_pro_version_item_owned", "dlg_pro_version_item_owned", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 2298, 82),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1974, 70),
      ))
    }

@delegate:ResourceContentHash(1_292_028_446)
public val Res.string.dlg_pro_version_purchase: StringResource by lazy {
      StringResource("string:dlg_pro_version_purchase", "dlg_pro_version_purchase", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 2520, 64),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 2164, 52),
      ))
    }

@delegate:ResourceContentHash(1_602_213_390)
public val Res.string.dlg_pro_version_purchase_error: StringResource by lazy {
      StringResource("string:dlg_pro_version_purchase_error", "dlg_pro_version_purchase_error", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 2381, 138),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 2045, 118),
      ))
    }

@delegate:ResourceContentHash(502_621_064)
public val Res.string.dlg_pro_version_restore_purchases: StringResource by lazy {
      StringResource("string:dlg_pro_version_restore_purchases", "dlg_pro_version_restore_purchases", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 2585, 73),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 2217, 65),
      ))
    }

@delegate:ResourceContentHash(80_731_272)
public val Res.string.dlg_pro_version_retry_loading_data: StringResource by lazy {
      StringResource("string:dlg_pro_version_retry_loading_data", "dlg_pro_version_retry_loading_data", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 2659, 70),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 2283, 66),
      ))
    }

@delegate:ResourceContentHash(1_646_699_168)
public val Res.string.error_invalid_input: StringResource by lazy {
      StringResource("string:error_invalid_input", "error_invalid_input", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 2730, 51),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 2350, 47),
      ))
    }

@delegate:ResourceContentHash(508_088_416)
public val Res.string.error_invalid_length: StringResource by lazy {
      StringResource("string:error_invalid_length", "error_invalid_length", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 2782, 52),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 2398, 48),
      ))
    }

@delegate:ResourceContentHash(-787_192_253)
public val Res.string.error_too_high: StringResource by lazy {
      StringResource("string:error_too_high", "error_too_high", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 2835, 38),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 2447, 34),
      ))
    }

@delegate:ResourceContentHash(-2_135_420_760)
public val Res.string.error_too_low: StringResource by lazy {
      StringResource("string:error_too_low", "error_too_low", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 2874, 41),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 2482, 33),
      ))
    }

@delegate:ResourceContentHash(2_071_668_950)
public val Res.string.feedback_dialog_email_info: StringResource by lazy {
      StringResource("string:feedback_dialog_email_info", "feedback_dialog_email_info", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 2916, 122),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 2516, 106),
      ))
    }

@delegate:ResourceContentHash(1_007_411_395)
public val Res.string.feedback_dialog_open_email: StringResource by lazy {
      StringResource("string:feedback_dialog_open_email", "feedback_dialog_open_email", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 3039, 54),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 2623, 54),
      ))
    }

@delegate:ResourceContentHash(1_658_679_058)
public val Res.string.info_gdpr_reset: StringResource by lazy {
      StringResource("string:info_gdpr_reset", "info_gdpr_reset", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 3094, 71),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 2678, 55),
      ))
    }

@delegate:ResourceContentHash(-1_018_944_191)
public val Res.string.info_getting_pro_cancelled: StringResource by lazy {
      StringResource("string:info_getting_pro_cancelled", "info_getting_pro_cancelled", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 3166, 82),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 2734, 74),
      ))
    }

@delegate:ResourceContentHash(970_395_119)
public val Res.string.menu_copy: StringResource by lazy {
      StringResource("string:menu_copy", "menu_copy", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 3249, 29),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 2809, 25),
      ))
    }

@delegate:ResourceContentHash(1_895_062_480)
public val Res.string.menu_cut: StringResource by lazy {
      StringResource("string:menu_cut", "menu_cut", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 3279, 32),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 2835, 20),
      ))
    }

@delegate:ResourceContentHash(1_219_545_176)
public val Res.string.menu_delete: StringResource by lazy {
      StringResource("string:menu_delete", "menu_delete", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 3312, 31),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 2856, 27),
      ))
    }

@delegate:ResourceContentHash(-1_496_173_149)
public val Res.string.menu_deselect_all: StringResource by lazy {
      StringResource("string:menu_deselect_all", "menu_deselect_all", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 3344, 53),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 2884, 41),
      ))
    }

@delegate:ResourceContentHash(-736_813_042)
public val Res.string.menu_duplicate: StringResource by lazy {
      StringResource("string:menu_duplicate", "menu_duplicate", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 3398, 38),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 2926, 34),
      ))
    }

@delegate:ResourceContentHash(-682_128_971)
public val Res.string.menu_go_pro: StringResource by lazy {
      StringResource("string:menu_go_pro", "menu_go_pro", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 3437, 51),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 2961, 39),
      ))
    }

@delegate:ResourceContentHash(1_561_339_049)
public val Res.string.menu_invert_selection: StringResource by lazy {
      StringResource("string:menu_invert_selection", "menu_invert_selection", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 3489, 57),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 3001, 53),
      ))
    }

@delegate:ResourceContentHash(-191_386_854)
public val Res.string.menu_more: StringResource by lazy {
      StringResource("string:menu_more", "menu_more", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 3547, 25),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 3055, 25),
      ))
    }

@delegate:ResourceContentHash(-1_979_721_638)
public val Res.string.menu_move: StringResource by lazy {
      StringResource("string:menu_move", "menu_move", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 3573, 33),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 3081, 25),
      ))
    }

@delegate:ResourceContentHash(-2_034_642_682)
public val Res.string.menu_region_selection: StringResource by lazy {
      StringResource("string:menu_region_selection", "menu_region_selection", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 3607, 41),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 3107, 41),
      ))
    }

@delegate:ResourceContentHash(793_320_902)
public val Res.string.menu_select_all: StringResource by lazy {
      StringResource("string:menu_select_all", "menu_select_all", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 3649, 47),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 3149, 39),
      ))
    }

@delegate:ResourceContentHash(1_888_768_318)
public val Res.string.menu_settings: StringResource by lazy {
      StringResource("string:menu_settings", "menu_settings", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 3697, 41),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 3189, 33),
      ))
    }

@delegate:ResourceContentHash(1_666_881_888)
public val Res.string.placeholder_ads: StringResource by lazy {
      StringResource("string:placeholder_ads", "placeholder_ads", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 3739, 35),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 3223, 43),
      ))
    }

@delegate:ResourceContentHash(-1_964_023_100)
public val Res.string.range_from: StringResource by lazy {
      StringResource("string:range_from", "range_from", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 3775, 22),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 3267, 26),
      ))
    }

@delegate:ResourceContentHash(80_792_044)
public val Res.string.range_to: StringResource by lazy {
      StringResource("string:range_to", "range_to", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 3798, 20),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 3294, 20),
      ))
    }

@delegate:ResourceContentHash(142_553_768)
public val Res.string.settings_auto_backup_choose_folder: StringResource by lazy {
      StringResource("string:settings_auto_backup_choose_folder", "settings_auto_backup_choose_folder", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 3819, 110),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 3315, 94),
      ))
    }

@delegate:ResourceContentHash(637_282_182)
public val Res.string.settings_auto_backup_disable: StringResource by lazy {
      StringResource("string:settings_auto_backup_disable", "settings_auto_backup_disable", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 3930, 84),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 3410, 68),
      ))
    }

@delegate:ResourceContentHash(25_830_874)
public val Res.string.settings_auto_backup_enable: StringResource by lazy {
      StringResource("string:settings_auto_backup_enable", "settings_auto_backup_enable", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 4015, 79),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 3479, 67),
      ))
    }

@delegate:ResourceContentHash(-933_579_575)
public val Res.string.settings_auto_backup_folder: StringResource by lazy {
      StringResource("string:settings_auto_backup_folder", "settings_auto_backup_folder", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 4095, 59),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 3547, 55),
      ))
    }

@delegate:ResourceContentHash(-755_440_183)
public val Res.string.settings_auto_backup_frequency: StringResource by lazy {
      StringResource("string:settings_auto_backup_frequency", "settings_auto_backup_frequency", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 4155, 54),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 3603, 50),
      ))
    }

@delegate:ResourceContentHash(850_106_586)
public val Res.string.settings_auto_backup_info_details: StringResource by lazy {
      StringResource("string:settings_auto_backup_info_details", "settings_auto_backup_info_details", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 4210, 129),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 3654, 105),
      ))
    }

@delegate:ResourceContentHash(1_961_287_069)
public val Res.string.settings_auto_backup_info_title: StringResource by lazy {
      StringResource("string:settings_auto_backup_info_title", "settings_auto_backup_info_title", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 4340, 71),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 3760, 63),
      ))
    }

@delegate:ResourceContentHash(724_837_565)
public val Res.string.settings_change_language: StringResource by lazy {
      StringResource("string:settings_change_language", "settings_change_language", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 4412, 52),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 3824, 52),
      ))
    }

@delegate:ResourceContentHash(303_879_372)
public val Res.string.settings_changelog: StringResource by lazy {
      StringResource("string:settings_changelog", "settings_changelog", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 4465, 54),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 3877, 38),
      ))
    }

@delegate:ResourceContentHash(358_054_029)
public val Res.string.settings_consent_settings: StringResource by lazy {
      StringResource("string:settings_consent_settings", "settings_consent_settings", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 4520, 97),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 3916, 73),
      ))
    }

@delegate:ResourceContentHash(1_773_129_826)
public val Res.string.settings_contrast: StringResource by lazy {
      StringResource("string:settings_contrast", "settings_contrast", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 4618, 37),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 3990, 37),
      ))
    }

@delegate:ResourceContentHash(-874_721_454)
public val Res.string.settings_create_backup: StringResource by lazy {
      StringResource("string:settings_create_backup", "settings_create_backup", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 4656, 58),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 4028, 50),
      ))
    }

@delegate:ResourceContentHash(1_158_627_232)
public val Res.string.settings_developer_by_name: StringResource by lazy {
      StringResource("string:settings_developer_by_name", "settings_developer_by_name", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 4715, 46),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 4079, 46),
      ))
    }

@delegate:ResourceContentHash(1_133_906_988)
public val Res.string.settings_dialog_attach_log_file_details: StringResource by lazy {
      StringResource("string:settings_dialog_attach_log_file_details", "settings_dialog_attach_log_file_details", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 4762, 135),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 4126, 127),
      ))
    }

@delegate:ResourceContentHash(1_192_328_944)
public val Res.string.settings_dialog_attach_log_file_label: StringResource by lazy {
      StringResource("string:settings_dialog_attach_log_file_label", "settings_dialog_attach_log_file_label", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 4898, 73),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 4254, 65),
      ))
    }

@delegate:ResourceContentHash(2_086_448_825)
public val Res.string.settings_dynamic_theme: StringResource by lazy {
      StringResource("string:settings_dynamic_theme", "settings_dynamic_theme", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 5397, 54),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 4717, 50),
      ))
    }

@delegate:ResourceContentHash(1_464_346_184)
public val Res.string.settings_dynamic_theme_details: StringResource by lazy {
      StringResource("string:settings_dynamic_theme_details", "settings_dynamic_theme_details", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 4972, 150),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 4320, 122),
      ))
    }

@delegate:ResourceContentHash(393_363_843)
public val Res.string.settings_dynamic_theme_selection_info_details: StringResource by lazy {
      StringResource("string:settings_dynamic_theme_selection_info_details", "settings_dynamic_theme_selection_info_details", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 5123, 173),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 4443, 173),
      ))
    }

@delegate:ResourceContentHash(2_062_507_825)
public val Res.string.settings_dynamic_theme_selection_info_title: StringResource by lazy {
      StringResource("string:settings_dynamic_theme_selection_info_title", "settings_dynamic_theme_selection_info_title", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 5297, 99),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 4617, 99),
      ))
    }

@delegate:ResourceContentHash(-537_852_960)
public val Res.string.settings_feedback: StringResource by lazy {
      StringResource("string:settings_feedback", "settings_feedback", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 5586, 37),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 4886, 37),
      ))
    }

@delegate:ResourceContentHash(-2_034_825_781)
public val Res.string.settings_feedback_details: StringResource by lazy {
      StringResource("string:settings_feedback_details", "settings_feedback_details", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 5452, 133),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 4768, 117),
      ))
    }

@delegate:ResourceContentHash(1_589_826_816)
public val Res.string.settings_filter_themes_label: StringResource by lazy {
      StringResource("string:settings_filter_themes_label", "settings_filter_themes_label", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 5624, 44),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 4924, 44),
      ))
    }

@delegate:ResourceContentHash(-602_794_496)
public val Res.string.settings_filter_themes_placeholder: StringResource by lazy {
      StringResource("string:settings_filter_themes_placeholder", "settings_filter_themes_placeholder", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 5669, 66),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 4969, 66),
      ))
    }

@delegate:ResourceContentHash(927_697_611)
public val Res.string.settings_gdpr_consent: StringResource by lazy {
      StringResource("string:settings_gdpr_consent", "settings_gdpr_consent", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 5912, 57),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 5188, 45),
      ))
    }

@delegate:ResourceContentHash(-2_126_053_173)
public val Res.string.settings_gdpr_consent_details: StringResource by lazy {
      StringResource("string:settings_gdpr_consent_details", "settings_gdpr_consent_details", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 5736, 81),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 5036, 73),
      ))
    }

@delegate:ResourceContentHash(1_891_779_751)
public val Res.string.settings_gdpr_consent_show_dialog: StringResource by lazy {
      StringResource("string:settings_gdpr_consent_show_dialog", "settings_gdpr_consent_show_dialog", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 5818, 93),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 5110, 77),
      ))
    }

@delegate:ResourceContentHash(1_326_805_841)
public val Res.string.settings_group_about: StringResource by lazy {
      StringResource("string:settings_group_about", "settings_group_about", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 5970, 36),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 5234, 36),
      ))
    }

@delegate:ResourceContentHash(1_260_215_268)
public val Res.string.settings_group_auto_backup: StringResource by lazy {
      StringResource("string:settings_group_auto_backup", "settings_group_auto_backup", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 6007, 66),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 5271, 58),
      ))
    }

@delegate:ResourceContentHash(-1_272_357_103)
public val Res.string.settings_group_backup: StringResource by lazy {
      StringResource("string:settings_group_backup", "settings_group_backup", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 6074, 45),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 5330, 41),
      ))
    }

@delegate:ResourceContentHash(918_067_971)
public val Res.string.settings_group_consent: StringResource by lazy {
      StringResource("string:settings_group_consent", "settings_group_consent", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 6183, 50),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 5435, 42),
      ))
    }

@delegate:ResourceContentHash(-271_263_336)
public val Res.string.settings_group_consent_details: StringResource by lazy {
      StringResource("string:settings_group_consent_details", "settings_group_consent_details", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 6120, 62),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 5372, 62),
      ))
    }

@delegate:ResourceContentHash(-257_404_473)
public val Res.string.settings_group_infos: StringResource by lazy {
      StringResource("string:settings_group_infos", "settings_group_infos", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 6331, 44),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 5559, 44),
      ))
    }

@delegate:ResourceContentHash(623_042_386)
public val Res.string.settings_group_infos_details: StringResource by lazy {
      StringResource("string:settings_group_infos_details", "settings_group_infos_details", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 6234, 96),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 5478, 80),
      ))
    }

@delegate:ResourceContentHash(1_447_793_218)
public val Res.string.settings_group_language: StringResource by lazy {
      StringResource("string:settings_group_language", "settings_group_language", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 6376, 43),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 5604, 43),
      ))
    }

@delegate:ResourceContentHash(-1_525_857_167)
public val Res.string.settings_group_manual_backup: StringResource by lazy {
      StringResource("string:settings_group_manual_backup", "settings_group_manual_backup", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 6420, 64),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 5648, 56),
      ))
    }

@delegate:ResourceContentHash(1_860_254_567)
public val Res.string.settings_group_others: StringResource by lazy {
      StringResource("string:settings_group_others", "settings_group_others", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 6547, 41),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 5763, 37),
      ))
    }

@delegate:ResourceContentHash(-263_529_095)
public val Res.string.settings_group_others_details: StringResource by lazy {
      StringResource("string:settings_group_others_details", "settings_group_others_details", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 6485, 61),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 5705, 57),
      ))
    }

@delegate:ResourceContentHash(884_451_613)
public val Res.string.settings_group_privacy: StringResource by lazy {
      StringResource("string:settings_group_privacy", "settings_group_privacy", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 6589, 46),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 5801, 42),
      ))
    }

@delegate:ResourceContentHash(-117_433_951)
public val Res.string.settings_group_style: StringResource by lazy {
      StringResource("string:settings_group_style", "settings_group_style", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 6636, 44),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 5844, 44),
      ))
    }

@delegate:ResourceContentHash(-533_708_928)
public val Res.string.settings_open_play_store: StringResource by lazy {
      StringResource("string:settings_open_play_store", "settings_open_play_store", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 6774, 48),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 5970, 48),
      ))
    }

@delegate:ResourceContentHash(-1_029_980_479)
public val Res.string.settings_open_play_store_details: StringResource by lazy {
      StringResource("string:settings_open_play_store_details", "settings_open_play_store_details", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 6681, 92),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 5889, 80),
      ))
    }

@delegate:ResourceContentHash(763_462_681)
public val Res.string.settings_privacy_policy: StringResource by lazy {
      StringResource("string:settings_privacy_policy", "settings_privacy_policy", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 6927, 59),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 6103, 51),
      ))
    }

@delegate:ResourceContentHash(1_534_040_488)
public val Res.string.settings_privacy_policy_details: StringResource by lazy {
      StringResource("string:settings_privacy_policy_details", "settings_privacy_policy_details", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 6823, 103),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 6019, 83),
      ))
    }

@delegate:ResourceContentHash(46_908_160)
public val Res.string.settings_pro_version: StringResource by lazy {
      StringResource("string:settings_pro_version", "settings_pro_version", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 7538, 40),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 6662, 40),
      ))
    }

@delegate:ResourceContentHash(852_342_286)
public val Res.string.settings_pro_version_already_pro: StringResource by lazy {
      StringResource("string:settings_pro_version_already_pro", "settings_pro_version_already_pro", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 6987, 144),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 6155, 132),
      ))
    }

@delegate:ResourceContentHash(352_511_360)
public val Res.string.settings_pro_version_clickable_free_title: StringResource by lazy {
      StringResource("string:settings_pro_version_clickable_free_title", "settings_pro_version_clickable_free_title", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 7132, 65),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 6288, 65),
      ))
    }

@delegate:ResourceContentHash(133_691_956)
public val Res.string.settings_pro_version_free_upgrade_hint: StringResource by lazy {
      StringResource("string:settings_pro_version_free_upgrade_hint", "settings_pro_version_free_upgrade_hint", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 7198, 98),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 6354, 86),
      ))
    }

@delegate:ResourceContentHash(352_511_360)
public val Res.string.settings_pro_version_is_free: StringResource by lazy {
      StringResource("string:settings_pro_version_is_free", "settings_pro_version_is_free", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 7297, 52),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 6441, 52),
      ))
    }

@InternalResourceApi
internal fun _collectCommonMainString0Resources(map: MutableMap<String, StringResource>) {
  map.put("backup_dialog_create_document_activity_not_found_info", Res.string.backup_dialog_create_document_activity_not_found_info)
  map.put("backup_dialog_create_document_activity_not_found_title", Res.string.backup_dialog_create_document_activity_not_found_title)
  map.put("backup_dialog_open_document_activity_not_found_info", Res.string.backup_dialog_open_document_activity_not_found_info)
  map.put("backup_dialog_open_document_activity_not_found_title", Res.string.backup_dialog_open_document_activity_not_found_title)
  map.put("backup_done", Res.string.backup_done)
  map.put("backup_error", Res.string.backup_error)
  map.put("backup_export", Res.string.backup_export)
  map.put("backup_exporting", Res.string.backup_exporting)
  map.put("backup_import", Res.string.backup_import)
  map.put("backup_importing", Res.string.backup_importing)
  map.put("backup_select_file", Res.string.backup_select_file)
  map.put("backup_waiting_for_file", Res.string.backup_waiting_for_file)
  map.put("button_cancel", Res.string.button_cancel)
  map.put("button_close", Res.string.button_close)
  map.put("button_no", Res.string.button_no)
  map.put("button_ok", Res.string.button_ok)
  map.put("button_yes", Res.string.button_yes)
  map.put("contrast_high", Res.string.contrast_high)
  map.put("contrast_medium", Res.string.contrast_medium)
  map.put("contrast_normal", Res.string.contrast_normal)
  map.put("dlg_getting_pro_error_info", Res.string.dlg_getting_pro_error_info)
  map.put("dlg_pro_version_info", Res.string.dlg_pro_version_info)
  map.put("dlg_pro_version_info_already_bought", Res.string.dlg_pro_version_info_already_bought)
  map.put("dlg_pro_version_info_bought", Res.string.dlg_pro_version_info_bought)
  map.put("dlg_pro_version_item_owned", Res.string.dlg_pro_version_item_owned)
  map.put("dlg_pro_version_purchase", Res.string.dlg_pro_version_purchase)
  map.put("dlg_pro_version_purchase_error", Res.string.dlg_pro_version_purchase_error)
  map.put("dlg_pro_version_restore_purchases", Res.string.dlg_pro_version_restore_purchases)
  map.put("dlg_pro_version_retry_loading_data", Res.string.dlg_pro_version_retry_loading_data)
  map.put("error_invalid_input", Res.string.error_invalid_input)
  map.put("error_invalid_length", Res.string.error_invalid_length)
  map.put("error_too_high", Res.string.error_too_high)
  map.put("error_too_low", Res.string.error_too_low)
  map.put("feedback_dialog_email_info", Res.string.feedback_dialog_email_info)
  map.put("feedback_dialog_open_email", Res.string.feedback_dialog_open_email)
  map.put("info_gdpr_reset", Res.string.info_gdpr_reset)
  map.put("info_getting_pro_cancelled", Res.string.info_getting_pro_cancelled)
  map.put("menu_copy", Res.string.menu_copy)
  map.put("menu_cut", Res.string.menu_cut)
  map.put("menu_delete", Res.string.menu_delete)
  map.put("menu_deselect_all", Res.string.menu_deselect_all)
  map.put("menu_duplicate", Res.string.menu_duplicate)
  map.put("menu_go_pro", Res.string.menu_go_pro)
  map.put("menu_invert_selection", Res.string.menu_invert_selection)
  map.put("menu_more", Res.string.menu_more)
  map.put("menu_move", Res.string.menu_move)
  map.put("menu_region_selection", Res.string.menu_region_selection)
  map.put("menu_select_all", Res.string.menu_select_all)
  map.put("menu_settings", Res.string.menu_settings)
  map.put("placeholder_ads", Res.string.placeholder_ads)
  map.put("range_from", Res.string.range_from)
  map.put("range_to", Res.string.range_to)
  map.put("settings_auto_backup_choose_folder", Res.string.settings_auto_backup_choose_folder)
  map.put("settings_auto_backup_disable", Res.string.settings_auto_backup_disable)
  map.put("settings_auto_backup_enable", Res.string.settings_auto_backup_enable)
  map.put("settings_auto_backup_folder", Res.string.settings_auto_backup_folder)
  map.put("settings_auto_backup_frequency", Res.string.settings_auto_backup_frequency)
  map.put("settings_auto_backup_info_details", Res.string.settings_auto_backup_info_details)
  map.put("settings_auto_backup_info_title", Res.string.settings_auto_backup_info_title)
  map.put("settings_change_language", Res.string.settings_change_language)
  map.put("settings_changelog", Res.string.settings_changelog)
  map.put("settings_consent_settings", Res.string.settings_consent_settings)
  map.put("settings_contrast", Res.string.settings_contrast)
  map.put("settings_create_backup", Res.string.settings_create_backup)
  map.put("settings_developer_by_name", Res.string.settings_developer_by_name)
  map.put("settings_dialog_attach_log_file_details", Res.string.settings_dialog_attach_log_file_details)
  map.put("settings_dialog_attach_log_file_label", Res.string.settings_dialog_attach_log_file_label)
  map.put("settings_dynamic_theme", Res.string.settings_dynamic_theme)
  map.put("settings_dynamic_theme_details", Res.string.settings_dynamic_theme_details)
  map.put("settings_dynamic_theme_selection_info_details", Res.string.settings_dynamic_theme_selection_info_details)
  map.put("settings_dynamic_theme_selection_info_title", Res.string.settings_dynamic_theme_selection_info_title)
  map.put("settings_feedback", Res.string.settings_feedback)
  map.put("settings_feedback_details", Res.string.settings_feedback_details)
  map.put("settings_filter_themes_label", Res.string.settings_filter_themes_label)
  map.put("settings_filter_themes_placeholder", Res.string.settings_filter_themes_placeholder)
  map.put("settings_gdpr_consent", Res.string.settings_gdpr_consent)
  map.put("settings_gdpr_consent_details", Res.string.settings_gdpr_consent_details)
  map.put("settings_gdpr_consent_show_dialog", Res.string.settings_gdpr_consent_show_dialog)
  map.put("settings_group_about", Res.string.settings_group_about)
  map.put("settings_group_auto_backup", Res.string.settings_group_auto_backup)
  map.put("settings_group_backup", Res.string.settings_group_backup)
  map.put("settings_group_consent", Res.string.settings_group_consent)
  map.put("settings_group_consent_details", Res.string.settings_group_consent_details)
  map.put("settings_group_infos", Res.string.settings_group_infos)
  map.put("settings_group_infos_details", Res.string.settings_group_infos_details)
  map.put("settings_group_language", Res.string.settings_group_language)
  map.put("settings_group_manual_backup", Res.string.settings_group_manual_backup)
  map.put("settings_group_others", Res.string.settings_group_others)
  map.put("settings_group_others_details", Res.string.settings_group_others_details)
  map.put("settings_group_privacy", Res.string.settings_group_privacy)
  map.put("settings_group_style", Res.string.settings_group_style)
  map.put("settings_open_play_store", Res.string.settings_open_play_store)
  map.put("settings_open_play_store_details", Res.string.settings_open_play_store_details)
  map.put("settings_privacy_policy", Res.string.settings_privacy_policy)
  map.put("settings_privacy_policy_details", Res.string.settings_privacy_policy_details)
  map.put("settings_pro_version", Res.string.settings_pro_version)
  map.put("settings_pro_version_already_pro", Res.string.settings_pro_version_already_pro)
  map.put("settings_pro_version_clickable_free_title", Res.string.settings_pro_version_clickable_free_title)
  map.put("settings_pro_version_free_upgrade_hint", Res.string.settings_pro_version_free_upgrade_hint)
  map.put("settings_pro_version_is_free", Res.string.settings_pro_version_is_free)
}
