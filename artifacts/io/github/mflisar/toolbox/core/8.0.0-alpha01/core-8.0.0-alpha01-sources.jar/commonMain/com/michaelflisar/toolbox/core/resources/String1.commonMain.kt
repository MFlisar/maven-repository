@file:OptIn(InternalResourceApi::class)

package com.michaelflisar.toolbox.core.resources

import kotlin.OptIn
import kotlin.String
import kotlin.collections.MutableMap
import org.jetbrains.compose.resources.InternalResourceApi
import org.jetbrains.compose.resources.LanguageQualifier
import org.jetbrains.compose.resources.ResourceContentHash
import org.jetbrains.compose.resources.ResourceItem
import org.jetbrains.compose.resources.StringResource

private const val MD: String = "composeResources/com.michaelflisar.toolbox.core.resources/"

@delegate:ResourceContentHash(-1_400_315_107)
public val Res.string.settings_pro_version_is_pro_info: StringResource by lazy {
      StringResource("string:settings_pro_version_is_pro_info", "settings_pro_version_is_pro_info", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 7350, 136),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 6494, 116),
      ))
    }

@delegate:ResourceContentHash(-547_630_464)
public val Res.string.settings_pro_version_title: StringResource by lazy {
      StringResource("string:settings_pro_version_title", "settings_pro_version_title", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 7487, 50),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 6611, 50),
      ))
    }

@delegate:ResourceContentHash(-474_292_960)
public val Res.string.settings_restore_backup: StringResource by lazy {
      StringResource("string:settings_restore_backup", "settings_restore_backup", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 7579, 67),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 6703, 51),
      ))
    }

@delegate:ResourceContentHash(-198_748_159)
public val Res.string.settings_section_auto_backup: StringResource by lazy {
      StringResource("string:settings_section_auto_backup", "settings_section_auto_backup", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 7647, 52),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 6755, 48),
      ))
    }

@delegate:ResourceContentHash(-1_845_178_575)
public val Res.string.settings_section_manual_backup: StringResource by lazy {
      StringResource("string:settings_section_manual_backup", "settings_section_manual_backup", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 7700, 50),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 6804, 46),
      ))
    }

@delegate:ResourceContentHash(681_017_923)
public val Res.string.settings_section_more_settings: StringResource by lazy {
      StringResource("string:settings_section_more_settings", "settings_section_more_settings", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 7751, 66),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 6851, 58),
      ))
    }

@delegate:ResourceContentHash(-1_045_808_850)
public val Res.string.settings_section_theme_options: StringResource by lazy {
      StringResource("string:settings_section_theme_options", "settings_section_theme_options", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 7818, 50),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 6910, 50),
      ))
    }

@delegate:ResourceContentHash(830_302_194)
public val Res.string.settings_theme: StringResource by lazy {
      StringResource("string:settings_theme", "settings_theme", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 8161, 30),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 7249, 30),
      ))
    }

@delegate:ResourceContentHash(620_652_159)
public val Res.string.settings_theme_appearance: StringResource by lazy {
      StringResource("string:settings_theme_appearance", "settings_theme_appearance", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 7869, 49),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 6961, 57),
      ))
    }

@delegate:ResourceContentHash(1_532_394_696)
public val Res.string.settings_theme_collection: StringResource by lazy {
      StringResource("string:settings_theme_collection", "settings_theme_collection", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 7919, 45),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 7019, 49),
      ))
    }

@delegate:ResourceContentHash(-1_638_912_421)
public val Res.string.settings_theme_colors: StringResource by lazy {
      StringResource("string:settings_theme_colors", "settings_theme_colors", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 7965, 37),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 7069, 37),
      ))
    }

@delegate:ResourceContentHash(623_076_753)
public val Res.string.settings_theme_details: StringResource by lazy {
      StringResource("string:settings_theme_details", "settings_theme_details", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 8003, 114),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 7107, 98),
      ))
    }

@delegate:ResourceContentHash(62_311_890)
public val Res.string.settings_theme_variant: StringResource by lazy {
      StringResource("string:settings_theme_variant", "settings_theme_variant", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 8118, 42),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 7206, 42),
      ))
    }

@delegate:ResourceContentHash(-873_154_248)
public val Res.string.settings_toolbar_style: StringResource by lazy {
      StringResource("string:settings_toolbar_style", "settings_toolbar_style", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 8192, 46),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 7280, 50),
      ))
    }

@delegate:ResourceContentHash(-1_949_493_021)
public val Res.string.settings_version: StringResource by lazy {
      StringResource("string:settings_version", "settings_version", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 8239, 44),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 7331, 40),
      ))
    }

@delegate:ResourceContentHash(-1_208_808_197)
public val Res.string.theme_dark: StringResource by lazy {
      StringResource("string:theme_dark", "theme_dark", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 8284, 26),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 7372, 26),
      ))
    }

@delegate:ResourceContentHash(-251_661_480)
public val Res.string.theme_light: StringResource by lazy {
      StringResource("string:theme_light", "theme_light", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 8311, 27),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 7399, 27),
      ))
    }

@delegate:ResourceContentHash(-631_594_592)
public val Res.string.theme_system: StringResource by lazy {
      StringResource("string:theme_system", "theme_system", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 8339, 28),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 7427, 28),
      ))
    }

@delegate:ResourceContentHash(1_490_176_740)
public val Res.string.theme_variant_colorful: StringResource by lazy {
      StringResource("string:theme_variant_colorful", "theme_variant_colorful", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 8368, 38),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 7456, 42),
      ))
    }

@delegate:ResourceContentHash(1_284_753_719)
public val Res.string.theme_variant_monochrome: StringResource by lazy {
      StringResource("string:theme_variant_monochrome", "theme_variant_monochrome", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 8407, 44),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 7499, 48),
      ))
    }

@delegate:ResourceContentHash(1_979_852_325)
public val Res.string.toolbar_mode_background: StringResource by lazy {
      StringResource("string:toolbar_mode_background", "toolbar_mode_background", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 8452, 55),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 7548, 55),
      ))
    }

@delegate:ResourceContentHash(-1_299_417_330)
public val Res.string.toolbar_mode_black: StringResource by lazy {
      StringResource("string:toolbar_mode_black", "toolbar_mode_black", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 8508, 38),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 7604, 34),
      ))
    }

@delegate:ResourceContentHash(-1_439_526_515)
public val Res.string.toolbar_mode_primary: StringResource by lazy {
      StringResource("string:toolbar_mode_primary", "toolbar_mode_primary", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 8547, 48),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 7639, 48),
      ))
    }

@InternalResourceApi
internal fun _collectCommonMainString1Resources(map: MutableMap<String, StringResource>) {
  map.put("settings_pro_version_is_pro_info", Res.string.settings_pro_version_is_pro_info)
  map.put("settings_pro_version_title", Res.string.settings_pro_version_title)
  map.put("settings_restore_backup", Res.string.settings_restore_backup)
  map.put("settings_section_auto_backup", Res.string.settings_section_auto_backup)
  map.put("settings_section_manual_backup", Res.string.settings_section_manual_backup)
  map.put("settings_section_more_settings", Res.string.settings_section_more_settings)
  map.put("settings_section_theme_options", Res.string.settings_section_theme_options)
  map.put("settings_theme", Res.string.settings_theme)
  map.put("settings_theme_appearance", Res.string.settings_theme_appearance)
  map.put("settings_theme_collection", Res.string.settings_theme_collection)
  map.put("settings_theme_colors", Res.string.settings_theme_colors)
  map.put("settings_theme_details", Res.string.settings_theme_details)
  map.put("settings_theme_variant", Res.string.settings_theme_variant)
  map.put("settings_toolbar_style", Res.string.settings_toolbar_style)
  map.put("settings_version", Res.string.settings_version)
  map.put("theme_dark", Res.string.theme_dark)
  map.put("theme_light", Res.string.theme_light)
  map.put("theme_system", Res.string.theme_system)
  map.put("theme_variant_colorful", Res.string.theme_variant_colorful)
  map.put("theme_variant_monochrome", Res.string.theme_variant_monochrome)
  map.put("toolbar_mode_background", Res.string.toolbar_mode_background)
  map.put("toolbar_mode_black", Res.string.toolbar_mode_black)
  map.put("toolbar_mode_primary", Res.string.toolbar_mode_primary)
}
