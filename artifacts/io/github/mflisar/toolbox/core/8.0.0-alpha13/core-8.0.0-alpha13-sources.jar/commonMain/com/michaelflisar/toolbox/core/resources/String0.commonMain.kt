@file:OptIn(InternalResourceApi::class)

package com.michaelflisar.toolbox.core.resources

import kotlin.OptIn
import kotlin.String
import kotlin.collections.MutableMap
import org.jetbrains.compose.resources.InternalResourceApi
import org.jetbrains.compose.resources.LanguageQualifier
import org.jetbrains.compose.resources.ResourceContentHash
import org.jetbrains.compose.resources.ResourceItem
import org.jetbrains.compose.resources.StringResource

private const val MD: String = "composeResources/com.michaelflisar.toolbox.core.resources/"

@delegate:ResourceContentHash(1_850_003_945)
public val Res.string.backup_dialog_create_document_activity_not_found_info: StringResource by
    lazy {
      StringResource("string:backup_dialog_create_document_activity_not_found_info", "backup_dialog_create_document_activity_not_found_info", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 10, 437),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 10, 345),
      ))
    }

@delegate:ResourceContentHash(415_926_306)
public val Res.string.backup_dialog_create_document_activity_not_found_title: StringResource by
    lazy {
      StringResource("string:backup_dialog_create_document_activity_not_found_title", "backup_dialog_create_document_activity_not_found_title", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 448, 102),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 356, 86),
      ))
    }

@delegate:ResourceContentHash(1_801_960_204)
public val Res.string.backup_dialog_open_document_activity_not_found_info: StringResource by lazy {
      StringResource("string:backup_dialog_open_document_activity_not_found_info", "backup_dialog_open_document_activity_not_found_info", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 551, 431),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 443, 343),
      ))
    }

@delegate:ResourceContentHash(-797_763_864)
public val Res.string.backup_dialog_open_document_activity_not_found_title: StringResource by lazy {
      StringResource("string:backup_dialog_open_document_activity_not_found_title", "backup_dialog_open_document_activity_not_found_title", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 983, 100),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 787, 84),
      ))
    }

@delegate:ResourceContentHash(1_333_531_016)
public val Res.string.backup_done: StringResource by lazy {
      StringResource("string:backup_done", "backup_done", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1084, 31),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 872, 27),
      ))
    }

@delegate:ResourceContentHash(945_634_191)
public val Res.string.backup_error: StringResource by lazy {
      StringResource("string:backup_error", "backup_error", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1116, 36),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 900, 36),
      ))
    }

@delegate:ResourceContentHash(-1_361_049_216)
public val Res.string.backup_export: StringResource by lazy {
      StringResource("string:backup_export", "backup_export", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1198, 29),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 978, 29),
      ))
    }

@delegate:ResourceContentHash(220_563_103)
public val Res.string.backup_exporting: StringResource by lazy {
      StringResource("string:backup_exporting", "backup_exporting", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1153, 44),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 937, 40),
      ))
    }

@delegate:ResourceContentHash(1_391_261_728)
public val Res.string.backup_import: StringResource by lazy {
      StringResource("string:backup_import", "backup_import", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1273, 29),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1049, 29),
      ))
    }

@delegate:ResourceContentHash(59_885_503)
public val Res.string.backup_importing: StringResource by lazy {
      StringResource("string:backup_importing", "backup_importing", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1228, 44),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1008, 40),
      ))
    }

@delegate:ResourceContentHash(1_337_693_664)
public val Res.string.backup_inspection_app: StringResource by lazy {
      StringResource("string:backup_inspection_app", "backup_inspection_app", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1365, 41),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1141, 41),
      ))
    }

@delegate:ResourceContentHash(1_894_491_285)
public val Res.string.backup_inspection_app_version: StringResource by lazy {
      StringResource("string:backup_inspection_app_version", "backup_inspection_app_version", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1303, 61),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1079, 61),
      ))
    }

@delegate:ResourceContentHash(-1_979_427_332)
public val Res.string.backup_inspection_compatible: StringResource by lazy {
      StringResource("string:backup_inspection_compatible", "backup_inspection_compatible", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1407, 100),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1183, 76),
      ))
    }

@delegate:ResourceContentHash(-1_914_986_697)
public val Res.string.backup_inspection_created_at: StringResource by lazy {
      StringResource("string:backup_inspection_created_at", "backup_inspection_created_at", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1508, 56),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1260, 56),
      ))
    }

@delegate:ResourceContentHash(-841_879_088)
public val Res.string.backup_inspection_data_version: StringResource by lazy {
      StringResource("string:backup_inspection_data_version", "backup_inspection_data_version", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1565, 62),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1317, 62),
      ))
    }

@delegate:ResourceContentHash(801_775_587)
public val Res.string.backup_inspection_legacy: StringResource by lazy {
      StringResource("string:backup_inspection_legacy", "backup_inspection_legacy", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1628, 152),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1380, 124),
      ))
    }

@delegate:ResourceContentHash(-324_352_957)
public val Res.string.backup_inspection_metadata_version: StringResource by lazy {
      StringResource("string:backup_inspection_metadata_version", "backup_inspection_metadata_version", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1781, 74),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1505, 74),
      ))
    }

@delegate:ResourceContentHash(-719_090_468)
public val Res.string.backup_inspection_validation_failed: StringResource by lazy {
      StringResource("string:backup_inspection_validation_failed", "backup_inspection_validation_failed", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1856, 135),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1580, 103),
      ))
    }

@delegate:ResourceContentHash(1_189_892_122)
public val Res.string.backup_inspection_verifying: StringResource by lazy {
      StringResource("string:backup_inspection_verifying", "backup_inspection_verifying", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1992, 75),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1684, 63),
      ))
    }

@delegate:ResourceContentHash(1_616_833_401)
public val Res.string.backup_restore: StringResource by lazy {
      StringResource("string:backup_restore", "backup_restore", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 2068, 46),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1748, 34),
      ))
    }

@delegate:ResourceContentHash(229_706_097)
public val Res.string.backup_select_another_file: StringResource by lazy {
      StringResource("string:backup_select_another_file", "backup_select_another_file", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 2115, 62),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1783, 62),
      ))
    }

@delegate:ResourceContentHash(747_720_467)
public val Res.string.backup_select_file: StringResource by lazy {
      StringResource("string:backup_select_file", "backup_select_file", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 2178, 46),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1846, 42),
      ))
    }

@delegate:ResourceContentHash(-850_159_080)
public val Res.string.backup_waiting_for_file: StringResource by lazy {
      StringResource("string:backup_waiting_for_file", "backup_waiting_for_file", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 2225, 95),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1889, 79),
      ))
    }

@delegate:ResourceContentHash(324_824_862)
public val Res.string.button_cancel: StringResource by lazy {
      StringResource("string:button_cancel", "button_cancel", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 2321, 33),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1969, 29),
      ))
    }

@delegate:ResourceContentHash(1_879_537_469)
public val Res.string.button_close: StringResource by lazy {
      StringResource("string:button_close", "button_close", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 2355, 36),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1999, 28),
      ))
    }

@delegate:ResourceContentHash(1_804_059_142)
public val Res.string.button_no: StringResource by lazy {
      StringResource("string:button_no", "button_no", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 2392, 25),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 2028, 21),
      ))
    }

@delegate:ResourceContentHash(81_670_336)
public val Res.string.button_ok: StringResource by lazy {
      StringResource("string:button_ok", "button_ok", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 2418, 21),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 2050, 21),
      ))
    }

@delegate:ResourceContentHash(82_645_874)
public val Res.string.button_yes: StringResource by lazy {
      StringResource("string:button_yes", "button_yes", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 2440, 22),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 2072, 22),
      ))
    }

@delegate:ResourceContentHash(2_074_099_281)
public val Res.string.contrast_high: StringResource by lazy {
      StringResource("string:contrast_high", "contrast_high", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 2463, 29),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 2095, 29),
      ))
    }

@delegate:ResourceContentHash(1_167_716_518)
public val Res.string.contrast_medium: StringResource by lazy {
      StringResource("string:contrast_medium", "contrast_medium", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 2493, 31),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 2125, 31),
      ))
    }

@delegate:ResourceContentHash(-2_136_677_536)
public val Res.string.contrast_normal: StringResource by lazy {
      StringResource("string:contrast_normal", "contrast_normal", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 2525, 31),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 2157, 31),
      ))
    }

@delegate:ResourceContentHash(1_190_233_503)
public val Res.string.dlg_getting_pro_error_info: StringResource by lazy {
      StringResource("string:dlg_getting_pro_error_info", "dlg_getting_pro_error_info", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 2557, 182),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 2189, 134),
      ))
    }

@delegate:ResourceContentHash(970_559_495)
public val Res.string.dlg_pro_version_info: StringResource by lazy {
      StringResource("string:dlg_pro_version_info", "dlg_pro_version_info", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 3020, 152),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 2600, 140),
      ))
    }

@delegate:ResourceContentHash(1_608_915_567)
public val Res.string.dlg_pro_version_info_already_bought: StringResource by lazy {
      StringResource("string:dlg_pro_version_info_already_bought", "dlg_pro_version_info_already_bought", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 2740, 143),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 2324, 135),
      ))
    }

@delegate:ResourceContentHash(1_014_854_258)
public val Res.string.dlg_pro_version_info_bought: StringResource by lazy {
      StringResource("string:dlg_pro_version_info_bought", "dlg_pro_version_info_bought", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 2884, 135),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 2460, 139),
      ))
    }

@delegate:ResourceContentHash(46_334_286)
public val Res.string.dlg_pro_version_item_owned: StringResource by lazy {
      StringResource("string:dlg_pro_version_item_owned", "dlg_pro_version_item_owned", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 3173, 82),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 2741, 70),
      ))
    }

@delegate:ResourceContentHash(1_292_028_446)
public val Res.string.dlg_pro_version_purchase: StringResource by lazy {
      StringResource("string:dlg_pro_version_purchase", "dlg_pro_version_purchase", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 3395, 64),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 2931, 52),
      ))
    }

@delegate:ResourceContentHash(1_602_213_390)
public val Res.string.dlg_pro_version_purchase_error: StringResource by lazy {
      StringResource("string:dlg_pro_version_purchase_error", "dlg_pro_version_purchase_error", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 3256, 138),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 2812, 118),
      ))
    }

@delegate:ResourceContentHash(502_621_064)
public val Res.string.dlg_pro_version_restore_purchases: StringResource by lazy {
      StringResource("string:dlg_pro_version_restore_purchases", "dlg_pro_version_restore_purchases", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 3460, 73),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 2984, 65),
      ))
    }

@delegate:ResourceContentHash(80_731_272)
public val Res.string.dlg_pro_version_retry_loading_data: StringResource by lazy {
      StringResource("string:dlg_pro_version_retry_loading_data", "dlg_pro_version_retry_loading_data", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 3534, 70),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 3050, 66),
      ))
    }

@delegate:ResourceContentHash(1_646_699_168)
public val Res.string.error_invalid_input: StringResource by lazy {
      StringResource("string:error_invalid_input", "error_invalid_input", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 3605, 51),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 3117, 47),
      ))
    }

@delegate:ResourceContentHash(508_088_416)
public val Res.string.error_invalid_length: StringResource by lazy {
      StringResource("string:error_invalid_length", "error_invalid_length", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 3657, 52),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 3165, 48),
      ))
    }

@delegate:ResourceContentHash(-787_192_253)
public val Res.string.error_too_high: StringResource by lazy {
      StringResource("string:error_too_high", "error_too_high", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 3710, 38),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 3214, 34),
      ))
    }

@delegate:ResourceContentHash(-2_135_420_760)
public val Res.string.error_too_low: StringResource by lazy {
      StringResource("string:error_too_low", "error_too_low", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 3749, 41),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 3249, 33),
      ))
    }

@delegate:ResourceContentHash(2_071_668_950)
public val Res.string.feedback_dialog_email_info: StringResource by lazy {
      StringResource("string:feedback_dialog_email_info", "feedback_dialog_email_info", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 3791, 122),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 3283, 106),
      ))
    }

@delegate:ResourceContentHash(1_007_411_395)
public val Res.string.feedback_dialog_open_email: StringResource by lazy {
      StringResource("string:feedback_dialog_open_email", "feedback_dialog_open_email", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 3914, 54),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 3390, 54),
      ))
    }

@delegate:ResourceContentHash(1_658_679_058)
public val Res.string.info_gdpr_reset: StringResource by lazy {
      StringResource("string:info_gdpr_reset", "info_gdpr_reset", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 3969, 71),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 3445, 55),
      ))
    }

@delegate:ResourceContentHash(-1_018_944_191)
public val Res.string.info_getting_pro_cancelled: StringResource by lazy {
      StringResource("string:info_getting_pro_cancelled", "info_getting_pro_cancelled", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 4041, 82),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 3501, 74),
      ))
    }

@delegate:ResourceContentHash(970_395_119)
public val Res.string.menu_copy: StringResource by lazy {
      StringResource("string:menu_copy", "menu_copy", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 4124, 29),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 3576, 25),
      ))
    }

@delegate:ResourceContentHash(1_895_062_480)
public val Res.string.menu_cut: StringResource by lazy {
      StringResource("string:menu_cut", "menu_cut", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 4154, 32),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 3602, 20),
      ))
    }

@delegate:ResourceContentHash(1_219_545_176)
public val Res.string.menu_delete: StringResource by lazy {
      StringResource("string:menu_delete", "menu_delete", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 4187, 31),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 3623, 27),
      ))
    }

@delegate:ResourceContentHash(-1_496_173_149)
public val Res.string.menu_deselect_all: StringResource by lazy {
      StringResource("string:menu_deselect_all", "menu_deselect_all", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 4219, 53),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 3651, 41),
      ))
    }

@delegate:ResourceContentHash(-736_813_042)
public val Res.string.menu_duplicate: StringResource by lazy {
      StringResource("string:menu_duplicate", "menu_duplicate", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 4273, 38),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 3693, 34),
      ))
    }

@delegate:ResourceContentHash(-682_128_971)
public val Res.string.menu_go_pro: StringResource by lazy {
      StringResource("string:menu_go_pro", "menu_go_pro", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 4312, 51),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 3728, 39),
      ))
    }

@delegate:ResourceContentHash(1_561_339_049)
public val Res.string.menu_invert_selection: StringResource by lazy {
      StringResource("string:menu_invert_selection", "menu_invert_selection", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 4364, 57),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 3768, 53),
      ))
    }

@delegate:ResourceContentHash(-191_386_854)
public val Res.string.menu_more: StringResource by lazy {
      StringResource("string:menu_more", "menu_more", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 4422, 25),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 3822, 25),
      ))
    }

@delegate:ResourceContentHash(-1_979_721_638)
public val Res.string.menu_move: StringResource by lazy {
      StringResource("string:menu_move", "menu_move", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 4448, 33),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 3848, 25),
      ))
    }

@delegate:ResourceContentHash(-2_034_642_682)
public val Res.string.menu_region_selection: StringResource by lazy {
      StringResource("string:menu_region_selection", "menu_region_selection", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 4482, 41),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 3874, 41),
      ))
    }

@delegate:ResourceContentHash(793_320_902)
public val Res.string.menu_select_all: StringResource by lazy {
      StringResource("string:menu_select_all", "menu_select_all", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 4524, 47),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 3916, 39),
      ))
    }

@delegate:ResourceContentHash(1_888_768_318)
public val Res.string.menu_settings: StringResource by lazy {
      StringResource("string:menu_settings", "menu_settings", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 4572, 41),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 3956, 33),
      ))
    }

@delegate:ResourceContentHash(1_666_881_888)
public val Res.string.placeholder_ads: StringResource by lazy {
      StringResource("string:placeholder_ads", "placeholder_ads", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 4614, 35),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 3990, 43),
      ))
    }

@delegate:ResourceContentHash(-1_964_023_100)
public val Res.string.range_from: StringResource by lazy {
      StringResource("string:range_from", "range_from", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 4650, 22),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 4034, 26),
      ))
    }

@delegate:ResourceContentHash(80_792_044)
public val Res.string.range_to: StringResource by lazy {
      StringResource("string:range_to", "range_to", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 4673, 20),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 4061, 20),
      ))
    }

@delegate:ResourceContentHash(142_553_768)
public val Res.string.settings_auto_backup_choose_folder: StringResource by lazy {
      StringResource("string:settings_auto_backup_choose_folder", "settings_auto_backup_choose_folder", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 4694, 110),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 4082, 94),
      ))
    }

@delegate:ResourceContentHash(637_282_182)
public val Res.string.settings_auto_backup_disable: StringResource by lazy {
      StringResource("string:settings_auto_backup_disable", "settings_auto_backup_disable", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 4805, 84),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 4177, 68),
      ))
    }

@delegate:ResourceContentHash(25_830_874)
public val Res.string.settings_auto_backup_enable: StringResource by lazy {
      StringResource("string:settings_auto_backup_enable", "settings_auto_backup_enable", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 4890, 79),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 4246, 67),
      ))
    }

@delegate:ResourceContentHash(-933_579_575)
public val Res.string.settings_auto_backup_folder: StringResource by lazy {
      StringResource("string:settings_auto_backup_folder", "settings_auto_backup_folder", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 4970, 59),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 4314, 55),
      ))
    }

@delegate:ResourceContentHash(-755_440_183)
public val Res.string.settings_auto_backup_frequency: StringResource by lazy {
      StringResource("string:settings_auto_backup_frequency", "settings_auto_backup_frequency", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 5030, 54),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 4370, 50),
      ))
    }

@delegate:ResourceContentHash(850_106_586)
public val Res.string.settings_auto_backup_info_details: StringResource by lazy {
      StringResource("string:settings_auto_backup_info_details", "settings_auto_backup_info_details", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 5085, 129),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 4421, 105),
      ))
    }

@delegate:ResourceContentHash(1_961_287_069)
public val Res.string.settings_auto_backup_info_title: StringResource by lazy {
      StringResource("string:settings_auto_backup_info_title", "settings_auto_backup_info_title", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 5215, 71),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 4527, 63),
      ))
    }

@delegate:ResourceContentHash(724_837_565)
public val Res.string.settings_change_language: StringResource by lazy {
      StringResource("string:settings_change_language", "settings_change_language", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 5287, 52),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 4591, 52),
      ))
    }

@delegate:ResourceContentHash(303_879_372)
public val Res.string.settings_changelog: StringResource by lazy {
      StringResource("string:settings_changelog", "settings_changelog", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 5340, 54),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 4644, 38),
      ))
    }

@delegate:ResourceContentHash(358_054_029)
public val Res.string.settings_consent_settings: StringResource by lazy {
      StringResource("string:settings_consent_settings", "settings_consent_settings", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 5395, 97),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 4683, 73),
      ))
    }

@delegate:ResourceContentHash(1_773_129_826)
public val Res.string.settings_contrast: StringResource by lazy {
      StringResource("string:settings_contrast", "settings_contrast", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 5493, 37),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 4757, 37),
      ))
    }

@delegate:ResourceContentHash(-874_721_454)
public val Res.string.settings_create_backup: StringResource by lazy {
      StringResource("string:settings_create_backup", "settings_create_backup", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 5531, 58),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 4795, 50),
      ))
    }

@delegate:ResourceContentHash(1_158_627_232)
public val Res.string.settings_developer_by_name: StringResource by lazy {
      StringResource("string:settings_developer_by_name", "settings_developer_by_name", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 5590, 46),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 4846, 46),
      ))
    }

@delegate:ResourceContentHash(1_133_906_988)
public val Res.string.settings_dialog_attach_log_file_details: StringResource by lazy {
      StringResource("string:settings_dialog_attach_log_file_details", "settings_dialog_attach_log_file_details", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 5637, 135),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 4893, 127),
      ))
    }

@delegate:ResourceContentHash(1_192_328_944)
public val Res.string.settings_dialog_attach_log_file_label: StringResource by lazy {
      StringResource("string:settings_dialog_attach_log_file_label", "settings_dialog_attach_log_file_label", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 5773, 73),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 5021, 65),
      ))
    }

@delegate:ResourceContentHash(2_086_448_825)
public val Res.string.settings_dynamic_theme: StringResource by lazy {
      StringResource("string:settings_dynamic_theme", "settings_dynamic_theme", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 6272, 54),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 5484, 50),
      ))
    }

@delegate:ResourceContentHash(1_464_346_184)
public val Res.string.settings_dynamic_theme_details: StringResource by lazy {
      StringResource("string:settings_dynamic_theme_details", "settings_dynamic_theme_details", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 5847, 150),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 5087, 122),
      ))
    }

@delegate:ResourceContentHash(393_363_843)
public val Res.string.settings_dynamic_theme_selection_info_details: StringResource by lazy {
      StringResource("string:settings_dynamic_theme_selection_info_details", "settings_dynamic_theme_selection_info_details", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 5998, 173),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 5210, 173),
      ))
    }

@delegate:ResourceContentHash(2_062_507_825)
public val Res.string.settings_dynamic_theme_selection_info_title: StringResource by lazy {
      StringResource("string:settings_dynamic_theme_selection_info_title", "settings_dynamic_theme_selection_info_title", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 6172, 99),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 5384, 99),
      ))
    }

@delegate:ResourceContentHash(-537_852_960)
public val Res.string.settings_feedback: StringResource by lazy {
      StringResource("string:settings_feedback", "settings_feedback", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 6461, 37),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 5653, 37),
      ))
    }

@delegate:ResourceContentHash(-2_034_825_781)
public val Res.string.settings_feedback_details: StringResource by lazy {
      StringResource("string:settings_feedback_details", "settings_feedback_details", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 6327, 133),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 5535, 117),
      ))
    }

@delegate:ResourceContentHash(1_589_826_816)
public val Res.string.settings_filter_themes_label: StringResource by lazy {
      StringResource("string:settings_filter_themes_label", "settings_filter_themes_label", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 6499, 44),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 5691, 44),
      ))
    }

@delegate:ResourceContentHash(-602_794_496)
public val Res.string.settings_filter_themes_placeholder: StringResource by lazy {
      StringResource("string:settings_filter_themes_placeholder", "settings_filter_themes_placeholder", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 6544, 66),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 5736, 66),
      ))
    }

@delegate:ResourceContentHash(927_697_611)
public val Res.string.settings_gdpr_consent: StringResource by lazy {
      StringResource("string:settings_gdpr_consent", "settings_gdpr_consent", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 6787, 57),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 5955, 45),
      ))
    }

@delegate:ResourceContentHash(-2_126_053_173)
public val Res.string.settings_gdpr_consent_details: StringResource by lazy {
      StringResource("string:settings_gdpr_consent_details", "settings_gdpr_consent_details", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 6611, 81),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 5803, 73),
      ))
    }

@delegate:ResourceContentHash(1_891_779_751)
public val Res.string.settings_gdpr_consent_show_dialog: StringResource by lazy {
      StringResource("string:settings_gdpr_consent_show_dialog", "settings_gdpr_consent_show_dialog", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 6693, 93),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 5877, 77),
      ))
    }

@delegate:ResourceContentHash(1_326_805_841)
public val Res.string.settings_group_about: StringResource by lazy {
      StringResource("string:settings_group_about", "settings_group_about", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 6845, 36),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 6001, 36),
      ))
    }

@delegate:ResourceContentHash(1_260_215_268)
public val Res.string.settings_group_auto_backup: StringResource by lazy {
      StringResource("string:settings_group_auto_backup", "settings_group_auto_backup", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 6882, 66),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 6038, 58),
      ))
    }

@delegate:ResourceContentHash(-1_272_357_103)
public val Res.string.settings_group_backup: StringResource by lazy {
      StringResource("string:settings_group_backup", "settings_group_backup", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 6949, 45),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 6097, 41),
      ))
    }

@delegate:ResourceContentHash(918_067_971)
public val Res.string.settings_group_consent: StringResource by lazy {
      StringResource("string:settings_group_consent", "settings_group_consent", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 7058, 50),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 6202, 42),
      ))
    }

@delegate:ResourceContentHash(-271_263_336)
public val Res.string.settings_group_consent_details: StringResource by lazy {
      StringResource("string:settings_group_consent_details", "settings_group_consent_details", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 6995, 62),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 6139, 62),
      ))
    }

@delegate:ResourceContentHash(-257_404_473)
public val Res.string.settings_group_infos: StringResource by lazy {
      StringResource("string:settings_group_infos", "settings_group_infos", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 7206, 44),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 6326, 44),
      ))
    }

@delegate:ResourceContentHash(623_042_386)
public val Res.string.settings_group_infos_details: StringResource by lazy {
      StringResource("string:settings_group_infos_details", "settings_group_infos_details", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 7109, 96),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 6245, 80),
      ))
    }

@delegate:ResourceContentHash(1_447_793_218)
public val Res.string.settings_group_language: StringResource by lazy {
      StringResource("string:settings_group_language", "settings_group_language", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 7251, 43),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 6371, 43),
      ))
    }

@delegate:ResourceContentHash(-1_525_857_167)
public val Res.string.settings_group_manual_backup: StringResource by lazy {
      StringResource("string:settings_group_manual_backup", "settings_group_manual_backup", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 7295, 64),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 6415, 56),
      ))
    }

@delegate:ResourceContentHash(1_860_254_567)
public val Res.string.settings_group_others: StringResource by lazy {
      StringResource("string:settings_group_others", "settings_group_others", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 7422, 41),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 6530, 37),
      ))
    }

@delegate:ResourceContentHash(-263_529_095)
public val Res.string.settings_group_others_details: StringResource by lazy {
      StringResource("string:settings_group_others_details", "settings_group_others_details", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 7360, 61),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 6472, 57),
      ))
    }

@InternalResourceApi
internal fun _collectCommonMainString0Resources(map: MutableMap<String, StringResource>) {
  map.put("backup_dialog_create_document_activity_not_found_info", Res.string.backup_dialog_create_document_activity_not_found_info)
  map.put("backup_dialog_create_document_activity_not_found_title", Res.string.backup_dialog_create_document_activity_not_found_title)
  map.put("backup_dialog_open_document_activity_not_found_info", Res.string.backup_dialog_open_document_activity_not_found_info)
  map.put("backup_dialog_open_document_activity_not_found_title", Res.string.backup_dialog_open_document_activity_not_found_title)
  map.put("backup_done", Res.string.backup_done)
  map.put("backup_error", Res.string.backup_error)
  map.put("backup_export", Res.string.backup_export)
  map.put("backup_exporting", Res.string.backup_exporting)
  map.put("backup_import", Res.string.backup_import)
  map.put("backup_importing", Res.string.backup_importing)
  map.put("backup_inspection_app", Res.string.backup_inspection_app)
  map.put("backup_inspection_app_version", Res.string.backup_inspection_app_version)
  map.put("backup_inspection_compatible", Res.string.backup_inspection_compatible)
  map.put("backup_inspection_created_at", Res.string.backup_inspection_created_at)
  map.put("backup_inspection_data_version", Res.string.backup_inspection_data_version)
  map.put("backup_inspection_legacy", Res.string.backup_inspection_legacy)
  map.put("backup_inspection_metadata_version", Res.string.backup_inspection_metadata_version)
  map.put("backup_inspection_validation_failed", Res.string.backup_inspection_validation_failed)
  map.put("backup_inspection_verifying", Res.string.backup_inspection_verifying)
  map.put("backup_restore", Res.string.backup_restore)
  map.put("backup_select_another_file", Res.string.backup_select_another_file)
  map.put("backup_select_file", Res.string.backup_select_file)
  map.put("backup_waiting_for_file", Res.string.backup_waiting_for_file)
  map.put("button_cancel", Res.string.button_cancel)
  map.put("button_close", Res.string.button_close)
  map.put("button_no", Res.string.button_no)
  map.put("button_ok", Res.string.button_ok)
  map.put("button_yes", Res.string.button_yes)
  map.put("contrast_high", Res.string.contrast_high)
  map.put("contrast_medium", Res.string.contrast_medium)
  map.put("contrast_normal", Res.string.contrast_normal)
  map.put("dlg_getting_pro_error_info", Res.string.dlg_getting_pro_error_info)
  map.put("dlg_pro_version_info", Res.string.dlg_pro_version_info)
  map.put("dlg_pro_version_info_already_bought", Res.string.dlg_pro_version_info_already_bought)
  map.put("dlg_pro_version_info_bought", Res.string.dlg_pro_version_info_bought)
  map.put("dlg_pro_version_item_owned", Res.string.dlg_pro_version_item_owned)
  map.put("dlg_pro_version_purchase", Res.string.dlg_pro_version_purchase)
  map.put("dlg_pro_version_purchase_error", Res.string.dlg_pro_version_purchase_error)
  map.put("dlg_pro_version_restore_purchases", Res.string.dlg_pro_version_restore_purchases)
  map.put("dlg_pro_version_retry_loading_data", Res.string.dlg_pro_version_retry_loading_data)
  map.put("error_invalid_input", Res.string.error_invalid_input)
  map.put("error_invalid_length", Res.string.error_invalid_length)
  map.put("error_too_high", Res.string.error_too_high)
  map.put("error_too_low", Res.string.error_too_low)
  map.put("feedback_dialog_email_info", Res.string.feedback_dialog_email_info)
  map.put("feedback_dialog_open_email", Res.string.feedback_dialog_open_email)
  map.put("info_gdpr_reset", Res.string.info_gdpr_reset)
  map.put("info_getting_pro_cancelled", Res.string.info_getting_pro_cancelled)
  map.put("menu_copy", Res.string.menu_copy)
  map.put("menu_cut", Res.string.menu_cut)
  map.put("menu_delete", Res.string.menu_delete)
  map.put("menu_deselect_all", Res.string.menu_deselect_all)
  map.put("menu_duplicate", Res.string.menu_duplicate)
  map.put("menu_go_pro", Res.string.menu_go_pro)
  map.put("menu_invert_selection", Res.string.menu_invert_selection)
  map.put("menu_more", Res.string.menu_more)
  map.put("menu_move", Res.string.menu_move)
  map.put("menu_region_selection", Res.string.menu_region_selection)
  map.put("menu_select_all", Res.string.menu_select_all)
  map.put("menu_settings", Res.string.menu_settings)
  map.put("placeholder_ads", Res.string.placeholder_ads)
  map.put("range_from", Res.string.range_from)
  map.put("range_to", Res.string.range_to)
  map.put("settings_auto_backup_choose_folder", Res.string.settings_auto_backup_choose_folder)
  map.put("settings_auto_backup_disable", Res.string.settings_auto_backup_disable)
  map.put("settings_auto_backup_enable", Res.string.settings_auto_backup_enable)
  map.put("settings_auto_backup_folder", Res.string.settings_auto_backup_folder)
  map.put("settings_auto_backup_frequency", Res.string.settings_auto_backup_frequency)
  map.put("settings_auto_backup_info_details", Res.string.settings_auto_backup_info_details)
  map.put("settings_auto_backup_info_title", Res.string.settings_auto_backup_info_title)
  map.put("settings_change_language", Res.string.settings_change_language)
  map.put("settings_changelog", Res.string.settings_changelog)
  map.put("settings_consent_settings", Res.string.settings_consent_settings)
  map.put("settings_contrast", Res.string.settings_contrast)
  map.put("settings_create_backup", Res.string.settings_create_backup)
  map.put("settings_developer_by_name", Res.string.settings_developer_by_name)
  map.put("settings_dialog_attach_log_file_details", Res.string.settings_dialog_attach_log_file_details)
  map.put("settings_dialog_attach_log_file_label", Res.string.settings_dialog_attach_log_file_label)
  map.put("settings_dynamic_theme", Res.string.settings_dynamic_theme)
  map.put("settings_dynamic_theme_details", Res.string.settings_dynamic_theme_details)
  map.put("settings_dynamic_theme_selection_info_details", Res.string.settings_dynamic_theme_selection_info_details)
  map.put("settings_dynamic_theme_selection_info_title", Res.string.settings_dynamic_theme_selection_info_title)
  map.put("settings_feedback", Res.string.settings_feedback)
  map.put("settings_feedback_details", Res.string.settings_feedback_details)
  map.put("settings_filter_themes_label", Res.string.settings_filter_themes_label)
  map.put("settings_filter_themes_placeholder", Res.string.settings_filter_themes_placeholder)
  map.put("settings_gdpr_consent", Res.string.settings_gdpr_consent)
  map.put("settings_gdpr_consent_details", Res.string.settings_gdpr_consent_details)
  map.put("settings_gdpr_consent_show_dialog", Res.string.settings_gdpr_consent_show_dialog)
  map.put("settings_group_about", Res.string.settings_group_about)
  map.put("settings_group_auto_backup", Res.string.settings_group_auto_backup)
  map.put("settings_group_backup", Res.string.settings_group_backup)
  map.put("settings_group_consent", Res.string.settings_group_consent)
  map.put("settings_group_consent_details", Res.string.settings_group_consent_details)
  map.put("settings_group_infos", Res.string.settings_group_infos)
  map.put("settings_group_infos_details", Res.string.settings_group_infos_details)
  map.put("settings_group_language", Res.string.settings_group_language)
  map.put("settings_group_manual_backup", Res.string.settings_group_manual_backup)
  map.put("settings_group_others", Res.string.settings_group_others)
  map.put("settings_group_others_details", Res.string.settings_group_others_details)
}
