package com.michaelflisar.toolbox.backup.internal

import android.content.Context
import android.content.pm.ServiceInfo
import android.os.Build
import androidx.core.app.NotificationManagerCompat
import androidx.work.Constraints
import androidx.work.Data
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.OutOfQuotaPolicy
import androidx.work.WorkManager
import com.michaelflisar.kmp.platformcontext.PlatformApplicationContext
import com.michaelflisar.lumberjack.core.L
import com.michaelflisar.toolbox.NotificationUtil
import com.michaelflisar.toolbox.backup.BackupDefaults
import com.michaelflisar.toolbox.backup.worker.BackupWorker
import com.michaelflisar.toolbox.service.ServiceSetup
import kotlinx.serialization.json.Json
import java.util.concurrent.Executor
import java.util.concurrent.TimeUnit
import kotlin.time.Duration

object BackupServiceUtil {

    internal val JSON = Json {
        useArrayPolymorphism = true
    }

    private const val NOTIFICATION_BACKUP_ID = 5000
    private const val NOTIFICATION_BACKUP_KEPT_ID = 5001

    private const val NOTIFICATION_RESTORE_ID = 5002
    private const val NOTIFICATION_RESTORE_KEPT_ID = 5003

    const val NOTIFICATION_CHANNEL_BACKUP_ID = "backup_channel"
    const val NOTIFICATION_CHANNEL_BACKUP_NAME = "Backup Notifications"

    private val CHANNEL = ServiceSetup.Channel(
        id = NOTIFICATION_CHANNEL_BACKUP_ID,
        name = NOTIFICATION_CHANNEL_BACKUP_NAME,
        importance = NotificationManagerCompat.IMPORTANCE_MAX
    )

    fun createChannels() {
        val exists = NotificationUtil.channelExists(
            PlatformApplicationContext,
            NOTIFICATION_CHANNEL_BACKUP_ID
        )
        L.logIf { BackupDefaults.LOG }?.d {
            "BackupServiceUtil.createChannels: backup notification channel exists=$exists"
        }
        if (!exists) {
            NotificationUtil.createChannel(
                PlatformApplicationContext,
                NOTIFICATION_CHANNEL_BACKUP_NAME,
                NOTIFICATION_CHANNEL_BACKUP_ID,
                NotificationManagerCompat.IMPORTANCE_MAX
            )
            L.logIf { BackupDefaults.LOG }?.d {
                "BackupServiceUtil.createChannels: backup notification channel created"
            }
        }
    }

    fun cancelAll(context: Context) {
        L.logIf { BackupDefaults.LOG }?.d { "BackupServiceUtil.cancelAll: cancelling all work" }
        WorkManager.getInstance(context).cancelAllWork()
    }

    fun cancelAllWorkByTag(context: Context, tag: String) {
        L.logIf { BackupDefaults.LOG }?.d {
            "BackupServiceUtil.cancelAllWorkByTag: cancelling work with tag=$tag"
        }
        WorkManager.getInstance(context).cancelAllWorkByTag(tag)
    }

    fun enqueue(
        context: Context,
        inputData: Data,
        needsInternet: Boolean,
        initialDelay: Duration,
        tag: String?,
    ) {
        val workManager = WorkManager.getInstance(context)
        val constraints = Constraints.Builder()
            .apply {
                if (needsInternet) {
                    setRequiredNetworkType(NetworkType.CONNECTED)
                }
            }
            .build()
        val initialDelayMilliseconds = initialDelay.inWholeMilliseconds
        val backupRequest = OneTimeWorkRequestBuilder<BackupWorker>()
            .let {
                if (tag != null) {
                    it.addTag(tag)
                } else {
                    it
                }
            }
            .setInitialDelay(initialDelayMilliseconds, TimeUnit.MILLISECONDS)
            .setInputData(inputData)
            .setConstraints(constraints)
            .let {
                if (initialDelayMilliseconds == 0L) {
                    // beschleunigte (wenn möglich sofortige) ausführung
                    it.setExpedited(OutOfQuotaPolicy.RUN_AS_NON_EXPEDITED_WORK_REQUEST)
                } else {
                    it
                }
            }
            .build()
        L.logIf { BackupDefaults.LOG }?.d {
            "BackupServiceUtil.enqueue: requestId=${backupRequest.id}, tag=$tag, delayMs=$initialDelayMilliseconds, expedited=${initialDelayMilliseconds == 0L}, needsInternet=$needsInternet"
        }
        val operation = workManager.enqueue(backupRequest)
        L.logIf { BackupDefaults.LOG }?.d {
            "BackupServiceUtil.enqueue: enqueue submitted, requestId=${backupRequest.id}"
        }
        operation.result.addListener(
            {
                try {
                    operation.result.get()
                    L.logIf { BackupDefaults.LOG }?.d {
                        "BackupServiceUtil.enqueue: request persisted, requestId=${backupRequest.id}"
                    }
                } catch (e: Exception) {
                    L.logIf { BackupDefaults.LOG }?.d {
                        "BackupServiceUtil.enqueue: request persistence failed, requestId=${backupRequest.id}, error=${e.javaClass.simpleName}"
                    }
                    L.e(e)
                }
            },
            Executor { command -> command.run() }
        )
    }
    /*
        fun enqueuePeriodic(
            context: Context,
            firstStart: LocalTime,
            periodicDuration: Duration,
            inputData: Data,
            needsInternet: Boolean,
            tag: String? = null
        ) {
            val now = LocalDateTime.now()
            val delay = if (now.isBefore(firstStart)) {
                Duration.between(now, target)
            } else {
                Duration.between(now, firstStart).plusHours(24)
            }

            val workManager = WorkManager.getInstance(context)
            val constraints = Constraints.Builder()
                .apply {
                    if (needsInternet) {
                        setRequiredNetworkType(NetworkType.CONNECTED)
                    }
                }
                .build()
            val backupRequest = PeriodicWorkRequestBuilder<BackupWorker>(duration)
                .let {
                    if (tag != null) {
                        it.addTag(tag)
                    } else {
                        it
                    }
                }
                .setInitialDelay(delay.toJavaDuration())
                .setInputData(inputData)
                .setConstraints(constraints)
                .build()
            workManager.enqueue(backupRequest)
        }*/

    val SERVICE_BACKUP_SETUP = ServiceSetup(
        channel = CHANNEL,
        notificationId = NOTIFICATION_BACKUP_ID,
        type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
        } else 0,
        keptNotificationId = NOTIFICATION_BACKUP_KEPT_ID
    )

    val SERVICE_RESTORE_SETUP = ServiceSetup(
        channel = CHANNEL,
        notificationId = NOTIFICATION_RESTORE_ID,
        type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
        } else 0,
        keptNotificationId = NOTIFICATION_RESTORE_KEPT_ID
    )

}