package com.michaelflisar.kmpdevtools.core

import com.charleskorn.kaml.Yaml
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import java.io.File
import kotlin.text.ifEmpty

@Serializable
data class Config(
    val publish: Publish,
    @SerialName("config") val general: General,
    val apps: List<App>,
    val project: Project,
    val modules: Modules,
    val documentation: Documentation,
    val settings: Settings = Settings(),
) {
    companion object {

        const val FILE_NAME = ".config.yml"

        fun read(directory: File, filename: String = FILE_NAME): Config {
            val file = File(directory, filename)
            val content = file.readText(Charsets.UTF_8)
            return Yaml.default.decodeFromString(serializer(), content)
        }
    }

    val javaVersion: String
        get() = general.javaVersion

    val developer: Developer
        get() = general.developer

    fun requireApp(project: org.gradle.api.Project): App {
        val relativePath = project.relativeInvariantProjectPath()
        return requireApp(relativePath)
    }

    fun requireApp(relativePath: String): App {
        val app = apps.find {
            val validPaths = it.invariantModulePaths
            validPaths.contains(relativePath)
        }
        return app ?: error("[Config::requireApp] Missing required 'app' section in $FILE_NAME - path: $relativePath")
    }

    fun getModuleForProject(rootDir: File, projectDir: File): Modules.Module {
        val path = projectDir.relativeTo(rootDir).invariantSeparatorsPath
        return modules.modules.find { it.invariantPath == path }
            ?: error("Module setup not found for path '$path'; define it in config.yml")
    }

    fun libraryName(): String = project.repoName.lowercase()

    @Serializable
    data class Publish(
        @SerialName("group-id") val groupId: String,
        @SerialName("release-target") val releaseTarget: Target,
        @SerialName("test-target") val testTarget: Target = Target.NONE,
        val github: Github? = null,
    ) {
        init {
            require(github != null || (releaseTarget != Target.GITHUB && testTarget != Target.GITHUB)) {
                "'publish.github' is required when 'release-target' or 'test-target' is 'github'"
            }
        }

        fun target(type: Type): Target = when (type) {
            Type.RELEASE -> releaseTarget
            Type.TEST -> testTarget
        }

        fun requireGithub(): Github =
            github ?: error("'publish.github' is required when a publish target is 'github'")

        enum class Type(val id: String) {
            RELEASE("release"),
            TEST("test");

            companion object {
                const val ENV_NAME = "PUBLISH_TYPE"

                fun parse(value: String): Type =
                    entries.find { it.id.equals(value.trim(), ignoreCase = true) }
                        ?: error("Invalid publish type '$value'; expected one of: ${entries.joinToString { it.id }}")

                /** Reads the publish type from the [ENV_NAME] environment variable, defaults to [RELEASE]. */
                fun fromEnv(): Type =
                    System.getenv(ENV_NAME)?.takeIf { it.isNotBlank() }?.let(::parse) ?: RELEASE
            }
        }

        @Serializable
        enum class Target(val id: String) {
            @SerialName("none")
            NONE("none"),

            @SerialName("maven-central")
            MAVEN_CENTRAL("maven-central"),

            @SerialName("github")
            GITHUB("github");

            companion object {
                const val ENV_NAME = "PUBLISH_TARGET"

                /**
                 * Reads an optional target override from the [ENV_NAME] environment variable;
                 * returns null if unset, empty or "auto".
                 */
                fun fromEnv(): Target? {
                    val value = System.getenv(ENV_NAME)?.trim()
                    if (value.isNullOrEmpty() || value.equals("auto", ignoreCase = true)) return null
                    return entries.find { it.id.equals(value, ignoreCase = true) }
                        ?: error("Invalid publish target '$value' in $ENV_NAME; expected one of: auto, ${entries.joinToString { it.id }}")
                }
            }
        }

        @Serializable
        data class Github(
            val user: String,
            val repo: String,
            val branch: String,
            val path: String,
        ) {
            val fullRepoLink: String
                get() = "https://github.com/$user/$repo"

            val fullGithubPageLink: String
                get() = "https://$user.github.io/$repo"

            val fullGithubPageLinkWithPath: String
                get() = "https://$user.github.io/${repo.trimEnd('/')}/${path.trimStart('/')}"
        }
    }

    @Serializable
    data class General(
        @SerialName("java-version") val javaVersion: String,
        val developer: Developer,
    )

    @Serializable
    data class Developer(
        val name: String = "<UNKNOWN>",
        val mail: String = "<NONE>",
        @SerialName("maven-id") val mavenId: String = "<NONE>",
        @SerialName("github-user-name") val githubUserName: String = "<NONE>",
    )

    @Serializable
    data class App(
        val name: String,
        val namespace: String,
        val release: Release,
        @SerialName("module-paths") private val modulePaths: List<String>,
        val publish: Publish? = null,
    ) {
        init {
            require(release.number > 0) { "Release number for app '$name' must be positive" }
        }

        val invariantModulePaths: List<String>
            get() = modulePaths.map { it.invariantPath() }

        // soll folgendes machen:
        // invariantModulePaths = [demo/app/web, demo/app/windows, demo/shared]
        // -> commonInvariantModulePath = demo/app
        fun commonInvariantModulePath(): String {
            val modulePaths = invariantModulePaths.map { path ->
                path.trim('/').split('/').filter { it.isNotEmpty() }
            }
            require(modulePaths.isNotEmpty() && modulePaths.all { it.isNotEmpty() }) {
                "App '$name' must define at least one non-empty module path"
            }
            val commonSegments = modulePaths.drop(1).fold(modulePaths.first()) { common, path ->
                common.zip(path)
                    .takeWhile { (commonSegment, pathSegment) -> commonSegment == pathSegment }
                    .map { it.first }
            }
            return commonSegments.joinToString("/")
        }

        @Serializable
        data class Release(
            val name: String,
            val number: Int,
        )

        @Serializable
        data class Publish(
            @SerialName("url-path") val urlPath: String,
            val description: String,
            @SerialName("module-path") private val modulePath: String,
        ) {
            val invariantModulePath: String
                get() = modulePath.invariantPath()
        }
    }

    @Serializable
    data class Project(
        val namespace: String,
        @SerialName("repo-name") val repoName: String,
        val release: Int,
        val license: License,
    ) {
        init {
            require(repoName.isNotBlank()) { "'repo-name' must not be blank" }
            // vorerst; könnten auch entfernt werden bei bedarf...
            require(!repoName.contains(" ")) { "'repo-name' must not contain spaces" }
        }

        fun getRepoLink(developer: Developer): String =
            "https://github.com/${developer.githubUserName}/$repoName/"

        @Serializable
        data class License(
            val name: String,
            private val path: String,
        ) {
            fun getLink(developer: Developer, project: Project): String =
                "${project.getRepoLink(developer)}${invariantPath}"

            val invariantPath: String
                get() = path.invariantPath()
        }
    }

    @Serializable
    data class Modules(
        @SerialName("primary-artifact-id") val primaryArtifactId: String,
        val modules: List<Module>,
        val xcframeworks: List<XCFramework>,
    ) {
        @Serializable
        data class Module(
            @SerialName("artifact-id") val artifactId: String,
            val description: String,
            private val path: String,
            val plugin: Boolean = false,
            val internal: Boolean = false,
        ) {
            fun libraryDescription(config: Config): String =
                "${config.project.repoName} - $artifactId module - $description"

            fun androidNamespace(config: Config): String {
                val artifactIdPart = artifactId.replace("-", ".")
                return "${config.project.namespace}.$artifactIdPart"
            }

            val invariantPath: String
                get() = path.invariantPath()
        }

        @Serializable
        data class XCFramework(
            val name: String,
            val path: String,
            val targets: List<String>,
        )
    }

    @Serializable
    data class Documentation(
        private val path: String,
        @SerialName("relative-paths") val relativePaths: RelativePaths,
    ) {
        val invariantRoot: String
            get() = path.invariantPath()

        val invariantPartialsPath: String
            get() = resolvePath(relativePaths.partials)

        val invariantScreenshotsPath: String
            get() = resolvePath(relativePaths.screenshots)

        val invariantMainScreenshotPath: String?
            get() = relativePaths.mainScreenshot?.takeIf { it.isNotEmpty() }?.let(::resolvePath)

        private fun resolvePath(relativePath: String): String =
            "${invariantRoot.trimEnd('/')}/${relativePath.invariantPath().trimStart('/')}"

        @Serializable
        data class RelativePaths(
            val partials: String,
            val screenshots: String,
            @SerialName("main-screenshot") val mainScreenshot: String? = null,
        )
    }

    @Serializable
    data class Settings(
        @SerialName("log-dependencies") val logDependencies: Boolean = false,
    )
}