package com.michaelflisar.kmpdevtools

import com.android.build.api.dsl.ApplicationExtension
import com.android.build.api.dsl.LibraryExtension
import com.android.build.gradle.internal.crash.afterEvaluate
import com.michaelflisar.composechangelog.format.ChangelogVersionFormatter
import com.michaelflisar.composechangelog.format.DefaultVersionFormatter
import com.michaelflisar.kmpdevtools.configs.AndroidAppConfig
import com.michaelflisar.kmpdevtools.configs.AndroidLibraryConfig
import com.michaelflisar.kmpdevtools.configs.AppModuleConfig
import com.michaelflisar.kmpdevtools.configs.DesktopAppConfig
import com.michaelflisar.kmpdevtools.configs.LibraryModuleConfig
import com.michaelflisar.kmpdevtools.core.Config
import com.michaelflisar.kmpdevtools.core.utils.ModuleUtil
import com.vanniktech.maven.publish.JavadocJar
import com.vanniktech.maven.publish.KotlinMultiplatform
import com.vanniktech.maven.publish.MavenPublishBaseExtension
import com.vanniktech.maven.publish.Platform
import com.vanniktech.maven.publish.SourcesJar
import edu.sc.seis.launch4j.tasks.Launch4jLibraryTask
import org.gradle.api.JavaVersion
import org.gradle.api.Project
import org.gradle.api.publish.PublishingExtension
import org.jetbrains.compose.desktop.application.dsl.JvmApplication
import org.jetbrains.compose.desktop.application.dsl.JvmApplicationDistributions
import org.jetbrains.compose.desktop.application.dsl.TargetFormat
import org.jetbrains.dokka.gradle.DokkaExtension
import java.io.File
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

object BuildFileUtil {

    fun checkGradleProperty(project: Project, property: String): Boolean? {
        if (!project.providers.gradleProperty(property).isPresent) {
            return null
        }
        return project.providers.gradleProperty(property).get().toBoolean()
    }

    /**
     * Configures the publishing destination selected in the project's YAML configuration.
     *
     * The destination is `publish.release-target` or `publish.test-target`, depending on [publishType]
     * (defaults to the `PUBLISH_TYPE` environment variable, or `release` if unset).
     * [targetOverride] (defaults to the `PUBLISH_TARGET` environment variable, `auto` = no override) replaces it.
     */
    fun setupMavenPublish(
        libraryModuleConfig: LibraryModuleConfig.Library,
        platform: Platform = KotlinMultiplatform(
            javadocJar = JavadocJar.Dokka("dokkaGenerateHtml"),
            sourcesJar = SourcesJar.Sources()
        ),
        autoReleaseOnMavenCentral: (version: String) -> Boolean = { true },
        sign: Boolean = System.getenv("CI")?.toBoolean() == true,
        version: String = System.getenv("TAG") ?: System.getenv("VERSION") ?: "LOCAL-SNAPSHOT",
        publishType: Config.Publish.Type = Config.Publish.Type.fromEnv(),
        targetOverride: Config.Publish.Target? = Config.Publish.Target.fromEnv(),
    ) {
        val config = libraryModuleConfig.config
        val publish = config.publish
        val target = targetOverride ?: publish.target(publishType)
        when (target) {
            Config.Publish.Target.NONE -> return
            Config.Publish.Target.MAVEN_CENTRAL -> Unit
            Config.Publish.Target.GITHUB -> {
                publish.requireGithub()
            }
        }
        val groupId = publish.groupId

        configurePublish(
            libraryModuleConfig = libraryModuleConfig,
            platform = platform,
            version = version,
            groupId = groupId,
        ) {
            when (target) {
                Config.Publish.Target.NONE -> Unit
                Config.Publish.Target.MAVEN_CENTRAL ->
                    publishToMavenCentral(autoReleaseOnMavenCentral(version))

                Config.Publish.Target.GITHUB -> Unit
            }

            if (sign) {
                signAllPublications()
            }
        }

        if (target == Config.Publish.Target.GITHUB) {
            libraryModuleConfig.project.extensions.configure(PublishingExtension::class.java) {
                repositories {
                    maven {
                        name = "GitHub"
                        url = libraryModuleConfig.project.layout.buildDirectory
                            .dir("maven-repo")
                            .get()
                            .asFile
                            .toURI()
                    }
                }
            }
        }
    }


    private fun configurePublish(
        libraryModuleConfig: LibraryModuleConfig.Library,
        platform: Platform,
        version: String,
        groupId: String,
        block: MavenPublishBaseExtension.() -> Unit = {},
    ) {
        val module = libraryModuleConfig.config.getModuleForProject(
            libraryModuleConfig.project.rootDir,
            libraryModuleConfig.project.projectDir
        )

        libraryModuleConfig.project.extensions.configure(MavenPublishBaseExtension::class.java) {
            configure(platform)

            coordinates(
                groupId = groupId,
                artifactId = module.artifactId,
                version = version
            )

            pom {
                name.set(libraryModuleConfig.config.project.repoName)
                description.set(module.libraryDescription(libraryModuleConfig.config))
                inceptionYear.set(libraryModuleConfig.config.project.release.toString())
                url.set(
                    libraryModuleConfig.config.project.getRepoLink(
                        libraryModuleConfig.config.developer
                    )
                )

                licenses {
                    license {
                        name.set(libraryModuleConfig.config.project.license.name)
                        url.set(
                            libraryModuleConfig.config.project.license.getLink(
                                libraryModuleConfig.config.developer,
                                libraryModuleConfig.config.project
                            )
                        )
                    }
                }

                developers {
                    developer {
                        id.set(libraryModuleConfig.config.developer.mavenId)
                        name.set(libraryModuleConfig.config.developer.name)
                        email.set(libraryModuleConfig.config.developer.mail)
                    }
                }

                scm {
                    url.set(
                        libraryModuleConfig.config.project.getRepoLink(
                            libraryModuleConfig.config.developer
                        )
                    )
                }
            }

            block()
        }
    }

    fun setupAndroidLibrary(
        libraryModuleConfig: LibraryModuleConfig.Library,
        androidConfig: AndroidLibraryConfig,
        buildConfig: Boolean,
    ) {
        libraryModuleConfig.project.extensions.configure(LibraryExtension::class.java) {

            namespace = libraryModuleConfig.namespace()

            this.compileSdk = androidConfig.compileSdk.get().toInt()

            buildFeatures {
                this.buildConfig = buildConfig
            }

            defaultConfig {
                this.minSdk = androidConfig.minSdk.get().toInt()
            }

            compileOptions {
                sourceCompatibility = JavaVersion.toVersion(libraryModuleConfig.config.javaVersion)
                targetCompatibility = JavaVersion.toVersion(libraryModuleConfig.config.javaVersion)
            }
        }
    }

    fun setupAndroidApp(
        appModuleConfig: AppModuleConfig,
        androidAppConfig: AndroidAppConfig,
        generateResAppName: Boolean,
        buildConfig: Boolean,
        checkDebugKeyStoreProperty: Boolean,
        setupBuildTypesDebugAndRelease: Boolean,
        versionFormatter: ChangelogVersionFormatter = DefaultVersionFormatter(DefaultVersionFormatter.Format.MajorMinorPatch),
        buildTypeDebugSuffix: String = ".debug",
    ) {
        appModuleConfig.project.extensions.configure(ApplicationExtension::class.java) {

            namespace = appModuleConfig.app.namespace

            this.compileSdk = androidAppConfig.compileSdk.get().toInt()

            buildFeatures {
                resValues = true // needed for app name as string resource
                this.buildConfig = buildConfig
            }

            defaultConfig {

                this.minSdk = androidAppConfig.minSdk.get().toInt()
                this.targetSdk = androidAppConfig.targetSdk.get().toInt()
                this.versionCode = versionFormatter.parseVersion(appModuleConfig.app.versionName)
                this.versionName = appModuleConfig.app.versionName

                if (generateResAppName) {
                    resValue(
                        type = "string",
                        name = androidAppConfig.stringResourceIdForAppName,
                        value = appModuleConfig.app.name
                    )
                }
            }

            compileOptions {
                sourceCompatibility = JavaVersion.toVersion(appModuleConfig.config.javaVersion)
                targetCompatibility = JavaVersion.toVersion(appModuleConfig.config.javaVersion)
            }

            // eventually use local custom signing
            if (checkDebugKeyStoreProperty) {
                val debugKeyStore =
                    appModuleConfig.project.providers.gradleProperty("debugKeyStore").orNull
                if (debugKeyStore != null) {
                    signingConfigs {
                        getByName("debug") {
                            keyAlias = "androiddebugkey"
                            keyPassword = "android"
                            storeFile = File(debugKeyStore)
                            storePassword = "android"
                        }
                    }
                }
            }

            if (setupBuildTypesDebugAndRelease) {
                buildTypes {
                    release {
                        isMinifyEnabled = true
                        isShrinkResources = true
                        proguardFiles(
                            getDefaultProguardFile("proguard-android-optimize.txt"),
                            "proguard-rules.pro"
                        )
                    }
                    debug {
                        isMinifyEnabled = false
                        isShrinkResources = false
                        applicationIdSuffix = buildTypeDebugSuffix
                    }
                }
            }
        }
    }

    fun setupWindowsApp(
        appModuleConfig: AppModuleConfig,
        application: JvmApplication,
        desktopAppConfig: DesktopAppConfig,
        configureNativeDistribution: JvmApplicationDistributions.() -> Unit = {
            targetFormats(TargetFormat.Dmg, TargetFormat.Msi, TargetFormat.Deb)
        },
    ) {
        with(application) {

            this.mainClass = desktopAppConfig.mainClass

            nativeDistributions {

                configureNativeDistribution()

                val now = LocalDateTime.now()
                val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")

                packageName = appModuleConfig.app.name // entspricht dem exe Name
                packageVersion = appModuleConfig.app.versionName
                description =
                    "${appModuleConfig.app.name} - Build at ${now.format(formatter)}"
                copyright =
                    "©${now.year} ${appModuleConfig.config.developer.name}. All rights reserved."
                vendor = appModuleConfig.config.developer.name

                // https://github.com/JetBrains/compose-multiplatform/issues/1154
                // => suggestRuntimeModules task ausführen um zu prüfen, was man hier hinzufügen sollte
                // modules("java.instrument", "java.security.jgss", "java.sql", "java.xml.crypto", "jdk.unsupported")

                windows {
                    iconFile.set(appModuleConfig.project.file(desktopAppConfig.ico))
                    //includeAllModules = true
                }
            }
        }
    }

    fun registerLaunch4JTask(
        appModuleConfig: AppModuleConfig,
        desktopAppConfig: DesktopAppConfig,
        config: Launch4J.Config = Launch4J.Config.All(),
        baseTaskName: String = "launch4j",
        outputConfig: Launch4J.OutputConfig = Launch4J.OutputConfig(),
        configure: Launch4jLibraryTask.() -> Unit = { }
    ) {
        when (config) {
            is Launch4J.Config.Thin -> {
                Launch4J.registerTask(
                    appModuleConfig,
                    desktopAppConfig,
                    config,
                    baseTaskName,
                    outputConfig,
                    configure
                )
            }
            is Launch4J.Config.Fat -> {
                Launch4J.registerTask(
                    appModuleConfig,
                    desktopAppConfig,
                    config,
                    baseTaskName,
                    outputConfig,
                    configure
                )
            }
            is Launch4J.Config.All -> {
                Launch4J.registerTask(
                    appModuleConfig,
                    desktopAppConfig,
                    config.thin,
                    baseTaskName,
                    outputConfig,
                    configure
                )
                Launch4J.registerTask(
                    appModuleConfig,
                    desktopAppConfig,
                    config.fat,
                    baseTaskName,
                    outputConfig,
                    configure
                )
            }
        }
    }

    fun registerExtractProguardMapFromAABTask(
        appModuleConfig: AppModuleConfig,
        outputFolder: String = "${if (appModuleConfig.project.providers.gradleProperty("work").isPresent) "D:/dev" else "M:/dev"}/06 - retrace",
    ) {
        val project = appModuleConfig.project
        val appName = appModuleConfig.app.name
        val appVersionName = appModuleConfig.app.versionName
        afterEvaluate {
            project.tasks.named("bundleRelease").configure {
                finalizedBy("extractProguardMap")
            }
        }

        project.tasks.register("extractProguardMap") {
            doLast {
                extractProguardMapFromAAB(project, appName, appVersionName, outputFolder)
            }
        }
    }

    private fun extractProguardMapFromAAB(
        project: Project,
        appName: String,
        versionName: String,
        outputFolder: String,
    ) {
        with(project) {

            val outputDir = outputFolder

            //val dev = if (providers.gradleProperty("work").isPresent) "D:/dev" else "M:/dev"
            val projectName = project.name
            val aabFile = file("release/$projectName-release.aab")

            // Files / Paths
            val proguardMapRootZipPath = "BUNDLE-METADATA"
            val proguardMapZipPath =
                "$proguardMapRootZipPath/com.android.tools.build.obfuscation/proguard.map"
            val proguardMapOutput = File("$outputDir/$appName - Proguard $versionName.map")
            val proguardTmpFolder = File("$outputDir/$proguardMapRootZipPath")
            val proguardFile = File(proguardMapOutput.parentFile, proguardMapZipPath)

            // 1) das ProGuard-Map-File aus der aab extrahieren
            copy {
                copySpec {
                    from(zipTree(aabFile)) {
                        include(proguardMapZipPath)
                    }
                    into(proguardMapOutput.parentFile)
                }
            }

            // 2) das ProGuard-Map-File umbenennen
            if (proguardMapOutput.exists())
                proguardMapOutput.delete()
            val success = proguardFile.renameTo(proguardMapOutput)

            // 3) die alten Dateien löschen
            proguardTmpFolder.deleteRecursively()

            if (success) {
                println("ProGuard-Map-Datei wurde in ${proguardMapOutput.absolutePath} umbenannt.")
            } else {
                throw kotlin.Exception("ERROR - ProGuard-Map-Datei wurde NICHT in ${proguardMapOutput.absolutePath} umbenannt!")
            }
        }
    }

    fun setupDokka(project: Project) {

        val config = Config.read(project.rootDir)

        project.pluginManager.apply("org.jetbrains.dokka")
        project.extensions.configure(DokkaExtension::class.java) {
            moduleName.set(config.project.repoName)
        }

        val libraryId = config.project.repoName.lowercase()
        config.modules.modules
            .filter { it.artifactId.isNotEmpty() }
            .forEach {
                val moduleName = ModuleUtil.folderToModuleName(it.invariantPath, libraryId)
                val moduleProject = project.project(moduleName)
                moduleProject.pluginManager.apply("org.jetbrains.dokka")
                project.dependencies.add(
                    "dokka",
                    project.dependencies.project(mapOf("path" to moduleProject.path))
                )
            }
    }
}