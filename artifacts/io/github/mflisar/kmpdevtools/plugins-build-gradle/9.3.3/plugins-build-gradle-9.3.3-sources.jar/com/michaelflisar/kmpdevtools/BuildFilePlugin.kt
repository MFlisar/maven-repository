package com.michaelflisar.kmpdevtools

import com.michaelflisar.kmpdevtools.core.Config
import com.michaelflisar.kmpdevtools.features.downloadfiles.DownloadFilesTask
import com.michaelflisar.kmpdevtools.features.mactools.MacActions
import com.michaelflisar.kmpdevtools.features.mactools.MacDefaults
import com.michaelflisar.kmpdevtools.features.mactools.ToolingSetup
import com.michaelflisar.kmpdevtools.features.readme.ReadmeDefaults
import com.michaelflisar.kmpdevtools.features.readme.UpdateReadmeUtil
import com.michaelflisar.kmpdevtools.features.updatedevtools.UpdateDevToolsTask
import com.michaelflisar.kmpdevtools.internal.TaskUtil
import org.gradle.api.DefaultTask
import org.gradle.api.Plugin
import org.gradle.api.Project
import org.gradle.api.file.ConfigurableFileCollection
import org.gradle.api.file.DirectoryProperty
import org.gradle.api.provider.Property
import org.gradle.api.tasks.Input
import org.gradle.api.tasks.InputDirectory
import org.gradle.api.tasks.InputFiles
import org.gradle.api.tasks.TaskAction

//abstract class BuildFilePluginExtension @Inject constructor(private val objects: ObjectFactory) {
//
//}

class BuildFilePlugin : Plugin<Project> {

    private lateinit var project: Project

    override fun apply(project: Project) {

        this.project = project

        //val ext = project.extensions.create("buildFilePlugin", BuildFilePluginExtension::class.java)

        // 1) register root tasks
        if (project == project.rootProject) {
            project.tasks.register("updateMarkdownFiles", UpdateMarkdownFilesTask::class.java)
            project.tasks.register("macActions", MacActionsTask::class.java)
            project.tasks.register("devTools", DevToolsTask::class.java)
        }
    }
}

// ----------------------------
// Tasks
// ----------------------------

abstract class BaseTask : DefaultTask() {

    @get:InputDirectory
    abstract val rootDirectory: DirectoryProperty

    @get:InputFiles
    abstract val configFiles: ConfigurableFileCollection

    init {
        rootDirectory.convention(project.rootProject.layout.projectDirectory)
        configFiles.from(project.rootProject.layout.projectDirectory.file(Config.FILE_NAME))
    }

    fun readRoot() = rootDirectory.get().asFile

    fun readConfig(): Config {
        val root = readRoot()
        return Config.read(root)
    }

}

abstract class UpdateMarkdownFilesTask : BaseTask() {

    @get:Input
    abstract val template: Property<String>

    @get:Input
    abstract val hasApiDocs: Property<String>

    init {
        template.convention(ReadmeDefaults.DefaultReadmeTemplate)
        hasApiDocs.convention(ReadmeDefaults.HAS_API_DOCS.toString())
    }

    @TaskAction
    fun run() {
        val config = readConfig()
        UpdateReadmeUtil.update(
            rootDir = rootDirectory.get().asFile,
            config = config,
            readmeTemplate = template.get(),
            hasApiDocs = hasApiDocs.get().toBoolean()
        )
    }
}

abstract class MacActionsTask : BaseTask() {

    @TaskAction
    fun run() {
        val config = readConfig()
        val sshSetup = MacDefaults.getMacSSHSetup()
        val relativePathRoot =
            MacDefaults.getRelativePathRoot(rootDirectory.get().asFile, config)
        val toolingSetup = ToolingSetup(relativePathRoot)
        MacActions.run(
            projectRootDirectory = rootDirectory.get().asFile,
            sshSetup = sshSetup,
            toolingSetup = toolingSetup,
            config = config,
        )
    }
}

abstract class DevToolsTask : BaseTask() {

    @TaskAction
    fun run() {

        val root = readRoot()

        val tasks = listOf(
            UpdateDevToolsTask("u"),
            DownloadFilesTask("d")
        )

        println()
        println("-------------------")
        println("Available Tasks:")
        println("-------------------")

        tasks.forEachIndexed { index, task ->
            val description = task.description.takeIf { it.isNotBlank() }?.let { ": $it" }.orEmpty()
            println("- (${index + 1}) [${task.shortcut}] ${task.name}$description")
        }

        val input = TaskUtil.readUserInput("Enter task number/key: ").lowercase().trim()
        val selectedTask = tasks.firstOrNull { it.shortcut.equals(input, ignoreCase = true) }
            ?: input.toIntOrNull()?.let { tasks.getOrNull(it - 1) }

        if (selectedTask != null) {
            selectedTask.run(root)
        } else {
            println("Invalid input")
        }

    }
}