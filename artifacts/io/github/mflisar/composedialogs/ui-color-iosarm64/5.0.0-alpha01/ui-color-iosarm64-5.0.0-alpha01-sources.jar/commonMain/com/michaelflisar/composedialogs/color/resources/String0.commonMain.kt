@file:OptIn(InternalResourceApi::class)

package com.michaelflisar.composedialogs.color.resources

import kotlin.OptIn
import kotlin.String
import kotlin.collections.MutableMap
import org.jetbrains.compose.resources.InternalResourceApi
import org.jetbrains.compose.resources.LanguageQualifier
import org.jetbrains.compose.resources.ResourceContentHash
import org.jetbrains.compose.resources.ResourceItem
import org.jetbrains.compose.resources.StringResource

private const val MD: String = "composeResources/com.michaelflisar.composedialogs.color.resources/"

@delegate:ResourceContentHash(93_631_811)
public val Res.string.composedialogs_color_label_custom: StringResource by lazy {
      StringResource("string:composedialogs_color_label_custom", "composedialogs_color_label_custom", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 10, 53),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 10, 49),
      ))
    }

@delegate:ResourceContentHash(-590_264_113)
public val Res.string.composedialogs_color_label_presets: StringResource by lazy {
      StringResource("string:composedialogs_color_label_presets", "composedialogs_color_label_presets", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 64, 54),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 60, 54),
      ))
    }

@InternalResourceApi
internal fun _collectCommonMainString0Resources(map: MutableMap<String, StringResource>) {
  map.put("composedialogs_color_label_custom", Res.string.composedialogs_color_label_custom)
  map.put("composedialogs_color_label_presets", Res.string.composedialogs_color_label_presets)
}
