package com.michaelflisar.composedialogs.dialogs.color.composables

import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.michaelflisar.composedialogs.core.ui.DialogUI
import com.michaelflisar.composedialogs.dialogs.color.DialogColor
import com.michaelflisar.composedialogs.dialogs.color.DialogColorUtil
import com.michaelflisar.composedialogs.dialogs.color.classes.ColorDefinitions
import com.michaelflisar.composedialogs.dialogs.color.classes.GroupedColor

@Composable
internal fun Content(
    color: MutableState<Color>,
    colorState: MutableState<DialogColor.Page>,
    selectedMainColor: MutableState<GroupedColor>,
    selectedSubColor: MutableState<Color?>,
    selectedPresetsLevel: MutableState<Int>,
    selectedAlpha: MutableState<Float>,
    alphaSupported: Boolean,
    directEditSupported: Boolean,
    shape: Shape,
    gridSize: Int,
    labelStyle: DialogColor.LabelStyle,
) {
    val density = LocalDensity.current
    val updateSelectedPresetColors = {
        selectedMainColor.value = DialogColorUtil.getNearestColorGroup(color.value)
        selectedSubColor.value = null
        selectedPresetsLevel.value = 0
    }
    Column(modifier = Modifier.animateContentSize()) {
        Crossfade(
            modifier = Modifier,
            targetState = colorState.value,
            label = "color"
        ) {
            when (it) {
                DialogColor.Page.Custom -> {
                    Column {
                        Row(
                            modifier = Modifier.height(IntrinsicSize.Min),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box {
                                Canvas(
                                    modifier = Modifier
                                        .height(IntrinsicSize.Min)
                                        .aspectRatio(1f)
                                        //.size(previewSize)
                                        .clip(shape)
                                ) {
                                    DialogColorUtil.drawCheckerboard(this, density)
                                }
                                Spacer(
                                    modifier = Modifier
                                        .height(IntrinsicSize.Min)
                                        .aspectRatio(1f)
                                        //.size(previewSize)
                                        .background(color.value, shape)
                                )
                            }

                            DialogUI.provider.Card(modifier = Modifier) {
                                Column(
                                    modifier = Modifier
                                        .padding(all = 8.dp)
                                        .weight(1f)
                                ) {
                                    DialogUI.provider.Text(
                                        modifier = Modifier.fillMaxWidth(),
                                        text = if (alphaSupported) "ARGB" else "RGB",
                                        role = DialogUI.TextRole.Label,
                                        color = null,
                                        textAlign = null,
                                        fontWeight = FontWeight.Bold
                                    )
                                    DialogUI.provider.Text(
                                        modifier = Modifier.fillMaxWidth(),
                                        text = "#" + color.value.toArgb().toHexString()
                                            .substring(if (alphaSupported) 0 else 2),
                                        role = DialogUI.TextRole.Body,
                                        color = null,
                                        textAlign = null,
                                        fontWeight = null
                                    )
                                    if (directEditSupported) {
                                        DirectEditField(
                                            color = color,
                                            alphaSupported = alphaSupported,
                                            updateSelectedPresetColors = updateSelectedPresetColors
                                        )
                                    }
                                }
                            }
                        }
                        if (alphaSupported) {
                            ColorSlider("A", color.value.alpha, labelStyle) {
                                selectedAlpha.value = it
                                color.value = color.value.copy(alpha = it)
                                updateSelectedPresetColors()
                            }
                        }
                        ColorSlider("R", color.value.red, labelStyle) {
                            color.value = color.value.copy(red = it)
                            updateSelectedPresetColors()
                        }
                        ColorSlider("G", color.value.green, labelStyle) {
                            color.value = color.value.copy(green = it)
                            updateSelectedPresetColors()
                        }
                        ColorSlider("B", color.value.blue, labelStyle) {
                            color.value = color.value.copy(blue = it)
                            updateSelectedPresetColors()
                        }
                    }
                }

                DialogColor.Page.Presets -> {
                    val space = 8.dp
                    val size = 48.dp
                    Column(
                        modifier = Modifier.wrapContentHeight(),
                        verticalArrangement = Arrangement.spacedBy(space)
                    ) {
                        val level = selectedPresetsLevel.value
                        if (level == 0) {
                            ColorGrid(
                                level,
                                ColorDefinitions.COLORS.map { it.getColor() },
                                null,
                                selectedAlpha.value,
                                null,
                                gridSize,
                                shape,
                                space,
                                size,
                                density
                            ) {
                                selectedMainColor.value = ColorDefinitions.COLORS[it]
                                selectedPresetsLevel.value = 1
                            }
                        } else {
                            ColorGrid(
                                level,
                                selectedMainColor.value.colors.map { it.getColor() },
                                selectedMainColor.value.colors.map { it.label },
                                selectedAlpha.value,
                                selectedSubColor.value,
                                gridSize,
                                shape,
                                space,
                                size,
                                density
                            ) {
                                selectedSubColor.value =
                                    selectedMainColor.value.colors[it].getColor()
                                color.value = selectedSubColor.value!!.copy(selectedAlpha.value)
                            }
                        }
                        if (alphaSupported) {
                            ColorSlider("A", selectedAlpha.value, labelStyle) {
                                selectedAlpha.value = it
                                color.value = color.value.copy(alpha = it)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DirectEditField(
    color: MutableState<Color>,
    alphaSupported: Boolean,
    updateSelectedPresetColors: () -> Unit
) {
    val colorText = remember(color.value) {
        mutableStateOf(
            color.value.toArgb().toHexString()
                .substring(if (alphaSupported) 0 else 2)
        )
    }
    val parsedColorText = remember(colorText.value) { derivedStateOf {  DialogColorUtil.parseColor(colorText.value, alphaSupported) }  }
    LaunchedEffect(parsedColorText) {
        val c = parsedColorText.value
        if (c != null) {
            color.value = c
            updateSelectedPresetColors()
        }
    }
    DialogUI.provider.OutlinedTextField(
        modifier = Modifier.fillMaxWidth(),
        value = colorText.value,
        onValueChange = {
            colorText.value = it
        },
        isError = parsedColorText.value == null
    )
}