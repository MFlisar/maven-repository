@file:OptIn(InternalResourceApi::class)

package com.michaelflisar.composedialogs.time.resources

import kotlin.OptIn
import kotlin.String
import kotlin.collections.MutableMap
import org.jetbrains.compose.resources.InternalResourceApi
import org.jetbrains.compose.resources.LanguageQualifier
import org.jetbrains.compose.resources.ResourceContentHash
import org.jetbrains.compose.resources.ResourceItem
import org.jetbrains.compose.resources.StringResource

private const val MD: String = "composeResources/com.michaelflisar.composedialogs.time.resources/"

@delegate:ResourceContentHash(1_667_501_782)
public val Res.string.composedialogs_time_am: StringResource by lazy {
      StringResource("string:composedialogs_time_am", "composedialogs_time_am", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 10, 34),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 10, 38),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 10, 34),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 10, 34),
      ))
    }

@delegate:ResourceContentHash(1_222_532_953)
public val Res.string.composedialogs_time_hour: StringResource by lazy {
      StringResource("string:composedialogs_time_hour", "composedialogs_time_hour", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 45, 40),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 49, 40),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 45, 40),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 45, 40),
      ))
    }

@delegate:ResourceContentHash(-1_161_480_965)
public val Res.string.composedialogs_time_invalid_hour: StringResource by lazy {
      StringResource("string:composedialogs_time_invalid_hour", "composedialogs_time_invalid_hour", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 86, 64),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 90, 60),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 86, 60),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 86, 56),
      ))
    }

@delegate:ResourceContentHash(782_382_050)
public val Res.string.composedialogs_time_invalid_minute: StringResource by lazy {
      StringResource("string:composedialogs_time_invalid_minute", "composedialogs_time_invalid_minute", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 151, 66),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 151, 66),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 147, 62),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 143, 62),
      ))
    }

@delegate:ResourceContentHash(1_212_554_250)
public val Res.string.composedialogs_time_minute: StringResource by lazy {
      StringResource("string:composedialogs_time_minute", "composedialogs_time_minute", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 218, 42),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 218, 42),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 210, 42),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 206, 42),
      ))
    }

@delegate:ResourceContentHash(1_652_136_592)
public val Res.string.composedialogs_time_pm: StringResource by lazy {
      StringResource("string:composedialogs_time_pm", "composedialogs_time_pm", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 261, 34),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 261, 38),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 253, 34),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 249, 34),
      ))
    }

@InternalResourceApi
internal fun _collectCommonMainString0Resources(map: MutableMap<String, StringResource>) {
  map.put("composedialogs_time_am", Res.string.composedialogs_time_am)
  map.put("composedialogs_time_hour", Res.string.composedialogs_time_hour)
  map.put("composedialogs_time_invalid_hour", Res.string.composedialogs_time_invalid_hour)
  map.put("composedialogs_time_invalid_minute", Res.string.composedialogs_time_invalid_minute)
  map.put("composedialogs_time_minute", Res.string.composedialogs_time_minute)
  map.put("composedialogs_time_pm", Res.string.composedialogs_time_pm)
}
