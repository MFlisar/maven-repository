@file:OptIn(InternalResourceApi::class)

package com.michaelflisar.composedialogs.time.resources

import kotlin.OptIn
import kotlin.String
import kotlin.collections.MutableMap
import org.jetbrains.compose.resources.InternalResourceApi
import org.jetbrains.compose.resources.LanguageQualifier
import org.jetbrains.compose.resources.ResourceContentHash
import org.jetbrains.compose.resources.ResourceItem
import org.jetbrains.compose.resources.StringResource

private const val MD: String = "composeResources/com.michaelflisar.composedialogs.time.resources/"

@delegate:ResourceContentHash(79_881_760)
public val Res.string.composedialogs_time_am: StringResource by lazy {
      StringResource("string:composedialogs_time_am", "composedialogs_time_am", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 10, 34),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 10, 34),
      ))
    }

@delegate:ResourceContentHash(-175_486_162)
public val Res.string.composedialogs_time_hour: StringResource by lazy {
      StringResource("string:composedialogs_time_hour", "composedialogs_time_hour", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 45, 40),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 45, 40),
      ))
    }

@delegate:ResourceContentHash(-1_445_528_412)
public val Res.string.composedialogs_time_invalid_hour: StringResource by lazy {
      StringResource("string:composedialogs_time_invalid_hour", "composedialogs_time_invalid_hour", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 86, 64),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 86, 56),
      ))
    }

@delegate:ResourceContentHash(-1_354_710_125)
public val Res.string.composedialogs_time_invalid_minute: StringResource by lazy {
      StringResource("string:composedialogs_time_invalid_minute", "composedialogs_time_invalid_minute", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 151, 66),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 143, 62),
      ))
    }

@delegate:ResourceContentHash(-512_171_200)
public val Res.string.composedialogs_time_minute: StringResource by lazy {
      StringResource("string:composedialogs_time_minute", "composedialogs_time_minute", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 218, 42),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 206, 42),
      ))
    }

@delegate:ResourceContentHash(83_202_976)
public val Res.string.composedialogs_time_pm: StringResource by lazy {
      StringResource("string:composedialogs_time_pm", "composedialogs_time_pm", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 261, 34),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 249, 34),
      ))
    }

@InternalResourceApi
internal fun _collectCommonMainString0Resources(map: MutableMap<String, StringResource>) {
  map.put("composedialogs_time_am", Res.string.composedialogs_time_am)
  map.put("composedialogs_time_hour", Res.string.composedialogs_time_hour)
  map.put("composedialogs_time_invalid_hour", Res.string.composedialogs_time_invalid_hour)
  map.put("composedialogs_time_invalid_minute", Res.string.composedialogs_time_invalid_minute)
  map.put("composedialogs_time_minute", Res.string.composedialogs_time_minute)
  map.put("composedialogs_time_pm", Res.string.composedialogs_time_pm)
}
