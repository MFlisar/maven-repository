@file:OptIn(InternalResourceApi::class)

package com.michaelflisar.composedialogs.color.resources

import kotlin.OptIn
import kotlin.String
import kotlin.collections.MutableMap
import org.jetbrains.compose.resources.InternalResourceApi
import org.jetbrains.compose.resources.LanguageQualifier
import org.jetbrains.compose.resources.ResourceContentHash
import org.jetbrains.compose.resources.ResourceItem
import org.jetbrains.compose.resources.StringResource

private const val MD: String = "composeResources/com.michaelflisar.composedialogs.color.resources/"

@delegate:ResourceContentHash(1_588_739_277)
public val Res.string.composedialogs_color_action_apply: StringResource by lazy {
      StringResource("string:composedialogs_color_action_apply", "composedialogs_color_action_apply", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 10, 57),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 10, 49),
      ))
    }

@delegate:ResourceContentHash(324_824_862)
public val Res.string.composedialogs_color_action_cancel: StringResource by lazy {
      StringResource("string:composedialogs_color_action_cancel", "composedialogs_color_action_cancel", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 68, 54),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 60, 50),
      ))
    }

@delegate:ResourceContentHash(2_122_122_274)
public val Res.string.composedialogs_color_error_invalid: StringResource by lazy {
      StringResource("string:composedialogs_color_error_invalid", "composedialogs_color_error_invalid", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 123, 70),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 111, 70),
      ))
    }

@delegate:ResourceContentHash(93_631_811)
public val Res.string.composedialogs_color_label_custom: StringResource by lazy {
      StringResource("string:composedialogs_color_label_custom", "composedialogs_color_label_custom", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 194, 53),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 182, 49),
      ))
    }

@delegate:ResourceContentHash(-580_935_968)
public val Res.string.composedialogs_color_label_edit: StringResource by lazy {
      StringResource("string:composedialogs_color_label_edit", "composedialogs_color_label_edit", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 248, 63),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 232, 55),
      ))
    }

@delegate:ResourceContentHash(-590_264_113)
public val Res.string.composedialogs_color_label_presets: StringResource by lazy {
      StringResource("string:composedialogs_color_label_presets", "composedialogs_color_label_presets", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 312, 54),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 288, 54),
      ))
    }

@InternalResourceApi
internal fun _collectCommonMainString0Resources(map: MutableMap<String, StringResource>) {
  map.put("composedialogs_color_action_apply", Res.string.composedialogs_color_action_apply)
  map.put("composedialogs_color_action_cancel", Res.string.composedialogs_color_action_cancel)
  map.put("composedialogs_color_error_invalid", Res.string.composedialogs_color_error_invalid)
  map.put("composedialogs_color_label_custom", Res.string.composedialogs_color_label_custom)
  map.put("composedialogs_color_label_edit", Res.string.composedialogs_color_label_edit)
  map.put("composedialogs_color_label_presets", Res.string.composedialogs_color_label_presets)
}
