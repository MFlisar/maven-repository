@file:OptIn(InternalResourceApi::class)

package com.michaelflisar.composedialogs.date.resources

import kotlin.OptIn
import kotlin.String
import kotlin.collections.MutableMap
import org.jetbrains.compose.resources.InternalResourceApi
import org.jetbrains.compose.resources.LanguageQualifier
import org.jetbrains.compose.resources.ResourceContentHash
import org.jetbrains.compose.resources.ResourceItem
import org.jetbrains.compose.resources.StringResource

private const val MD: String = "composeResources/com.michaelflisar.composedialogs.date.resources/"

@delegate:ResourceContentHash(-116_595_334)
public val Res.string.composedialogs_date_today: StringResource by lazy {
      StringResource("string:composedialogs_date_today", "composedialogs_date_today", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 10, 41),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 10, 41),
      ))
    }

@InternalResourceApi
internal fun _collectCommonMainString0Resources(map: MutableMap<String, StringResource>) {
  map.put("composedialogs_date_today", Res.string.composedialogs_date_today)
}
