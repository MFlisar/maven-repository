@file:OptIn(InternalResourceApi::class)

package com.michaelflisar.composedialogs.frequency.resources

import kotlin.OptIn
import kotlin.String
import kotlin.collections.MutableMap
import org.jetbrains.compose.resources.InternalResourceApi
import org.jetbrains.compose.resources.LanguageQualifier
import org.jetbrains.compose.resources.ResourceContentHash
import org.jetbrains.compose.resources.ResourceItem
import org.jetbrains.compose.resources.StringResource

private const val MD: String =
    "composeResources/com.michaelflisar.composedialogs.frequency.resources/"

@delegate:ResourceContentHash(-374_323_317)
public val Res.string.composedialogs_frequency_day: StringResource by lazy {
      StringResource("string:composedialogs_frequency_day", "composedialogs_frequency_day", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 185, 40),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 193, 44),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 193, 44),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 185, 40),
      ))
    }

@delegate:ResourceContentHash(-274_252_703)
public val Res.string.composedialogs_frequency_day_of_month: StringResource by lazy {
      StringResource("string:composedialogs_frequency_day_of_month", "composedialogs_frequency_day_of_month", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 10, 65),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 10, 61),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 10, 61),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 10, 61),
      ))
    }

@delegate:ResourceContentHash(-119_430_977)
public val Res.string.composedialogs_frequency_day_of_week: StringResource by lazy {
      StringResource("string:composedialogs_frequency_day_of_week", "composedialogs_frequency_day_of_week", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 76, 56),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 72, 68),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 72, 68),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 72, 60),
      ))
    }

@delegate:ResourceContentHash(1_816_333_768)
public val Res.string.composedialogs_frequency_day_plural: StringResource by lazy {
      StringResource("string:composedialogs_frequency_day_plural", "composedialogs_frequency_day_plural", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 133, 51),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 141, 51),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 141, 51),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 133, 51),
      ))
    }

@delegate:ResourceContentHash(2_116_843_373)
public val Res.string.composedialogs_frequency_frequency: StringResource by lazy {
      StringResource("string:composedialogs_frequency_frequency", "composedialogs_frequency_frequency", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 226, 58),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 238, 58),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 238, 58),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 226, 54),
      ))
    }

@delegate:ResourceContentHash(-340_423_881)
public val Res.string.composedialogs_frequency_interval: StringResource by lazy {
      StringResource("string:composedialogs_frequency_interval", "composedialogs_frequency_interval", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 285, 53),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 297, 53),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 297, 57),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 281, 53),
      ))
    }

@delegate:ResourceContentHash(305_763_612)
public val Res.string.composedialogs_frequency_invalid_interval: StringResource by lazy {
      StringResource("string:composedialogs_frequency_invalid_interval", "composedialogs_frequency_invalid_interval", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 339, 101),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 351, 97),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 355, 109),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 335, 85),
      ))
    }

@delegate:ResourceContentHash(-902_562_023)
public val Res.string.composedialogs_frequency_month: StringResource by lazy {
      StringResource("string:composedialogs_frequency_month", "composedialogs_frequency_month", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1280, 46),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 1288, 42),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 1312, 46),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1260, 46),
      ))
    }

@delegate:ResourceContentHash(1_421_303_478)
public val Res.string.composedialogs_frequency_month_of_year: StringResource by lazy {
      StringResource("string:composedialogs_frequency_month_of_year", "composedialogs_frequency_month_of_year", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 441, 70),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 449, 62),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 465, 70),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 421, 66),
      ))
    }

@delegate:ResourceContentHash(-1_082_777_163)
public val Res.string.composedialogs_frequency_month_plural: StringResource by lazy {
      StringResource("string:composedialogs_frequency_month_plural", "composedialogs_frequency_month_plural", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 512, 53),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 512, 53),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 536, 53),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 488, 53),
      ))
    }

@delegate:ResourceContentHash(1_161_461_135)
public val Res.string.composedialogs_frequency_monthname_april: StringResource by lazy {
      StringResource("string:composedialogs_frequency_monthname_april", "composedialogs_frequency_monthname_april", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 566, 56),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 566, 56),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 590, 56),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 542, 56),
      ))
    }

@delegate:ResourceContentHash(1_864_537_159)
public val Res.string.composedialogs_frequency_monthname_august: StringResource by lazy {
      StringResource("string:composedialogs_frequency_monthname_august", "composedialogs_frequency_monthname_august", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 623, 57),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 623, 57),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 647, 57),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 599, 57),
      ))
    }

@delegate:ResourceContentHash(269_514_440)
public val Res.string.composedialogs_frequency_monthname_december: StringResource by lazy {
      StringResource("string:composedialogs_frequency_monthname_december", "composedialogs_frequency_monthname_december", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 681, 63),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 681, 63),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 705, 63),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 657, 63),
      ))
    }

@delegate:ResourceContentHash(-1_208_144_379)
public val Res.string.composedialogs_frequency_monthname_february: StringResource by lazy {
      StringResource("string:composedialogs_frequency_monthname_february", "composedialogs_frequency_monthname_february", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 745, 63),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 745, 63),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 769, 63),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 721, 63),
      ))
    }

@delegate:ResourceContentHash(238_993_383)
public val Res.string.composedialogs_frequency_monthname_january: StringResource by lazy {
      StringResource("string:composedialogs_frequency_monthname_january", "composedialogs_frequency_monthname_january", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 809, 58),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 809, 58),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 833, 62),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 785, 62),
      ))
    }

@delegate:ResourceContentHash(-1_726_134_172)
public val Res.string.composedialogs_frequency_monthname_july: StringResource by lazy {
      StringResource("string:composedialogs_frequency_monthname_july", "composedialogs_frequency_monthname_july", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 868, 55),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 868, 55),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 896, 59),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 848, 55),
      ))
    }

@delegate:ResourceContentHash(2_131_835_234)
public val Res.string.composedialogs_frequency_monthname_june: StringResource by lazy {
      StringResource("string:composedialogs_frequency_monthname_june", "composedialogs_frequency_monthname_june", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 924, 55),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 924, 55),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 956, 55),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 904, 55),
      ))
    }

@delegate:ResourceContentHash(-1_575_856_934)
public val Res.string.composedialogs_frequency_monthname_march: StringResource by lazy {
      StringResource("string:composedialogs_frequency_monthname_march", "composedialogs_frequency_monthname_march", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 980, 56),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 980, 56),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 1012, 56),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 960, 56),
      ))
    }

@delegate:ResourceContentHash(-364_671_297)
public val Res.string.composedialogs_frequency_monthname_may: StringResource by lazy {
      StringResource("string:composedialogs_frequency_monthname_may", "composedialogs_frequency_monthname_may", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1037, 50),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 1037, 54),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 1069, 50),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1017, 50),
      ))
    }

@delegate:ResourceContentHash(-431_776_380)
public val Res.string.composedialogs_frequency_monthname_november: StringResource by lazy {
      StringResource("string:composedialogs_frequency_monthname_november", "composedialogs_frequency_monthname_november", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1088, 63),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 1092, 63),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 1120, 63),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1068, 63),
      ))
    }

@delegate:ResourceContentHash(147_333_065)
public val Res.string.composedialogs_frequency_monthname_october: StringResource by lazy {
      StringResource("string:composedialogs_frequency_monthname_october", "composedialogs_frequency_monthname_october", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1152, 62),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 1156, 62),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 1184, 62),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1132, 62),
      ))
    }

@delegate:ResourceContentHash(-150_045_178)
public val Res.string.composedialogs_frequency_monthname_september: StringResource by lazy {
      StringResource("string:composedialogs_frequency_monthname_september", "composedialogs_frequency_monthname_september", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1215, 64),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 1219, 68),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 1247, 64),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1195, 64),
      ))
    }

@delegate:ResourceContentHash(-77_573_174)
public val Res.string.composedialogs_frequency_time: StringResource by lazy {
      StringResource("string:composedialogs_frequency_time", "composedialogs_frequency_time", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1382, 49),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 1386, 45),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 1418, 45),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1358, 45),
      ))
    }

@delegate:ResourceContentHash(-557_081_932)
public val Res.string.composedialogs_frequency_time_save: StringResource by lazy {
      StringResource("string:composedialogs_frequency_time_save", "composedialogs_frequency_time_save", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1327, 54),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 1331, 54),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 1359, 58),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1307, 50),
      ))
    }

@delegate:ResourceContentHash(533_488_818)
public val Res.string.composedialogs_frequency_week: StringResource by lazy {
      StringResource("string:composedialogs_frequency_week", "composedialogs_frequency_week", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1913, 45),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 1909, 45),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 1933, 49),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1873, 45),
      ))
    }

@delegate:ResourceContentHash(850_108_772)
public val Res.string.composedialogs_frequency_week_plural: StringResource by lazy {
      StringResource("string:composedialogs_frequency_week_plural", "composedialogs_frequency_week_plural", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1432, 52),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 1432, 56),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 1464, 56),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1404, 52),
      ))
    }

@delegate:ResourceContentHash(2_014_944_477)
public val Res.string.composedialogs_frequency_weekday_friday: StringResource by lazy {
      StringResource("string:composedialogs_frequency_weekday_friday", "composedialogs_frequency_weekday_friday", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1485, 59),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 1489, 59),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 1521, 59),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1457, 55),
      ))
    }

@delegate:ResourceContentHash(1_890_632_640)
public val Res.string.composedialogs_frequency_weekday_monday: StringResource by lazy {
      StringResource("string:composedialogs_frequency_weekday_monday", "composedialogs_frequency_weekday_monday", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1545, 55),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 1549, 55),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 1581, 55),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1513, 55),
      ))
    }

@delegate:ResourceContentHash(124_363_683)
public val Res.string.composedialogs_frequency_weekday_saturday: StringResource by lazy {
      StringResource("string:composedialogs_frequency_weekday_saturday", "composedialogs_frequency_weekday_saturday", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1601, 61),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 1605, 61),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 1637, 57),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1569, 61),
      ))
    }

@delegate:ResourceContentHash(-487_524_809)
public val Res.string.composedialogs_frequency_weekday_sunday: StringResource by lazy {
      StringResource("string:composedialogs_frequency_weekday_sunday", "composedialogs_frequency_weekday_sunday", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1663, 59),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 1667, 59),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 1695, 59),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1631, 55),
      ))
    }

@delegate:ResourceContentHash(-994_272_165)
public val Res.string.composedialogs_frequency_weekday_thursday: StringResource by lazy {
      StringResource("string:composedialogs_frequency_weekday_thursday", "composedialogs_frequency_weekday_thursday", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1723, 65),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 1727, 57),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 1755, 57),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1687, 61),
      ))
    }

@delegate:ResourceContentHash(1_717_777_894)
public val Res.string.composedialogs_frequency_weekday_tuesday: StringResource by lazy {
      StringResource("string:composedialogs_frequency_weekday_tuesday", "composedialogs_frequency_weekday_tuesday", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1789, 60),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 1785, 56),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 1813, 56),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1749, 60),
      ))
    }

@delegate:ResourceContentHash(755_334_375)
public val Res.string.composedialogs_frequency_weekday_wednesday: StringResource by lazy {
      StringResource("string:composedialogs_frequency_weekday_wednesday", "composedialogs_frequency_weekday_wednesday", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1850, 62),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 1842, 66),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 1870, 62),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1810, 62),
      ))
    }

@delegate:ResourceContentHash(1_730_143_426)
public val Res.string.composedialogs_frequency_year: StringResource by lazy {
      StringResource("string:composedialogs_frequency_year", "composedialogs_frequency_year", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 2012, 45),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 2008, 45),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 2032, 41),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1972, 45),
      ))
    }

@delegate:ResourceContentHash(1_861_770_139)
public val Res.string.composedialogs_frequency_year_plural: StringResource by lazy {
      StringResource("string:composedialogs_frequency_year_plural", "composedialogs_frequency_year_plural", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1959, 52),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 1955, 52),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 1983, 48),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1919, 52),
      ))
    }

@InternalResourceApi
internal fun _collectCommonMainString0Resources(map: MutableMap<String, StringResource>) {
  map.put("composedialogs_frequency_day", Res.string.composedialogs_frequency_day)
  map.put("composedialogs_frequency_day_of_month", Res.string.composedialogs_frequency_day_of_month)
  map.put("composedialogs_frequency_day_of_week", Res.string.composedialogs_frequency_day_of_week)
  map.put("composedialogs_frequency_day_plural", Res.string.composedialogs_frequency_day_plural)
  map.put("composedialogs_frequency_frequency", Res.string.composedialogs_frequency_frequency)
  map.put("composedialogs_frequency_interval", Res.string.composedialogs_frequency_interval)
  map.put("composedialogs_frequency_invalid_interval", Res.string.composedialogs_frequency_invalid_interval)
  map.put("composedialogs_frequency_month", Res.string.composedialogs_frequency_month)
  map.put("composedialogs_frequency_month_of_year", Res.string.composedialogs_frequency_month_of_year)
  map.put("composedialogs_frequency_month_plural", Res.string.composedialogs_frequency_month_plural)
  map.put("composedialogs_frequency_monthname_april", Res.string.composedialogs_frequency_monthname_april)
  map.put("composedialogs_frequency_monthname_august", Res.string.composedialogs_frequency_monthname_august)
  map.put("composedialogs_frequency_monthname_december", Res.string.composedialogs_frequency_monthname_december)
  map.put("composedialogs_frequency_monthname_february", Res.string.composedialogs_frequency_monthname_february)
  map.put("composedialogs_frequency_monthname_january", Res.string.composedialogs_frequency_monthname_january)
  map.put("composedialogs_frequency_monthname_july", Res.string.composedialogs_frequency_monthname_july)
  map.put("composedialogs_frequency_monthname_june", Res.string.composedialogs_frequency_monthname_june)
  map.put("composedialogs_frequency_monthname_march", Res.string.composedialogs_frequency_monthname_march)
  map.put("composedialogs_frequency_monthname_may", Res.string.composedialogs_frequency_monthname_may)
  map.put("composedialogs_frequency_monthname_november", Res.string.composedialogs_frequency_monthname_november)
  map.put("composedialogs_frequency_monthname_october", Res.string.composedialogs_frequency_monthname_october)
  map.put("composedialogs_frequency_monthname_september", Res.string.composedialogs_frequency_monthname_september)
  map.put("composedialogs_frequency_time", Res.string.composedialogs_frequency_time)
  map.put("composedialogs_frequency_time_save", Res.string.composedialogs_frequency_time_save)
  map.put("composedialogs_frequency_week", Res.string.composedialogs_frequency_week)
  map.put("composedialogs_frequency_week_plural", Res.string.composedialogs_frequency_week_plural)
  map.put("composedialogs_frequency_weekday_friday", Res.string.composedialogs_frequency_weekday_friday)
  map.put("composedialogs_frequency_weekday_monday", Res.string.composedialogs_frequency_weekday_monday)
  map.put("composedialogs_frequency_weekday_saturday", Res.string.composedialogs_frequency_weekday_saturday)
  map.put("composedialogs_frequency_weekday_sunday", Res.string.composedialogs_frequency_weekday_sunday)
  map.put("composedialogs_frequency_weekday_thursday", Res.string.composedialogs_frequency_weekday_thursday)
  map.put("composedialogs_frequency_weekday_tuesday", Res.string.composedialogs_frequency_weekday_tuesday)
  map.put("composedialogs_frequency_weekday_wednesday", Res.string.composedialogs_frequency_weekday_wednesday)
  map.put("composedialogs_frequency_year", Res.string.composedialogs_frequency_year)
  map.put("composedialogs_frequency_year_plural", Res.string.composedialogs_frequency_year_plural)
}
