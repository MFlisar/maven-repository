@file:OptIn(InternalResourceApi::class)

package com.michaelflisar.composedialogs.frequency.resources

import kotlin.OptIn
import kotlin.String
import kotlin.collections.MutableMap
import org.jetbrains.compose.resources.InternalResourceApi
import org.jetbrains.compose.resources.LanguageQualifier
import org.jetbrains.compose.resources.ResourceContentHash
import org.jetbrains.compose.resources.ResourceItem
import org.jetbrains.compose.resources.StringResource

private const val MD: String =
    "composeResources/com.michaelflisar.composedialogs.frequency.resources/"

@delegate:ResourceContentHash(84_360_291)
public val Res.string.composedialogs_frequency_day: StringResource by lazy {
      StringResource("string:composedialogs_frequency_day", "composedialogs_frequency_day", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 185, 40),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 185, 40),
      ))
    }

@delegate:ResourceContentHash(779_845_912)
public val Res.string.composedialogs_frequency_day_of_month: StringResource by lazy {
      StringResource("string:composedialogs_frequency_day_of_month", "composedialogs_frequency_day_of_month", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 10, 65),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 10, 61),
      ))
    }

@delegate:ResourceContentHash(28_410_215)
public val Res.string.composedialogs_frequency_day_of_week: StringResource by lazy {
      StringResource("string:composedialogs_frequency_day_of_week", "composedialogs_frequency_day_of_week", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 76, 56),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 72, 60),
      ))
    }

@delegate:ResourceContentHash(-2_117_788_736)
public val Res.string.composedialogs_frequency_day_plural: StringResource by lazy {
      StringResource("string:composedialogs_frequency_day_plural", "composedialogs_frequency_day_plural", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 133, 51),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 133, 51),
      ))
    }

@delegate:ResourceContentHash(-755_440_183)
public val Res.string.composedialogs_frequency_frequency: StringResource by lazy {
      StringResource("string:composedialogs_frequency_frequency", "composedialogs_frequency_frequency", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 226, 58),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 226, 54),
      ))
    }

@delegate:ResourceContentHash(-1_153_978_517)
public val Res.string.composedialogs_frequency_interval: StringResource by lazy {
      StringResource("string:composedialogs_frequency_interval", "composedialogs_frequency_interval", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 285, 53),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 281, 53),
      ))
    }

@delegate:ResourceContentHash(-2_072_776_551)
public val Res.string.composedialogs_frequency_invalid_interval: StringResource by lazy {
      StringResource("string:composedialogs_frequency_invalid_interval", "composedialogs_frequency_invalid_interval", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 339, 101),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 335, 85),
      ))
    }

@delegate:ResourceContentHash(-1_370_941_344)
public val Res.string.composedialogs_frequency_month: StringResource by lazy {
      StringResource("string:composedialogs_frequency_month", "composedialogs_frequency_month", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1280, 46),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1260, 46),
      ))
    }

@delegate:ResourceContentHash(1_708_365_874)
public val Res.string.composedialogs_frequency_month_of_year: StringResource by lazy {
      StringResource("string:composedialogs_frequency_month_of_year", "composedialogs_frequency_month_of_year", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 441, 70),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 421, 66),
      ))
    }

@delegate:ResourceContentHash(-1_370_938_834)
public val Res.string.composedialogs_frequency_month_plural: StringResource by lazy {
      StringResource("string:composedialogs_frequency_month_plural", "composedialogs_frequency_month_plural", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 512, 53),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 488, 53),
      ))
    }

@delegate:ResourceContentHash(-1_690_410_176)
public val Res.string.composedialogs_frequency_monthname_april: StringResource by lazy {
      StringResource("string:composedialogs_frequency_monthname_april", "composedialogs_frequency_monthname_april", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 566, 56),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 542, 56),
      ))
    }

@delegate:ResourceContentHash(-869_852_512)
public val Res.string.composedialogs_frequency_monthname_august: StringResource by lazy {
      StringResource("string:composedialogs_frequency_monthname_august", "composedialogs_frequency_monthname_august", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 623, 57),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 599, 57),
      ))
    }

@delegate:ResourceContentHash(1_791_849_396)
public val Res.string.composedialogs_frequency_monthname_december: StringResource by lazy {
      StringResource("string:composedialogs_frequency_monthname_december", "composedialogs_frequency_monthname_december", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 681, 63),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 657, 63),
      ))
    }

@delegate:ResourceContentHash(-1_779_872_327)
public val Res.string.composedialogs_frequency_monthname_february: StringResource by lazy {
      StringResource("string:composedialogs_frequency_monthname_february", "composedialogs_frequency_monthname_february", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 745, 63),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 721, 63),
      ))
    }

@delegate:ResourceContentHash(287_875_980)
public val Res.string.composedialogs_frequency_monthname_january: StringResource by lazy {
      StringResource("string:composedialogs_frequency_monthname_january", "composedialogs_frequency_monthname_january", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 809, 58),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 785, 62),
      ))
    }

@delegate:ResourceContentHash(1_177_983_612)
public val Res.string.composedialogs_frequency_monthname_july: StringResource by lazy {
      StringResource("string:composedialogs_frequency_monthname_july", "composedialogs_frequency_monthname_july", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 868, 55),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 848, 55),
      ))
    }

@delegate:ResourceContentHash(1_236_761_255)
public val Res.string.composedialogs_frequency_monthname_june: StringResource by lazy {
      StringResource("string:composedialogs_frequency_monthname_june", "composedialogs_frequency_monthname_june", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 924, 55),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 904, 55),
      ))
    }

@delegate:ResourceContentHash(1_882_770_177)
public val Res.string.composedialogs_frequency_monthname_march: StringResource by lazy {
      StringResource("string:composedialogs_frequency_monthname_march", "composedialogs_frequency_monthname_march", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 980, 56),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 960, 56),
      ))
    }

@delegate:ResourceContentHash(82_826_597)
public val Res.string.composedialogs_frequency_monthname_may: StringResource by lazy {
      StringResource("string:composedialogs_frequency_monthname_may", "composedialogs_frequency_monthname_may", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1037, 50),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1017, 50),
      ))
    }

@delegate:ResourceContentHash(-886_062_304)
public val Res.string.composedialogs_frequency_monthname_november: StringResource by lazy {
      StringResource("string:composedialogs_frequency_monthname_november", "composedialogs_frequency_monthname_november", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1088, 63),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1068, 63),
      ))
    }

@delegate:ResourceContentHash(-1_854_175_386)
public val Res.string.composedialogs_frequency_monthname_october: StringResource by lazy {
      StringResource("string:composedialogs_frequency_monthname_october", "composedialogs_frequency_monthname_october", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1152, 62),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1132, 62),
      ))
    }

@delegate:ResourceContentHash(134_014_656)
public val Res.string.composedialogs_frequency_monthname_september: StringResource by lazy {
      StringResource("string:composedialogs_frequency_monthname_september", "composedialogs_frequency_monthname_september", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1215, 64),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1195, 64),
      ))
    }

@delegate:ResourceContentHash(1_162_895_327)
public val Res.string.composedialogs_frequency_time: StringResource by lazy {
      StringResource("string:composedialogs_frequency_time", "composedialogs_frequency_time", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1327, 49),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1307, 45),
      ))
    }

@delegate:ResourceContentHash(476_253_663)
public val Res.string.composedialogs_frequency_week: StringResource by lazy {
      StringResource("string:composedialogs_frequency_week", "composedialogs_frequency_week", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1858, 45),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1822, 45),
      ))
    }

@delegate:ResourceContentHash(476_191_508)
public val Res.string.composedialogs_frequency_week_plural: StringResource by lazy {
      StringResource("string:composedialogs_frequency_week_plural", "composedialogs_frequency_week_plural", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1377, 52),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1353, 52),
      ))
    }

@delegate:ResourceContentHash(-557_514_570)
public val Res.string.composedialogs_frequency_weekday_friday: StringResource by lazy {
      StringResource("string:composedialogs_frequency_weekday_friday", "composedialogs_frequency_weekday_friday", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1430, 59),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1406, 55),
      ))
    }

@delegate:ResourceContentHash(8_862_033)
public val Res.string.composedialogs_frequency_weekday_monday: StringResource by lazy {
      StringResource("string:composedialogs_frequency_weekday_monday", "composedialogs_frequency_weekday_monday", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1490, 55),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1462, 55),
      ))
    }

@delegate:ResourceContentHash(1_303_866_655)
public val Res.string.composedialogs_frequency_weekday_saturday: StringResource by lazy {
      StringResource("string:composedialogs_frequency_weekday_saturday", "composedialogs_frequency_weekday_saturday", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1546, 61),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1518, 61),
      ))
    }

@delegate:ResourceContentHash(755_184_385)
public val Res.string.composedialogs_frequency_weekday_sunday: StringResource by lazy {
      StringResource("string:composedialogs_frequency_weekday_sunday", "composedialogs_frequency_weekday_sunday", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1608, 59),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1580, 55),
      ))
    }

@delegate:ResourceContentHash(1_431_618_833)
public val Res.string.composedialogs_frequency_weekday_thursday: StringResource by lazy {
      StringResource("string:composedialogs_frequency_weekday_thursday", "composedialogs_frequency_weekday_thursday", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1668, 65),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1636, 61),
      ))
    }

@delegate:ResourceContentHash(1_748_131_998)
public val Res.string.composedialogs_frequency_weekday_tuesday: StringResource by lazy {
      StringResource("string:composedialogs_frequency_weekday_tuesday", "composedialogs_frequency_weekday_tuesday", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1734, 60),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1698, 60),
      ))
    }

@delegate:ResourceContentHash(-1_334_666_736)
public val Res.string.composedialogs_frequency_weekday_wednesday: StringResource by lazy {
      StringResource("string:composedialogs_frequency_weekday_wednesday", "composedialogs_frequency_weekday_wednesday", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1795, 62),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1759, 62),
      ))
    }

@delegate:ResourceContentHash(365_871_713)
public val Res.string.composedialogs_frequency_year: StringResource by lazy {
      StringResource("string:composedialogs_frequency_year", "composedialogs_frequency_year", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1957, 45),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1921, 45),
      ))
    }

@delegate:ResourceContentHash(366_080_746)
public val Res.string.composedialogs_frequency_year_plural: StringResource by lazy {
      StringResource("string:composedialogs_frequency_year_plural", "composedialogs_frequency_year_plural", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1904, 52),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1868, 52),
      ))
    }

@InternalResourceApi
internal fun _collectCommonMainString0Resources(map: MutableMap<String, StringResource>) {
  map.put("composedialogs_frequency_day", Res.string.composedialogs_frequency_day)
  map.put("composedialogs_frequency_day_of_month", Res.string.composedialogs_frequency_day_of_month)
  map.put("composedialogs_frequency_day_of_week", Res.string.composedialogs_frequency_day_of_week)
  map.put("composedialogs_frequency_day_plural", Res.string.composedialogs_frequency_day_plural)
  map.put("composedialogs_frequency_frequency", Res.string.composedialogs_frequency_frequency)
  map.put("composedialogs_frequency_interval", Res.string.composedialogs_frequency_interval)
  map.put("composedialogs_frequency_invalid_interval", Res.string.composedialogs_frequency_invalid_interval)
  map.put("composedialogs_frequency_month", Res.string.composedialogs_frequency_month)
  map.put("composedialogs_frequency_month_of_year", Res.string.composedialogs_frequency_month_of_year)
  map.put("composedialogs_frequency_month_plural", Res.string.composedialogs_frequency_month_plural)
  map.put("composedialogs_frequency_monthname_april", Res.string.composedialogs_frequency_monthname_april)
  map.put("composedialogs_frequency_monthname_august", Res.string.composedialogs_frequency_monthname_august)
  map.put("composedialogs_frequency_monthname_december", Res.string.composedialogs_frequency_monthname_december)
  map.put("composedialogs_frequency_monthname_february", Res.string.composedialogs_frequency_monthname_february)
  map.put("composedialogs_frequency_monthname_january", Res.string.composedialogs_frequency_monthname_january)
  map.put("composedialogs_frequency_monthname_july", Res.string.composedialogs_frequency_monthname_july)
  map.put("composedialogs_frequency_monthname_june", Res.string.composedialogs_frequency_monthname_june)
  map.put("composedialogs_frequency_monthname_march", Res.string.composedialogs_frequency_monthname_march)
  map.put("composedialogs_frequency_monthname_may", Res.string.composedialogs_frequency_monthname_may)
  map.put("composedialogs_frequency_monthname_november", Res.string.composedialogs_frequency_monthname_november)
  map.put("composedialogs_frequency_monthname_october", Res.string.composedialogs_frequency_monthname_october)
  map.put("composedialogs_frequency_monthname_september", Res.string.composedialogs_frequency_monthname_september)
  map.put("composedialogs_frequency_time", Res.string.composedialogs_frequency_time)
  map.put("composedialogs_frequency_week", Res.string.composedialogs_frequency_week)
  map.put("composedialogs_frequency_week_plural", Res.string.composedialogs_frequency_week_plural)
  map.put("composedialogs_frequency_weekday_friday", Res.string.composedialogs_frequency_weekday_friday)
  map.put("composedialogs_frequency_weekday_monday", Res.string.composedialogs_frequency_weekday_monday)
  map.put("composedialogs_frequency_weekday_saturday", Res.string.composedialogs_frequency_weekday_saturday)
  map.put("composedialogs_frequency_weekday_sunday", Res.string.composedialogs_frequency_weekday_sunday)
  map.put("composedialogs_frequency_weekday_thursday", Res.string.composedialogs_frequency_weekday_thursday)
  map.put("composedialogs_frequency_weekday_tuesday", Res.string.composedialogs_frequency_weekday_tuesday)
  map.put("composedialogs_frequency_weekday_wednesday", Res.string.composedialogs_frequency_weekday_wednesday)
  map.put("composedialogs_frequency_year", Res.string.composedialogs_frequency_year)
  map.put("composedialogs_frequency_year_plural", Res.string.composedialogs_frequency_year_plural)
}
