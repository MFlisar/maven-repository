package com.michaelflisar.composedialogs.core

import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ButtonColors
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarScrollBehavior
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.michaelflisar.composedialogs.core.style.BottomSheetStyle
import com.michaelflisar.composedialogs.core.style.BottomSheetStyleDefaults
import com.michaelflisar.composedialogs.core.style.DialogStyle
import com.michaelflisar.composedialogs.core.style.DialogStyleDefaults
import com.michaelflisar.composedialogs.core.style.FullscreenDialogStyle
import com.michaelflisar.composedialogs.core.style.FullscreenDialogStyleDefaults

// ------------------
// defaults functions
// ------------------

/**
 * Shows a dialog containing some arbitrary [content]
 *
 * @param state the [DialogState] of the dialog
 * @param title the optional title of the dialog
 * @param icon the optional icon of the dialog
 * @param style the [ComposeDialogStyle] of the dialog - use [DialogDefaults.styleDialog] or [DialogDefaults.styleBottomSheet]
 * @param buttons the [DialogButtons] of the dialog - use [DialogDefaults.buttons] here [DialogDefaults.buttonsDisabled]
 * @param options the [DialogOptions] of the dialog - use [DialogDefaults.options] here
 * @param onEvent the callback for all [DialogEvent] - this can be a button click [DialogEvent.Button] or the dismiss information [DialogEvent.Dismissed]
 * @param content the content of this dialog
 */
@Composable
fun Dialog(
    state: BaseDialogState,
    title: (@Composable () -> Unit)? = null,
    icon: (@Composable () -> Unit)? = null,
    style: ComposeDialogStyle = DialogDefaults.defaultDialogStyle(),
    buttons: DialogButtons = DialogDefaults.buttons(),
    options: DialogOptions = DialogDefaults.options(),
    onEvent: (event: DialogEvent) -> Unit = {},
    content: @Composable () -> Unit
) {
    style.Show(
        title,
        icon,
        buttons,
        options,
        state,
        onEvent,
        content
    )
}

// ------------------
// defaults functions
// ------------------

object DialogDefaults {

    /**
     * the setup of the dialog buttons
     *
     * use [buttonsDisabled] if you do not want to show any buttons
     * use [DialogButton.DISABLED] as button if you do not want to show the respective button
     *
     * Info: Buttons with an empty text will be disabled!
     *
     * @param positive positive [DialogButton]
     * @param negative negative [DialogButton]
     */
    @Composable
    fun buttons(
        positive: DialogButton = DialogButton(stringOk()),
        negative: DialogButton = DialogButton("")
    ) = DialogButtons(
        positive,
        negative
    )

    /**
     * the setup of the dialog buttons if you do not want to show any buttons
     */
    @Composable
    fun buttonsDisabled() = DialogButtons.DISABLED

    /**
     * some additional options for the dialog
     *
     * @param dismissOnButtonClick if true, the dialog will be dismissed on button click
     */
    @Composable
    fun options(
        dismissOnButtonClick: Boolean = true
    ) = DialogOptions(
        dismissOnButtonClick
    )

    // begin-snippet: Dialog::style-dialog
    /**
     * the setup of a dialog that shows as a normal dialog popup
     *
     * @param swipeDismissable if true, the dialog can be swiped away by an up/down swipe
     * @param dismissOnBackPress if true, the dialog can be dismissed by a back press
     * @param dismissOnClickOutside if true, the dialog can be dismissed by clicking outside of its borders
     * @param scrim if true, the dialog will a show a scrim behind it
     * @param options provides custom style options of the dialog
     * @param shape the [Shape] of the dialog
     * @param containerColor the [Color] of the container
     * @param iconColor the content [Color] of the icon
     * @param titleColor the content [Color] of the title
     * @param contentColor the content [Color] of the text
     */
    @Composable
    fun styleDialog(
        swipeDismissable: Boolean = false,
        // DialogProperties
        dismissOnBackPress: Boolean = true,
        dismissOnClickOutside: Boolean = true,
        scrim: Boolean = true,
        // Style
        options: StyleOptions = StyleOptions(),
        shape: Shape = DialogStyleDefaults.shape,
        containerColor: Color = DialogStyleDefaults.containerColor,
        iconColor: Color = DialogStyleDefaults.iconColor,
        titleColor: Color = DialogStyleDefaults.titleColor,
        contentColor: Color = DialogStyleDefaults.contentColor
    ): ComposeDialogStyle
    // end-snippet
    {
        return DialogStyle(
            swipeDismissable = swipeDismissable,
            // DialogProperties
            dismissOnBackPress = dismissOnBackPress,
            dismissOnClickOutside = dismissOnClickOutside,
            scrim = scrim,
            // Style
            options = options,
            shape = shape,
            containerColor = containerColor,
            iconColor = iconColor,
            titleColor = titleColor,
            contentColor = contentColor
        )
    }

    // begin-snippet: Dialog::style-bottom-sheet
    /**
     * the setup of a dialog that shows as a normal dialog popup
     *
     * @param dragHandle if true, a drag handle will be shown
     * @param peekHeight the peek height calculation of the bottom sheet
     * @param expandInitially if true, the bottom sheet is initially displayed in expanded state (even if it has a peek height)
     * @param velocityThreshold the velocity threshold of the bottom sheet
     * @param positionalThreshold the positional threshold of the bottom sheet
     * @param animateShow if true, the sheet will be animated on first show
     * @param dismissOnBackPress if true, the dialog can be dismissed by a back press
     * @param dismissOnClickOutside if true, the dialog can be dismissed by clicking outside of its borders
     * @param scrim if true, the dialog will a show a scrim behind it
     * @param options provides custom style options of the dialog
     * @param shape the [Shape] of the dialog
     * @param containerColor the [Color] of the container
     * @param iconColor the content [Color] of the icon
     * @param titleColor the content [Color] of the title
     * @param contentColor the content [Color] of the text
     */
    @Composable
    fun styleBottomSheet(
        dragHandle: Boolean = true,
        peekHeight: ((containerHeight: Dp, sheetHeight: Dp) -> Dp)? = BottomSheetStyleDefaults.peekHeight,
        expandInitially: Boolean = false,
        velocityThreshold: () -> Dp = { 125.dp },
        positionalThreshold: (totalDistance: Dp) -> Dp = { 56.dp },
        animateShow: Boolean = false,
        // DialogProperties
        dismissOnBackPress: Boolean = true,
        dismissOnClickOutside: Boolean = true,
        scrim: Boolean = true,
        // Style
        options: StyleOptions = StyleOptions(),
        topCornerSize: Dp = BottomSheetStyleDefaults.topCornerSize,
        containerColor: Color = BottomSheetStyleDefaults.containerColor,
        iconColor: Color = BottomSheetStyleDefaults.iconColor,
        titleColor: Color = BottomSheetStyleDefaults.titleColor,
        contentColor: Color = BottomSheetStyleDefaults.contentColor
    ): ComposeDialogStyle
    // end-snippet
    {
        return BottomSheetStyle(
            dragHandle,
            peekHeight,
            expandInitially,
            velocityThreshold,
            positionalThreshold,
            animateShow,
            // DialogProperties
            dismissOnBackPress,
            dismissOnClickOutside,
            scrim,
            // Style
            options,
            topCornerSize,
            containerColor,
            iconColor,
            titleColor,
            contentColor
        )
    }

    // begin-snippet: Dialog::style-full-screen-dialog
    /**
     * the setup of a dialog that shows as a normal dialog popup
     *
     * @param navigationIcon the optional navigation icon, if not provided, a default close icon will be shown (use null to not show any navigation icon)
     * @param menuActions if provided, it replaces the the default close menu action
     * @param toolbarScrollBehaviour the optional scroll behaviour for the toolbar, if not provided, the toolbar will not react on scrolls
     * @param showIconBelowToolbar if true, the icon will be shown below the toolbar, otherwise in the toolbar
     * @param dismissOnBackPress if true, the dialog can be dismissed by a back press
     * @param toolbarColor the [Color] of the toolbar
     * @param toolbarColorExpanded the [Color] of the toolbar in expanded state (if a scroll behaviour is provided)
     * @param toolbarActionColor the content [Color] of the toolbar actions
     * @param toolbarActionColorExpanded the content [Color] of the toolbar actions in expanded state (if a scroll behaviour is provided)
     * @param toolbarContentColor the content [Color] of the toolbar title and navigation icon
     * @param toolbarContentColorExpanded the content [Color] of the toolbar title and navigation icon in expanded state (if a scroll behaviour is provided)
     * @param iconColor the content [Color] of the icon (if shown below the toolbar)
     * @param containerColor the [Color] of the container
     * @param contentColor the content [Color] of the text
     * @param applyContentPadding if true, the default content padding will be applied, otherwise the content will be shown edge to edge
     */
    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    fun styleFullscreenDialog(
        navigationIcon: (@Composable () -> Unit)? = { FullscreenDialogStyleDefaults.NavigationIcon() },
        menuActions: @Composable (RowScope.() -> Unit)? = null,
        toolbarScrollBehaviour: TopAppBarScrollBehavior? = null,
        showIconBelowToolbar: Boolean = true,
        // DialogProperties
        dismissOnBackPress: Boolean = true,
        // Style
        toolbarColor: Color = FullscreenDialogStyleDefaults.toolbarColor,
        toolbarColorExpanded: Color = FullscreenDialogStyleDefaults.toolbarColorExpanded,
        toolbarActionColor: Color = FullscreenDialogStyleDefaults.toolbarActionColor,
        toolbarActionColorExpanded: Color = FullscreenDialogStyleDefaults.toolbarActionColorExpanded,
        toolbarContentColor: Color = FullscreenDialogStyleDefaults.toolbarContentColor,
        toolbarContentColorExpanded: Color = FullscreenDialogStyleDefaults.toolbarContentColorExpanded,
        iconColor: Color = FullscreenDialogStyleDefaults.iconColor,
        containerColor: Color = FullscreenDialogStyleDefaults.containerColor,
        contentColor: Color = FullscreenDialogStyleDefaults.contentColor,
        applyContentPadding: Boolean = true
    ): ComposeDialogStyle
    // end-snippet
     {
        return FullscreenDialogStyle(
            navigationIcon,
            menuActions,
            toolbarScrollBehaviour,
            showIconBelowToolbar,
            // DialogProperties
            dismissOnBackPress,
            // Style
            toolbarColor,
            toolbarColorExpanded,
            toolbarActionColor,
            toolbarActionColorExpanded,
            toolbarContentColor,
            toolbarContentColorExpanded,
            iconColor,
            containerColor,
            contentColor,
            applyContentPadding
        )
    }
}

// ------------------
// classes
// ------------------

/**
 * an enum for the different dialog event types
 */
enum class DialogEventType {
    ButtonPositive,
    ButtonNegative,
    Dismissed
}

/**
 * the sealed event for all dialog events (button click and dismissal)
 *
 * [DialogEvent.dismissed] the information if this event will dismiss the dialog or not
 * [DialogEvent.type] a convenient enum to determine, if this is the event is a positive button, negative button or a dismissal
 */
sealed class DialogEvent {

    abstract val dismissed: Boolean
    @Deprecated("use [DialogEvent::type] instead", replaceWith = ReplaceWith("type == DialogEventType.ButtonPositive"))
    abstract val isPositiveButton: Boolean

    abstract val type: DialogEventType

    /**
     * the event of a dialog button click
     *
     * @param button the [DialogButtonType] of the button that was clicked
     * @param dismissed the information if this button will dismiss the dialog or not
     */
    class Button(
        val button: DialogButtonType,
        override val dismissed: Boolean
    ) : DialogEvent() {
        @Deprecated("use [DialogEvent::type] instead", replaceWith = ReplaceWith("type == DialogEventType.ButtonPositive"))
        override val isPositiveButton = button == DialogButtonType.Positive
        override val type = when (button) {
            DialogButtonType.Positive -> DialogEventType.ButtonPositive
            DialogButtonType.Negative -> DialogEventType.ButtonNegative
        }
        override fun toString() = "DialogEvent::Button(button=$button, dismissed=$dismissed)"
    }

    /**
     * the event of a dialog dismissal
     */
    object Dismissed : DialogEvent() {
        override val dismissed = true
        @Deprecated("use [DialogEvent::type] instead", replaceWith = ReplaceWith("type == DialogEventType.ButtonPositive"))
        override val isPositiveButton = false
        override val type = DialogEventType.Dismissed
        override fun toString() = "DialogEvent::Dismissed"
    }
}

/**
 * an enum for the different dialog button types
 */
enum class DialogButtonType {
    Positive,
    Negative
}

/**
 * an interaction source for button states and option state
 *
 * @param buttonPositiveEnabled the positive button is only enabled if this state is true
 * @param buttonNegativeEnabled the negative button is only enabled if this state is true
 * @param dismissAllowed the dialog can only be dismissed if this state is true
 * @param swipeAllowed the dialog can only be swiped away if this state is true
 */
class DialogInteractionSource internal constructor(
    val buttonPositiveEnabled: MutableState<Boolean>,
    val buttonNegativeEnabled: MutableState<Boolean>,
    val dismissAllowed: MutableState<Boolean>,
    val swipeAllowed: MutableState<Boolean>
)

/**
 * a dialog state holding the current showing state and some additional state [DialogInteractionSource] of the dialog
 */
abstract class BaseDialogState {

    /**
     * the showing state of the dialog
     */
    abstract val visible: Boolean

    /**
     * the [DialogInteractionSource] holding other states for this dialog
     */
    abstract val interactionSource: DialogInteractionSource

    abstract fun onDismiss()

    /**
     * this will dismiss this dialog (if the [interactionSource] ([DialogInteractionSource.dismissAllowed]) does allow this)
     *
     * @return true, if the dismiss was successful
     */
    fun dismiss(): Boolean {
        if (interactionSource.dismissAllowed.value) {
            onDismiss()
        }
        return !visible
    }

    internal fun dismiss(
        onEvent: (event: DialogEvent) -> Unit
    ): Boolean {
        if (dismiss())
            onEvent(DialogEvent.Dismissed)
        return !visible
    }

    internal fun onButtonPressed(
        onEvent: (event: DialogEvent) -> Unit,
        button: DialogButtonType,
        dismiss: Boolean
    ) {
        onEvent(DialogEvent.Button(button, dismiss))
    }

    /**
     * this will determine if a button currently can be pressed
     */
    fun isButtonEnabled(button: DialogButtonType): Boolean {
        return when (button) {
            DialogButtonType.Positive -> interactionSource.buttonPositiveEnabled.value
            DialogButtonType.Negative -> interactionSource.buttonNegativeEnabled.value
        }
    }

    /**
     * enable or disable a button
     */
    fun enableButton(
        button: DialogButtonType,
        enabled: Boolean
    ) {
        when (button) {
            DialogButtonType.Positive -> interactionSource.buttonPositiveEnabled.value = enabled
            DialogButtonType.Negative -> interactionSource.buttonNegativeEnabled.value = enabled
        }
    }

    /**
     * make dialog dismissable or not
     */
    fun dismissable(enabled: Boolean) {
        interactionSource.dismissAllowed.value = enabled
    }
}

/**
 * a dialog state holding the current state and the some additional state [DialogInteractionSource] of the dialog
 *
 * @param state the state of the dialog - if not null, the dialog is visible, otherwise not
 * @param interactionSource the [DialogInteractionSource] holding other states for this dialog
 * @param onBeforeShow the callback that will be called before showing this dialog, providing the data that will be shown in this dialog
 * @param onShow the callback that will be called when this dialog is shown, providing the data that is shown in this dialog
 * @param onDismiss the callback that will be called when this dialog is dismissed
 */
private class DialogStateImpl<T>(
    private val state: MutableState<T?>,
    interactionSource: MutableState<DialogInteractionSource>,
    private val onBeforeShow: ((data: T) -> Unit)? = null,
    private val onShow: ((data: T) -> Unit)? = null,
    private val onDismiss: (() -> Unit)? = null
) : BaseDialogState() {

    override val visible: Boolean
        get() = state.value != null

    override val interactionSource by interactionSource

    override fun onDismiss() {
        state.value = null
        onDismiss?.invoke()
    }

    /**
     * this will show this dialog
     */
    fun show(data: T) {
        onBeforeShow?.invoke(data)
        state.value = data
        onShow?.invoke(data)
    }

    /**
     * this will return the currently held data
     */
    val data: T?
        get() = state.value

    /**
     * should only be called if dialog is shown
     */
    fun requireData() = state.value!!
}

/**
 * a dialog state holding the current state and the some additional state [DialogInteractionSource] of the dialog
 *
 * @param state the state of the dialog - if not null, the dialog is visible, otherwise not
 * @param interactionSource the [DialogInteractionSource] holding other states for this dialog
 * @param onBeforeShow the callback that will be called before showing this dialog, providing the data that will be shown in this dialog
 * @param onShow the callback that will be called when this dialog is shown, providing the data that is shown in this dialog
 * @param onDismiss the callback that will be called when this dialog is dismissed
 */
class DialogState<T> internal constructor(
    // Parameter bleiben internal, Instanzen werden intern erzeugt
    state: MutableState<T?>,
    interactionSource: MutableState<DialogInteractionSource>,
    onBeforeShow: ((data: T) -> Unit)? = null,
    onShow: ((data: T) -> Unit)? = null,
    onDismiss: (() -> Unit)? = null
) : BaseDialogState() {

    private val impl = DialogStateImpl(state, interactionSource, onBeforeShow, onShow, onDismiss)

    override val visible: Boolean get() = impl.visible
    override val interactionSource get() = impl.interactionSource
    override fun onDismiss() = impl.onDismiss()

    fun show(data: T) = impl.show(data)
    val data: T? get() = impl.data
    fun requireData() = impl.requireData()
}

/**
 * convenience type alias for no data dialogs (internal state is Unit, but the overload does not require a data parameter)
 */
class DialogStateNoData internal constructor(
    state: MutableState<Unit?>,
    interactionSource: MutableState<DialogInteractionSource>,
    onBeforeShow: (() -> Unit)? = null,
    onShow: (() -> Unit)? = null,
    onDismiss: (() -> Unit)? = null
) : BaseDialogState() {

    private val impl = DialogStateImpl(
        state,
        interactionSource,
        onBeforeShow = onBeforeShow?.let { { onBeforeShow() } },
        onShow = onShow?.let { { onShow() } },
        onDismiss
    )

    override val visible: Boolean get() = impl.visible
    override val interactionSource get() = impl.interactionSource
    override fun onDismiss() = impl.onDismiss()

    fun show() = impl.show(Unit)
}

/**
 * a dialog buttons
 *
 * @param text the text of the button
 * @param contentColor the content color of the button
 * @param containerColor the container color of the button
 * @param shape the custom shape of the button
 */
class DialogButton(
    val text: String = "",
    val contentColor: Color = Color.Unspecified,
    val containerColor: Color = Color.Unspecified,
    val shape: Shape? = null
) {
    companion object {
        val DISABLED = DialogButton("")
    }

    val enabled: Boolean
        get() = text.isNotEmpty()

    @Composable
    internal fun Render(
        enabled: Boolean,
        colors: ButtonColors,
        onClick: () -> Unit
    ) {
        TextButton(
            enabled = enabled,
            colors = colors.copy(
                contentColor = contentColor.takeIf { it != Color.Unspecified } ?: colors.contentColor,
                containerColor = containerColor.takeIf { it != Color.Unspecified } ?: colors.containerColor,
                disabledContentColor = contentColor.takeIf { it != Color.Unspecified }?.copy(alpha = 0.38f) ?: colors.disabledContentColor,
                disabledContainerColor = containerColor.takeIf { it != Color.Unspecified }?.copy(alpha = 0.38f) ?: colors.disabledContainerColor,
            ),
            onClick = onClick,
            shape = shape ?: ButtonDefaults.textShape
        ) {
            Text(text)
        }
    }
}

/**
 * see [DialogDefaults.buttons] and [DialogDefaults.buttonsDisabled]
 *
 */
class DialogButtons internal constructor(
    val positive: DialogButton,
    val negative: DialogButton
) {
    companion object {
        val DISABLED = DialogButtons(DialogButton.DISABLED, DialogButton.DISABLED)
    }

    val enabled = positive.enabled || negative.enabled
}

class StyleOptions(
    val iconMode: IconMode = IconMode.CenterTop
) {
    enum class IconMode {
        CenterTop,
        Begin
    }

    fun copy(
        iconMode: IconMode = this.iconMode
    ) = StyleOptions(iconMode)
}

class DialogOptions internal constructor(
    val dismissOnButtonClick: Boolean
)

class DialogSpacing internal constructor(
    val spacingContentToButtons: Dp,
    val spacingContentToBottom: Dp
) {
    fun contentPadding(buttons: DialogButtons) =
        if (buttons.enabled) spacingContentToButtons else spacingContentToBottom
}